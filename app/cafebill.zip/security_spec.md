# Security Specification — CafeBill Firestore Rules

## 1. Data Invariants
1. Every document under `/users/{userId}` and its subcollections (`invoices`, `customers`, `openOrders`, `supportReports`) belongs strictly to the authenticated user whose `request.auth.uid == userId`.
2. Unauthenticated users (`request.auth == null`) have zero read or write access anywhere.
3. No user can read, list, create, update, or delete another user's workspace, invoices, customers, open orders, or support reports.
4. All document IDs (`userId`, `invoiceId`, `customerId`, `orderId`, `reportId`) must match `^[a-zA-Z0-9_\-]+$` and stay within 128 characters.
5. `ownerUid` and `createdAt` are immutable after creation; `createdAt` and `updatedAt` must match `request.time`.
6. Every string field enforces strict `.size()` bounds to prevent resource exhaustion attacks.
7. Unexpected / shadow fields are rejected via `keys().hasAll(...) && keys().hasOnly(...)` on create and `affectedKeys().hasOnly(...)` on update.

## 2. Adversarial Payloads ("Dirty Dozen")
1. Unauthenticated read of `/users/u1` -> PERMISSION_DENIED.
2. Authenticated `u2` reading `/users/u1` -> PERMISSION_DENIED.
3. Authenticated `u2` listing `/users/u1/invoices` -> PERMISSION_DENIED.
4. Authenticated `u1` creating `/users/u1/invoices/inv_1` with `ownerUid: "u2"` -> PERMISSION_DENIED.
5. Authenticated `u1` creating `/users/u1` with ghost field `isAdmin: true` -> PERMISSION_DENIED.
6. Authenticated `u1` creating `/users/u1/invoices/../../bad` -> PERMISSION_DENIED.
7. Authenticated `u1` updating `/users/u1/invoices/inv_1` attempting to change `ownerUid` -> PERMISSION_DENIED.
8. Authenticated `u1` updating `/users/u1/invoices/inv_1` attempting to mutate `createdAt` -> PERMISSION_DENIED.
9. Authenticated `u1` creating `/users/u1/invoices/inv_1` with invalid `currency: "EUR"` -> PERMISSION_DENIED.
10. Authenticated `u1` creating `/users/u1/supportReports/rep_1` with 2MB string in `description` -> PERMISSION_DENIED.
11. Authenticated `u1` updating `/users/u1/supportReports/rep_1` (immutable audit record) -> PERMISSION_DENIED.
12. Authenticated `u1` creating `/users/u1/customers/c1` with client-forged timestamp `createdAt` != `request.time` -> PERMISSION_DENIED.
