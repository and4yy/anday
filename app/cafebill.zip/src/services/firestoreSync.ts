import {
  collection,
  doc,
  serverTimestamp,
  setDoc,
} from 'firebase/firestore';
import { signInWithPopup, signOut } from 'firebase/auth';
import {
  auth,
  db,
  googleAuthProvider,
  handleFirestoreError,
  OperationType,
} from '../lib/firebase';
import type { AuthUser, SupportReportInput } from '../types/auth';
import type { AppDataState } from '../types/invoice';

export async function linkGoogleCloudSync(): Promise<{ uid: string; email: string | null }> {
  const cred = await signInWithPopup(auth, googleAuthProvider);
  return {
    uid: cred.user.uid,
    email: cred.user.email,
  };
}

export async function unlinkGoogleCloudSync(): Promise<void> {
  await signOut(auth);
}

export async function syncWorkspaceToFirestore(
  appUser: AuthUser,
  data: AppDataState
): Promise<void> {
  const firebaseUser = auth.currentUser;
  if (!firebaseUser) return;

  const uid = firebaseUser.uid;
  const userPath = `users/${uid}`;

  try {
    await setDoc(
      doc(db, 'users', uid),
      {
        uid,
        fullName: appUser.fullName,
        phone: appUser.normalizedPhone,
        onboardingCompleted: appUser.onboardingCompleted,
        businessProfileJson: JSON.stringify(data.businessProfile).slice(0, 440000),
        bankAccountsJson: JSON.stringify(data.bankAccounts).slice(0, 49000),
        translationsJson: JSON.stringify(data.translations).slice(0, 49000),
        preferencesJson: JSON.stringify({
          ...data.preferences,
          customFontDataUrl: undefined,
        }).slice(0, 190000),
        quickMenuItemsJson: JSON.stringify(data.quickMenuItems).slice(0, 440000),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, userPath);
  }
}

export async function syncInvoiceToFirestore(
  invoice: AppDataState['invoices'][number]
): Promise<void> {
  const firebaseUser = auth.currentUser;
  if (!firebaseUser) return;

  const uid = firebaseUser.uid;
  const path = `users/${uid}/invoices/${invoice.id}`;

  try {
    await setDoc(
      doc(collection(db, 'users', uid, 'invoices'), invoice.id),
      {
        id: invoice.id,
        ownerUid: uid,
        invoiceNumber: invoice.invoiceNumber,
        date: invoice.date,
        currency: invoice.currency,
        language: invoice.language,
        paymentStatus: invoice.paymentStatus,
        payloadJson: JSON.stringify(invoice).slice(0, 195000),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function saveSupportReportToFirestore(
  reportId: string,
  report: SupportReportInput
): Promise<void> {
  const firebaseUser = auth.currentUser;
  if (!firebaseUser) return;

  const uid = firebaseUser.uid;
  const path = `users/${uid}/supportReports/${reportId}`;

  try {
    await setDoc(doc(collection(db, 'users', uid, 'supportReports'), reportId), {
      id: reportId,
      ownerUid: uid,
      type: report.type,
      category: report.category || '',
      title: report.title,
      description: report.description,
      contactInfo: report.contactInfo || '',
      screenshotDataUrl: (report.screenshotDataUrl || '').slice(0, 440000),
      appVersion: report.appVersion || '',
      deviceInfo: report.deviceInfo || '',
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}
