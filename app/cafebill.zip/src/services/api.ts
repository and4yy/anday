import type { AuthUser, SupportReportInput, SupportReportSummary } from '../types/auth';
import type { AppDataState } from '../types/invoice';

const TOKEN_KEY = 'cafebill_auth_token';
const CACHED_USER_KEY = 'cafebill_cached_user';

export function getStoredToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function getCachedUser(): AuthUser | null {
  try {
    const raw = localStorage.getItem(CACHED_USER_KEY) || sessionStorage.getItem(CACHED_USER_KEY);
    return raw ? (JSON.parse(raw) as AuthUser) : null;
  } catch {
    return null;
  }
}

export function persistAuthSession(user: AuthUser, token: string, rememberMe: boolean): void {
  try {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(CACHED_USER_KEY);
    sessionStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(CACHED_USER_KEY);

    const store = rememberMe ? localStorage : sessionStorage;
    store.setItem(TOKEN_KEY, token);
    store.setItem(CACHED_USER_KEY, JSON.stringify(user));
  } catch {
    // Ignore storage quota issues
  }
}

export function updateCachedUser(user: AuthUser): void {
  try {
    if (localStorage.getItem(TOKEN_KEY)) {
      localStorage.setItem(CACHED_USER_KEY, JSON.stringify(user));
    } else if (sessionStorage.getItem(TOKEN_KEY)) {
      sessionStorage.setItem(CACHED_USER_KEY, JSON.stringify(user));
    }
  } catch {
    // Ignore
  }
}

export function clearAuthSession(): void {
  try {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(CACHED_USER_KEY);
    sessionStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(CACHED_USER_KEY);
  } catch {
    // Ignore
  }
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function apiFetch<T>(url: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((options.headers as Record<string, string>) || {}),
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(url, {
    ...options,
    headers,
    credentials: 'include',
  });

  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) {
    throw new ApiError(data.error || `Request failed (${res.status})`, res.status);
  }
  return data;
}

export async function registerUser(params: {
  fullName: string;
  countryCode: string;
  phoneNumber: string;
  password: string;
  rememberMe: boolean;
}): Promise<{ user: AuthUser; token: string }> {
  const res = await apiFetch<{ user: AuthUser; token: string }>('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify(params),
  });
  persistAuthSession(res.user, res.token, params.rememberMe);
  return res;
}

export async function loginUser(params: {
  countryCode: string;
  phoneNumber: string;
  password: string;
  rememberMe: boolean;
}): Promise<{ user: AuthUser; token: string }> {
  const res = await apiFetch<{ user: AuthUser; token: string }>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify(params),
  });
  persistAuthSession(res.user, res.token, params.rememberMe);
  return res;
}

export async function logoutUser(): Promise<void> {
  try {
    await apiFetch('/api/auth/logout', { method: 'POST' });
  } catch {
    // Always clear local session even when offline
  } finally {
    clearAuthSession();
  }
}

export async function fetchCurrentUser(): Promise<AuthUser> {
  const res = await apiFetch<{ user: AuthUser }>('/api/auth/me');
  updateCachedUser(res.user);
  return res.user;
}

export async function requestForgotPasswordOtp(params: {
  countryCode: string;
  phoneNumber: string;
}): Promise<{ ok: boolean; smsSent: boolean; previewOtp?: string; message: string }> {
  return apiFetch('/api/auth/forgot-password', {
    method: 'POST',
    body: JSON.stringify(params),
  });
}

export async function resetPasswordWithOtp(params: {
  countryCode: string;
  phoneNumber: string;
  otp: string;
  newPassword: string;
}): Promise<{ ok: boolean; message: string }> {
  return apiFetch('/api/auth/reset-password', {
    method: 'POST',
    body: JSON.stringify(params),
  });
}

export async function updateAccountProfile(fullName: string): Promise<AuthUser> {
  const res = await apiFetch<{ user: AuthUser }>('/api/account/profile', {
    method: 'PUT',
    body: JSON.stringify({ fullName }),
  });
  updateCachedUser(res.user);
  return res.user;
}

export async function requestPhoneChangeOtp(params: {
  countryCode: string;
  phoneNumber: string;
}): Promise<{ ok: boolean; smsSent: boolean; previewOtp?: string }> {
  return apiFetch('/api/account/request-phone-otp', {
    method: 'POST',
    body: JSON.stringify(params),
  });
}

export async function verifyPhoneChange(params: {
  countryCode: string;
  phoneNumber: string;
  otp: string;
  currentPassword: string;
}): Promise<AuthUser> {
  const res = await apiFetch<{ user: AuthUser }>('/api/account/verify-phone-change', {
    method: 'POST',
    body: JSON.stringify(params),
  });
  updateCachedUser(res.user);
  return res.user;
}

export async function changeAccountPassword(params: {
  currentPassword: string;
  newPassword: string;
}): Promise<void> {
  await apiFetch('/api/account/change-password', {
    method: 'POST',
    body: JSON.stringify(params),
  });
}

export async function deleteAccount(password: string): Promise<void> {
  await apiFetch('/api/account', {
    method: 'DELETE',
    body: JSON.stringify({ password }),
  });
  clearAuthSession();
}

export interface ServerWorkspaceResponse {
  onboardingCompleted: boolean;
  workspace: Partial<AppDataState> & { updatedAt?: string };
}

export async function fetchServerWorkspace(): Promise<ServerWorkspaceResponse> {
  return apiFetch<ServerWorkspaceResponse>('/api/workspace');
}

export async function pushServerWorkspace(
  data: Partial<AppDataState> & { onboardingCompleted?: boolean }
): Promise<{ ok: boolean; onboardingCompleted: boolean; updatedAt: string }> {
  return apiFetch('/api/workspace', {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function submitSupportReport(
  report: SupportReportInput
): Promise<{ ok: boolean; report: SupportReportSummary }> {
  return apiFetch('/api/support/reports', {
    method: 'POST',
    body: JSON.stringify(report),
  });
}

export async function fetchSupportReports(): Promise<SupportReportSummary[]> {
  const res = await apiFetch<{ reports: SupportReportSummary[] }>('/api/support/reports');
  return res.reports || [];
}
