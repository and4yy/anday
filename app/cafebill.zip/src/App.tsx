import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Coffee,
  FileText,
  Home,
  PlusCircle,
  Settings,
  WifiOff,
} from 'lucide-react';
import { AuthScreen } from './components/AuthScreen';
import { ConfirmModal, ToastBanner, type ToastMessage } from './components/ConfirmModal';
import { DashboardView } from './components/DashboardView';
import { InvoiceBuilderView } from './components/InvoiceBuilderView';
import { InvoicePreviewModal } from './components/InvoicePreviewModal';
import { InvoicesView } from './components/InvoicesView';
import { OnboardingWizard } from './components/OnboardingWizard';
import { PWAInstallButton } from './components/PWAInstallButton';
import { SettingsView } from './components/SettingsView';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { auth } from './lib/firebase';
import {
  ApiError,
  clearAuthSession,
  fetchCurrentUser,
  fetchServerWorkspace,
  getCachedUser,
  getStoredToken,
  logoutUser,
  pushServerWorkspace,
  updateCachedUser,
} from './services/api';
import {
  syncInvoiceToFirestore,
  syncWorkspaceToFirestore,
} from './services/firestoreSync';
import {
  createBackupPayloadFromState,
  createEmptyAppData,
  deleteUserLocalWorkspace,
  loadUserLocalWorkspace,
  mergeOrReplaceBackup,
  saveUserLocalWorkspace,
} from './storage/db';
import { GUEST_USER, type AuthUser } from './types/auth';
import type {
  AppDataState,
  AppPreferences,
  BackupPayload,
  BankAccount,
  BusinessProfile,
  Customer,
  Invoice,
  OpenTableOrder,
  QuickMenuItem,
  TranslationMap,
} from './types/invoice';
import {
  calculateInvoiceTotals,
  createId,
  formatInvoiceNumber,
  getTodayISO,
} from './utils/calculations';
import { applyCustomFontToDocument } from './utils/pngExport';

type AppTab = 'dashboard' | 'new-invoice' | 'invoices' | 'settings';
const GUEST_MODE_KEY = 'cafebill_guest_mode';

function SplashScreen({ message }: { message: string }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#3D1E0D] px-6 text-center text-[#FAF9F7]">
      <div className="flex flex-col items-center gap-4">
        <img
          src="/cafebill-logo.png"
          alt="CafePOS"
          className="h-28 w-28 rounded-3xl object-cover shadow-2xl ring-1 ring-white/10"
        />
        <div className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight text-[#FFF6E8]">CafePOS</h1>
          <p className="text-xs font-medium text-[#E2AE60]">{message}</p>
        </div>
        <div className="mt-2 h-1.5 w-28 overflow-hidden rounded-full bg-white/15">
          <div className="h-full w-1/2 animate-pulse rounded-full bg-[#E2AE60]" />
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const isOnline = useOnlineStatus();
  const [authChecking, setAuthChecking] = useState(true);
  const [authUser, setAuthUser] = useState<AuthUser | null>(null);

  const [activeTab, setActiveTab] = useState<AppTab>('dashboard');
  const [appData, setAppData] = useState<AppDataState | null>(null);
  const appDataRef = useRef<AppDataState | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [preselectedCustomer, setPreselectedCustomer] = useState<Customer | null>(null);
  const [builderKey, setBuilderKey] = useState<number>(1);
  const [previewInvoice, setPreviewInvoice] = useState<Invoice | null>(null);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [markPaidCandidate, setMarkPaidCandidate] = useState<Invoice | null>(null);

  useEffect(() => {
    appDataRef.current = appData;
  }, [appData]);

  const notify = useCallback((text: string, type: 'success' | 'info' | 'error' = 'info') => {
    const id = createId('toast');
    setToast({ id, text, type });
    setTimeout(() => {
      setToast((curr) => (curr?.id === id ? null : curr));
    }, 3500);
  }, []);

  // 1. Restore session on boot (works offline with cached user)
  useEffect(() => {
    let active = true;
    const initAuth = async () => {
      const token = getStoredToken();
      const cached = getCachedUser();

      if (!token) {
        let isGuestSession = false;
        try {
          const params = new URLSearchParams(window.location.search);
          isGuestSession =
            params.get('demo') === '1' ||
            params.get('guest') === '1' ||
            sessionStorage.getItem(GUEST_MODE_KEY) === '1';
        } catch {
          isGuestSession = false;
        }
        if (active) {
          setAuthUser(isGuestSession ? GUEST_USER : null);
          setAuthChecking(false);
        }
        return;
      }

      if (!navigator.onLine) {
        if (active) {
          setAuthUser(cached);
          setAuthChecking(false);
        }
        return;
      }

      try {
        const freshUser = await fetchCurrentUser();
        if (active) {
          setAuthUser(freshUser);
          setAuthChecking(false);
        }
      } catch (err) {
        if (!active) return;
        if (err instanceof ApiError && err.status === 401) {
          clearAuthSession();
          setAuthUser(null);
        } else {
          // Network/server error -> stay offline-resilient using cached session
          setAuthUser(cached);
        }
        setAuthChecking(false);
      }
    };

    void initAuth();
    return () => {
      active = false;
    };
  }, []);

  // 2. Load user-isolated workspace (IndexedDB + Server sync)
  useEffect(() => {
    if (!authUser) {
      setAppData(null);
      return;
    }

    let cancelled = false;
    setLoadError(null);

    const hydrateWorkspace = async () => {
      try {
        const local = await loadUserLocalWorkspace(authUser.id);

        if (authUser.isGuest) {
          if (local) {
            if (!cancelled) {
              setAppData(local.data);
              applyCustomFontToDocument(local.data.preferences.customFontDataUrl);
            }
          } else {
            const guestWorkspace = createEmptyAppData({
              businessProfile: {
                name: 'CafePOS Demo Café',
                address: "Male', Maldives",
                phone: '+960 330-0000',
                defaultFooterEn: 'Thank you for visiting! We appreciate your business.',
                defaultFooterDv: 'ޒިޔާރަތް ކުރެއްވި ކަމަށްޓަކައި ޝުކުރިއްޔާ!',
              },
            });
            await saveUserLocalWorkspace(authUser.id, guestWorkspace, false);
            if (!cancelled) {
              setAppData(guestWorkspace);
            }
          }
          return;
        }

        if (local && !cancelled) {
          setAppData(local.data);
          applyCustomFontToDocument(local.data.preferences.customFontDataUrl);
        }

        if (navigator.onLine) {
          try {
            const serverRes = await fetchServerWorkspace();
            if (cancelled) return;

            if (local?.pendingSync) {
              await pushServerWorkspace({
                ...local.data,
                onboardingCompleted: authUser.onboardingCompleted,
              });
              await saveUserLocalWorkspace(authUser.id, local.data, false);
            } else {
              const serverHasData =
                serverRes.workspace &&
                Object.keys(serverRes.workspace).some((k) => k !== 'updatedAt');

              const nextData = serverHasData
                ? createEmptyAppData(serverRes.workspace)
                : local?.data || createEmptyAppData();

              await saveUserLocalWorkspace(authUser.id, nextData, false);
              if (!cancelled) {
                setAppData(nextData);
                applyCustomFontToDocument(nextData.preferences.customFontDataUrl);
              }
            }

            if (serverRes.onboardingCompleted && !authUser.onboardingCompleted) {
              const syncedUser = { ...authUser, onboardingCompleted: true };
              updateCachedUser(syncedUser);
              if (!cancelled) setAuthUser(syncedUser);
            }
          } catch {
            // Keep local workspace when server is temporarily unreachable
            if (!local && !cancelled) {
              const empty = createEmptyAppData();
              await saveUserLocalWorkspace(authUser.id, empty, false);
              setAppData(empty);
            }
          }
        } else if (!local && !cancelled) {
          const empty = createEmptyAppData();
          await saveUserLocalWorkspace(authUser.id, empty, false);
          setAppData(empty);
        }
      } catch {
        if (!cancelled) {
          setLoadError('Unable to access local browser storage (IndexedDB).');
        }
      }
    };

    void hydrateWorkspace();
    return () => {
      cancelled = true;
    };
  }, [authUser?.id]);

  // 3. Auto-sync pending offline changes when internet returns
  useEffect(() => {
    if (!isOnline || !authUser || authUser.isGuest || !appData) return;

    let cancelled = false;
    const flushPending = async () => {
      try {
        const local = await loadUserLocalWorkspace(authUser.id);
        if (!local?.pendingSync || cancelled) return;

        await pushServerWorkspace({
          ...local.data,
          onboardingCompleted: authUser.onboardingCompleted,
        });
        await saveUserLocalWorkspace(authUser.id, local.data, false);
        if (!cancelled) {
          notify('Offline changes synced to your account.', 'success');
        }
      } catch {
        // Will retry next time connectivity stabilizes
      }
    };

    void flushPending();
    return () => {
      cancelled = true;
    };
  }, [isOnline, authUser, appData, notify]);

  // Unified offline-first workspace commit helper
  const commitWorkspace = useCallback(
    async (
      updater: (curr: AppDataState) => AppDataState,
      options?: { onboardingCompleted?: boolean }
    ) => {
      if (!authUser) return;
      const base = appDataRef.current || createEmptyAppData();
      const next = updater(base);
      appDataRef.current = next;
      setAppData(next);

      const onboardingFlag =
        options?.onboardingCompleted ?? authUser.onboardingCompleted;

      await saveUserLocalWorkspace(authUser.id, next, !authUser.isGuest);

      if (authUser.isGuest) return;

      if (navigator.onLine) {
        try {
          await pushServerWorkspace({
            ...next,
            onboardingCompleted: onboardingFlag,
          });
          await saveUserLocalWorkspace(authUser.id, next, false);
        } catch {
          // Remains queued as pendingSync=true in IndexedDB
        }
      }

      if (auth.currentUser) {
        void syncWorkspaceToFirestore(authUser, next).catch(() => {});
      }
    },
    [authUser]
  );

  const handleAuthenticated = (user: AuthUser) => {
    try {
      sessionStorage.removeItem(GUEST_MODE_KEY);
    } catch {
      // Ignore
    }
    setAuthUser(user);
    setActiveTab('dashboard');
    setEditingInvoice(null);
    setPreviewInvoice(null);
  };

  const handleContinueAsGuest = () => {
    try {
      sessionStorage.setItem(GUEST_MODE_KEY, '1');
    } catch {
      // Ignore
    }
    setAuthUser(GUEST_USER);
    setActiveTab('new-invoice');
    setEditingInvoice(null);
    setPreviewInvoice(null);
    notify('Testing CafePOS in local Guest Demo mode.', 'info');
  };

  const handleCompleteOnboarding = async (initialWorkspace: AppDataState) => {
    if (!authUser) return;
    await saveUserLocalWorkspace(authUser.id, initialWorkspace, !navigator.onLine);
    if (navigator.onLine) {
      await pushServerWorkspace({
        ...initialWorkspace,
        onboardingCompleted: true,
      });
      await saveUserLocalWorkspace(authUser.id, initialWorkspace, false);
    }
    const updatedUser: AuthUser = { ...authUser, onboardingCompleted: true };
    updateCachedUser(updatedUser);
    appDataRef.current = initialWorkspace;
    setAppData(initialWorkspace);
    applyCustomFontToDocument(initialWorkspace.preferences.customFontDataUrl);
    setAuthUser(updatedUser);
    setActiveTab('dashboard');
    notify('Business workspace ready! Welcome to CafePOS.', 'success');
  };

  const handleLogout = async () => {
    try {
      sessionStorage.removeItem(GUEST_MODE_KEY);
    } catch {
      // Ignore
    }
    if (!authUser?.isGuest) {
      await logoutUser();
    }
    setAuthUser(null);
    setAppData(null);
    appDataRef.current = null;
    setEditingInvoice(null);
    setPreviewInvoice(null);
    setActiveTab('dashboard');
  };

  const handleAccountDeleted = async () => {
    if (authUser) {
      await deleteUserLocalWorkspace(authUser.id).catch(() => {});
    }
    clearAuthSession();
    setAuthUser(null);
    setAppData(null);
    appDataRef.current = null;
    setEditingInvoice(null);
    setPreviewInvoice(null);
    notify('Your account has been permanently deleted.', 'info');
  };

  const handleSyncToCloud = async () => {
    if (!authUser || !appDataRef.current) return;
    await syncWorkspaceToFirestore(authUser, appDataRef.current);
  };

  const handleOpenNewInvoice = (customer?: Customer) => {
    setEditingInvoice(null);
    setPreselectedCustomer(customer || null);
    setBuilderKey((k) => k + 1);
    setActiveTab('new-invoice');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleEditInvoice = (invoice: Invoice) => {
    setEditingInvoice(invoice);
    setPreselectedCustomer(null);
    setBuilderKey((k) => k + 1);
    setActiveTab('new-invoice');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDuplicateInvoice = (invoice: Invoice) => {
    if (!appData) return;
    const nextNum = formatInvoiceNumber(
      appData.preferences.invoicePrefix,
      appData.preferences.nextInvoiceSequence
    );
    const copy: Invoice = {
      ...invoice,
      id: '',
      invoiceNumber: nextNum,
      date: getTodayISO(),
      paymentStatus: 'UNPAID',
      paymentDate: undefined,
      amountPaid: 0,
    };
    setEditingInvoice(copy);
    setPreselectedCustomer(null);
    setBuilderKey((k) => k + 1);
    setActiveTab('new-invoice');
    notify(`Duplicated ${invoice.invoiceNumber} as ${nextNum}.`, 'info');
  };

  const handleSaveInvoice = async (
    invoice: Invoice,
    isNew: boolean,
    fromTableKey?: string
  ) => {
    await commitWorkspace((prev) => {
      const nextPrefs = isNew
        ? {
            ...prev.preferences,
            nextInvoiceSequence: prev.preferences.nextInvoiceSequence + 1,
          }
        : prev.preferences;

      const nextOpenOrders = fromTableKey
        ? prev.openOrders.filter((o) => o.id !== fromTableKey)
        : prev.openOrders;

      const exists = prev.invoices.some((i) => i.id === invoice.id);
      const nextInvoices = exists
        ? prev.invoices.map((i) => (i.id === invoice.id ? invoice : i))
        : [invoice, ...prev.invoices];
      nextInvoices.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));

      return {
        ...prev,
        preferences: nextPrefs,
        invoices: nextInvoices,
        openOrders: nextOpenOrders,
      };
    });

    if (auth.currentUser) {
      void syncInvoiceToFirestore(invoice).catch(() => {});
    }

    if (previewInvoice && previewInvoice.id === invoice.id) {
      setPreviewInvoice(invoice);
    }
  };

  const handleConfirmMarkPaid = async (invoice: Invoice) => {
    const totals = calculateInvoiceTotals(
      invoice.items,
      invoice.discountType,
      invoice.discountValue,
      invoice.additionalChargeAmount,
      invoice.amountPaid,
      'PAID'
    );
    const updated: Invoice = {
      ...invoice,
      paymentStatus: 'PAID',
      paymentDate: getTodayISO(),
      amountPaid: totals.grandTotal,
      updatedAt: new Date().toISOString(),
    };
    await handleSaveInvoice(updated, false);
    notify(`Marked ${updated.invoiceNumber} as PAID.`, 'success');
  };

  const handleDeleteInvoice = async (id: string) => {
    await commitWorkspace((prev) => ({
      ...prev,
      invoices: prev.invoices.filter((i) => i.id !== id),
    }));
    notify('Invoice deleted.', 'info');
  };

  const handleSaveCustomer = async (customer: Customer) => {
    await commitWorkspace((prev) => {
      const exists = prev.customers.some((c) => c.id === customer.id);
      const nextCustomers = exists
        ? prev.customers.map((c) => (c.id === customer.id ? customer : c))
        : [...prev.customers, customer];
      nextCustomers.sort((a, b) => a.name.localeCompare(b.name));
      return { ...prev, customers: nextCustomers };
    });
  };

  const handleDeleteCustomer = async (id: string) => {
    await commitWorkspace((prev) => ({
      ...prev,
      customers: prev.customers.filter((c) => c.id !== id),
    }));
    notify('Customer removed.', 'info');
  };

  const handleSaveOpenOrder = async (order: OpenTableOrder) => {
    await commitWorkspace((prev) => {
      const exists = prev.openOrders.some((o) => o.id === order.id);
      const next = exists
        ? prev.openOrders.map((o) => (o.id === order.id ? order : o))
        : [...prev.openOrders, order];
      return { ...prev, openOrders: next };
    });
  };

  const handleDeleteOpenOrder = async (tableKey: string) => {
    await commitWorkspace((prev) => ({
      ...prev,
      openOrders: prev.openOrders.filter((o) => o.id !== tableKey),
    }));
  };

  const handleSaveProfile = async (businessProfile: BusinessProfile) => {
    await commitWorkspace((prev) => ({ ...prev, businessProfile }));
  };

  const handleSaveBanks = async (bankAccounts: BankAccount[]) => {
    await commitWorkspace((prev) => ({ ...prev, bankAccounts }));
  };

  const handleSaveTrans = async (translations: TranslationMap) => {
    await commitWorkspace((prev) => ({ ...prev, translations }));
  };

  const handleSavePrefs = async (preferences: AppPreferences) => {
    applyCustomFontToDocument(preferences.customFontDataUrl);
    await commitWorkspace((prev) => ({ ...prev, preferences }));
  };

  const handleSaveMenu = async (quickMenuItems: QuickMenuItem[]) => {
    await commitWorkspace((prev) => ({ ...prev, quickMenuItems }));
  };

  const handleExportBackup = async () => {
    if (!appDataRef.current) return;
    const payload = createBackupPayloadFromState(appDataRef.current);
    const json = JSON.stringify(payload, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `cafepos-backup-${getTodayISO()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    notify('Backup JSON exported.', 'success');
  };

  const handleImportBackup = async (
    payload: BackupPayload,
    mode: 'replace' | 'merge'
  ) => {
    await commitWorkspace((prev) => {
      const restored = mergeOrReplaceBackup(prev, payload, mode);
      applyCustomFontToDocument(restored.preferences.customFontDataUrl);
      return restored;
    });
    notify('Backup data restored.', 'success');
  };

  if (authChecking) {
    return <SplashScreen message="Starting CafePOS..." />;
  }

  if (!authUser) {
    return (
      <AuthScreen
        onAuthenticated={handleAuthenticated}
        onContinueAsGuest={handleContinueAsGuest}
      />
    );
  }

  if (loadError) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#FAF9F7] p-6">
        <div className="max-w-sm rounded-2xl border border-rose-200 bg-white p-6 text-center">
          <h1 className="text-base font-bold text-[#1C1917]">Storage Error</h1>
          <p className="mt-2 text-sm text-stone-600">{loadError}</p>
        </div>
      </div>
    );
  }

  if (!appData) {
    return <SplashScreen message="Loading your café workspace..." />;
  }

  if (!authUser.onboardingCompleted) {
    return (
      <OnboardingWizard
        user={authUser}
        onComplete={handleCompleteOnboarding}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#FAF9F7] text-[#1C1917] pb-24 md:pb-10">
      {/* Top Bar: Café Owner Business Name & Logo remain customizable */}
      <header className="border-b border-stone-200/80 bg-white">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 sm:gap-8 px-4 py-3 sm:px-6">
          {/* Zone 1: Café Business Brand */}
          <button
            type="button"
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-2.5 text-start whitespace-nowrap shrink-0 min-w-0"
          >
            {appData.businessProfile.logoDataUrl ? (
              <img
                src={appData.businessProfile.logoDataUrl}
                alt={appData.businessProfile.name}
                className="h-9 w-9 rounded-xl border border-stone-200 bg-white object-contain p-0.5 shrink-0"
              />
            ) : (
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#2C1B18] text-white">
                <Coffee className="h-5 w-5" />
              </div>
            )}
            <span className="text-lg font-bold tracking-tight text-[#1C1917] truncate max-w-[160px] sm:max-w-[240px]">
              {appData.businessProfile.name || 'CafePOS'}
            </span>
          </button>

          {/* Zone 2: Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-stone-600">
            {(
              [
                { id: 'dashboard', label: 'Dashboard' },
                { id: 'new-invoice', label: 'New Invoice' },
                { id: 'invoices', label: 'Invoices' },
                { id: 'settings', label: 'Settings' },
              ] as { id: AppTab; label: string }[]
            ).map((nav) => (
              <button
                key={nav.id}
                type="button"
                onClick={() => {
                  if (nav.id === 'new-invoice' && activeTab !== 'new-invoice') {
                    handleOpenNewInvoice();
                  } else {
                    setActiveTab(nav.id);
                  }
                }}
                className={`py-1 transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === nav.id
                    ? 'text-[#2C1B18] underline decoration-2 underline-offset-8'
                    : 'hover:text-[#1C1917]'
                }`}
              >
                {nav.label}
              </button>
            ))}
          </nav>

          {/* Zone 3: Install & Primary Action */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="hidden sm:block">
              <PWAInstallButton variant="compact" />
            </div>
            <button
              type="button"
              onClick={() => handleOpenNewInvoice()}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[#4E2A16] px-4 py-2 text-xs font-bold text-white hover:bg-[#3E2723] whitespace-nowrap shrink-0 min-h-[40px]"
            >
              <PlusCircle className="h-4 w-4" />
              <span>New Invoice</span>
            </button>
          </div>
        </div>
      </header>

      {/* Guest Demo Banner */}
      {authUser.isGuest && (
        <div className="border-b border-stone-200 bg-[#FAF6F0] px-4 py-2 text-xs text-[#4E2A16]">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-2">
            <span className="font-semibold">
              Guest Demo Mode — Testing locally without logging in.
            </span>
            <button
              type="button"
              onClick={() => void handleLogout()}
              className="rounded-lg bg-[#4E2A16] px-3 py-1 text-[11px] font-bold text-white hover:bg-[#3E2723]"
            >
              Sign In / Create Account
            </button>
          </div>
        </div>
      )}

      {/* Offline Connectivity Banner */}
      {!isOnline && (
        <div className="border-b border-amber-200 bg-amber-50 px-4 py-2 text-center text-xs font-semibold text-amber-900">
          <WifiOff className="mr-1.5 inline h-3.5 w-3.5" />
          Offline Mode — Invoices and settings are saved locally and will sync automatically when online.
        </div>
      )}

      {/* Main Content */}
      <main className="mx-auto max-w-7xl px-4 py-5 sm:px-6 sm:py-6">
        {activeTab === 'dashboard' && (
          <DashboardView
            businessName={appData.businessProfile.name}
            invoices={appData.invoices}
            onCreateInvoice={() => handleOpenNewInvoice()}
            onPreviewInvoice={(inv) => setPreviewInvoice(inv)}
            onMarkPaid={(inv) => setMarkPaidCandidate(inv)}
            onViewAllInvoices={() => setActiveTab('invoices')}
          />
        )}

        {activeTab === 'new-invoice' && (
          <InvoiceBuilderView
            key={builderKey}
            editingInvoice={editingInvoice}
            preselectedCustomer={preselectedCustomer}
            businessProfile={appData.businessProfile}
            bankAccounts={appData.bankAccounts}
            translations={appData.translations}
            preferences={appData.preferences}
            quickMenuItems={appData.quickMenuItems}
            customers={appData.customers}
            openOrders={appData.openOrders}
            onSaveInvoice={handleSaveInvoice}
            onSaveOpenOrder={handleSaveOpenOrder}
            onDeleteOpenOrder={handleDeleteOpenOrder}
            onQuickSaveCustomer={handleSaveCustomer}
            onOpenPreviewModal={(inv) => setPreviewInvoice(inv)}
            onViewHistory={() => setActiveTab('invoices')}
            onNotify={notify}
            onCancelEdit={() => {
              setEditingInvoice(null);
              setActiveTab('invoices');
            }}
          />
        )}

        {activeTab === 'invoices' && (
          <InvoicesView
            invoices={appData.invoices}
            customers={appData.customers}
            onCreateInvoice={(cust) => handleOpenNewInvoice(cust)}
            onEditInvoice={handleEditInvoice}
            onDuplicateInvoice={handleDuplicateInvoice}
            onPreviewInvoice={(inv) => setPreviewInvoice(inv)}
            onMarkPaid={(inv) => setMarkPaidCandidate(inv)}
            onDeleteInvoice={(id) => void handleDeleteInvoice(id)}
            onSaveCustomer={(c) => void handleSaveCustomer(c)}
            onDeleteCustomer={(id) => void handleDeleteCustomer(id)}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            user={authUser}
            businessProfile={appData.businessProfile}
            bankAccounts={appData.bankAccounts}
            translations={appData.translations}
            preferences={appData.preferences}
            quickMenuItems={appData.quickMenuItems}
            onUserUpdated={(u) => {
              updateCachedUser(u);
              setAuthUser(u);
            }}
            onLogout={() => void handleLogout()}
            onAccountDeleted={() => void handleAccountDeleted()}
            onSyncToCloud={handleSyncToCloud}
            onSaveBusinessProfile={handleSaveProfile}
            onSaveBankAccounts={handleSaveBanks}
            onSaveTranslations={handleSaveTrans}
            onSavePreferences={handleSavePrefs}
            onSaveQuickMenu={handleSaveMenu}
            onExportBackup={handleExportBackup}
            onImportBackup={handleImportBackup}
            onNotify={notify}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <nav
        aria-label="Mobile Navigation"
        className="fixed bottom-0 left-0 right-0 z-40 grid h-16 grid-cols-4 items-center border-t border-stone-200 bg-white/95 backdrop-blur-md pb-safe md:hidden"
      >
        {(
          [
            { id: 'dashboard', label: 'Dashboard', icon: Home },
            { id: 'new-invoice', label: 'New Invoice', icon: PlusCircle },
            { id: 'invoices', label: 'Invoices', icon: FileText },
            { id: 'settings', label: 'Settings', icon: Settings },
          ] as {
            id: AppTab;
            label: string;
            icon: React.ComponentType<{ className?: string }>;
          }[]
        ).map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                if (item.id === 'new-invoice' && activeTab !== 'new-invoice') {
                  handleOpenNewInvoice();
                } else {
                  setActiveTab(item.id);
                }
              }}
              className={`flex h-full flex-col items-center justify-center gap-0.5 text-[11px] font-semibold transition-colors ${
                isActive ? 'text-[#4E2A16]' : 'text-stone-500 hover:text-[#1C1917]'
              }`}
            >
              <Icon className={`h-5 w-5 ${isActive ? 'stroke-[2.4]' : 'stroke-[1.8]'}`} />
              <span className="whitespace-nowrap">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Invoice Full-Screen Preview & PNG Export Modal */}
      <InvoicePreviewModal
        invoice={previewInvoice}
        businessProfile={appData.businessProfile}
        bankAccounts={appData.bankAccounts}
        translations={appData.translations}
        exchangeRateUsdToMvr={appData.preferences.exchangeRateUsdToMvr}
        customFontDataUrl={appData.preferences.customFontDataUrl}
        onClose={() => setPreviewInvoice(null)}
        onMarkPaid={(inv) => setMarkPaidCandidate(inv)}
        onEdit={(inv) => handleEditInvoice(inv)}
        onNotify={notify}
      />

      {/* Confirm Mark Paid Modal */}
      <ConfirmModal
        open={Boolean(markPaidCandidate)}
        title="Mark Invoice as Paid?"
        message={`Confirm payment received for ${markPaidCandidate?.invoiceNumber || ''}? Today's date will be recorded and the green PAID stamp will appear on the receipt.`}
        confirmLabel="Mark as Paid"
        onConfirm={() => {
          if (markPaidCandidate) void handleConfirmMarkPaid(markPaidCandidate);
          setMarkPaidCandidate(null);
        }}
        onCancel={() => setMarkPaidCandidate(null)}
      />

      {/* Toast Notification */}
      <ToastBanner toast={toast} onDismiss={() => setToast(null)} />
    </div>
  );
}
