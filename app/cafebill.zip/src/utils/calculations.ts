import type {
  CurrencyCode,
  DiscountType,
  Invoice,
  InvoiceLineItem,
  PaymentStatus,
} from '../types/invoice';

export interface InvoiceTotals {
  subtotal: number;
  discountAmount: number;
  additionalChargeAmount: number;
  grandTotal: number;
  amountPaid: number;
  balanceDue: number;
}

export function roundMoney(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export function calculateLineTotal(quantity: number, unitPrice: number): number {
  const q = Number.isFinite(quantity) ? Math.max(0, quantity) : 0;
  const p = Number.isFinite(unitPrice) ? Math.max(0, unitPrice) : 0;
  return roundMoney(q * p);
}

export function calculateInvoiceTotals(
  items: InvoiceLineItem[],
  discountType: DiscountType,
  discountValue: number,
  additionalChargeAmount: number,
  amountPaidInput: number,
  paymentStatus: PaymentStatus
): InvoiceTotals {
  const subtotal = roundMoney(
    items.reduce((sum, item) => sum + calculateLineTotal(item.quantity, item.unitPrice), 0)
  );

  const safeDiscountVal = Number.isFinite(discountValue) ? Math.max(0, discountValue) : 0;
  let discountAmount =
    discountType === 'percent'
      ? roundMoney((subtotal * Math.min(100, safeDiscountVal)) / 100)
      : roundMoney(safeDiscountVal);

  if (discountAmount > subtotal) {
    discountAmount = subtotal;
  }

  const safeAdditional = Number.isFinite(additionalChargeAmount)
    ? Math.max(0, roundMoney(additionalChargeAmount))
    : 0;

  const grandTotal = roundMoney(Math.max(0, subtotal - discountAmount + safeAdditional));

  let amountPaid = 0;
  if (paymentStatus === 'PAID') {
    amountPaid = grandTotal;
  } else if (paymentStatus === 'PARTIALLY_PAID') {
    const safePaid = Number.isFinite(amountPaidInput) ? Math.max(0, roundMoney(amountPaidInput)) : 0;
    amountPaid = Math.min(grandTotal, safePaid);
  } else {
    amountPaid = 0;
  }

  const balanceDue = roundMoney(Math.max(0, grandTotal - amountPaid));

  return {
    subtotal,
    discountAmount,
    additionalChargeAmount: safeAdditional,
    grandTotal,
    amountPaid,
    balanceDue,
  };
}

export function getInvoiceComputedTotals(invoice: Invoice): InvoiceTotals {
  return calculateInvoiceTotals(
    invoice.items,
    invoice.discountType,
    invoice.discountValue,
    invoice.additionalChargeAmount,
    invoice.amountPaid,
    invoice.paymentStatus
  );
}

export function formatCurrency(amount: number, currency: CurrencyCode): string {
  const safe = roundMoney(amount);
  const formattedNumber = safe.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return currency === 'USD' ? `$${formattedNumber}` : `MVR ${formattedNumber}`;
}

export function formatNumber(amount: number): string {
  return roundMoney(amount).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export function getTodayISO(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function formatDateReadable(isoDate: string): string {
  if (!isoDate) return '';
  const parts = isoDate.split('-');
  if (parts.length !== 3) return isoDate;
  const year = Number(parts[0]);
  const month = Number(parts[1]) - 1;
  const day = Number(parts[2]);
  const dt = new Date(year, month, day);
  if (Number.isNaN(dt.getTime())) return isoDate;
  return dt.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatInvoiceNumber(prefix: string, sequence: number): string {
  const cleanPrefix = (prefix || 'INV-').trim();
  return `${cleanPrefix}${String(Math.max(1, sequence)).padStart(4, '0')}`;
}

export type DateFilterPreset = 'today' | 'week' | 'month' | 'all' | 'custom';

export function isDateInFilter(
  isoDate: string,
  preset: DateFilterPreset,
  customStart?: string,
  customEnd?: string
): boolean {
  if (preset === 'all') return true;
  if (!isoDate) return false;

  const todayStr = getTodayISO();
  if (preset === 'today') {
    return isoDate === todayStr;
  }

  const now = new Date();
  if (preset === 'week') {
    const startOfWeek = new Date(now);
    const day = startOfWeek.getDay(); // 0=Sun
    startOfWeek.setDate(startOfWeek.getDate() - day);
    const startStr = `${startOfWeek.getFullYear()}-${String(startOfWeek.getMonth() + 1).padStart(2, '0')}-${String(startOfWeek.getDate()).padStart(2, '0')}`;
    return isoDate >= startStr && isoDate <= todayStr;
  }

  if (preset === 'month') {
    const monthPrefix = todayStr.slice(0, 7);
    return isoDate.startsWith(monthPrefix);
  }

  if (preset === 'custom') {
    if (customStart && isoDate < customStart) return false;
    if (customEnd && isoDate > customEnd) return false;
    return true;
  }

  return true;
}

export function createId(prefix = 'id'): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `${prefix}_${crypto.randomUUID()}`;
  }
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}
