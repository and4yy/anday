import { toBlob } from 'html-to-image';

let cachedThaanaBase64: string | null = null;
let cachedDhanbumaaBase64: string | null | undefined = undefined;

async function fetchFontAsDataUrl(url: string): Promise<string | null> {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const contentType = (res.headers.get('content-type') || '').toLowerCase();
    if (contentType.includes('text/html')) return null;
    const blob = await res.blob();
    if (blob.type.includes('text/html') || blob.size < 1024) return null;
    return await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(typeof reader.result === 'string' ? reader.result : '');
      reader.onerror = () => reject(new Error('Failed to read font blob'));
      reader.readAsDataURL(blob);
    });
  } catch {
    return null;
  }
}

export async function getEmbeddedFontCSS(customFontDataUrl?: string): Promise<string> {
  if (cachedDhanbumaaBase64 === undefined) {
    cachedDhanbumaaBase64 = await fetchFontAsDataUrl('/fonts/Dhanbumaa_Regular.otf');
  }
  if (!cachedThaanaBase64) {
    cachedThaanaBase64 = await fetchFontAsDataUrl('/fonts/NotoSansThaana.ttf');
  }

  const rules: string[] = [];

  if (cachedDhanbumaaBase64) {
    rules.push(`
      @font-face {
        font-family: 'Dhanbumaa';
        src: url('${cachedDhanbumaaBase64}') format('opentype');
        font-weight: 100 900;
        font-style: normal;
        font-display: swap;
      }
    `);
  }

  if (cachedThaanaBase64) {
    rules.push(`
      @font-face {
        font-family: 'Noto Sans Thaana';
        src: url('${cachedThaanaBase64}') format('truetype');
        font-weight: 100 900;
        font-style: normal;
        font-display: swap;
      }
    `);
  }

  if (customFontDataUrl) {
    rules.push(`
      @font-face {
        font-family: 'CustomDhivehiFont';
        src: url('${customFontDataUrl}');
        font-weight: 100 900;
        font-style: normal;
        font-display: swap;
      }
    `);
  }

  return rules.join('\n');
}

export function applyCustomFontToDocument(customFontDataUrl?: string): void {
  if (typeof document === 'undefined') return;
  const existing = document.getElementById('custom-dhivehi-font-style');
  if (!customFontDataUrl) {
    if (existing) existing.remove();
    return;
  }
  const styleEl = existing || document.createElement('style');
  styleEl.id = 'custom-dhivehi-font-style';
  styleEl.textContent = `
    @font-face {
      font-family: 'CustomDhivehiFont';
      src: url('${customFontDataUrl}');
      font-weight: 100 900;
      font-style: normal;
      font-display: swap;
    }
  `;
  if (!existing) {
    document.head.appendChild(styleEl);
  }
}

export async function generateInvoicePngBlob(
  element: HTMLElement,
  customFontDataUrl?: string
): Promise<Blob> {
  if (document.fonts && document.fonts.ready) {
    await document.fonts.ready;
  }

  const fontEmbedCSS = await getEmbeddedFontCSS(customFontDataUrl);

  const width = element.scrollWidth || element.offsetWidth;
  const height = element.scrollHeight || element.offsetHeight;

  const blob = await toBlob(element, {
    backgroundColor: '#ffffff',
    pixelRatio: 2.5,
    cacheBust: false,
    fontEmbedCSS,
    width,
    height,
    style: {
      margin: '0',
      boxShadow: 'none',
    },
  });

  if (!blob) {
    throw new Error('Could not render invoice image.');
  }

  return blob;
}

export function downloadPngBlob(blob: Blob, filename: string): void {
  const safeName = filename.replace(/[^a-zA-Z0-9_-]+/g, '_') || 'invoice';
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = safeName.endsWith('.png') ? safeName : `${safeName}.png`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export interface ShareResult {
  method: 'web-share' | 'download-fallback';
}

export async function shareInvoicePng(
  blob: Blob,
  filename: string,
  title: string,
  text: string
): Promise<ShareResult> {
  const safeName = filename.replace(/[^a-zA-Z0-9_-]+/g, '_') || 'invoice';
  const finalName = safeName.endsWith('.png') ? safeName : `${safeName}.png`;
  const file = new File([blob], finalName, { type: 'image/png' });

  const nav = navigator as Navigator & {
    canShare?: (data: ShareData) => boolean;
  };

  if (typeof nav.share === 'function' && typeof nav.canShare === 'function') {
    try {
      if (nav.canShare({ files: [file] })) {
        await nav.share({
          files: [file],
          title,
          text,
        });
        return { method: 'web-share' };
      }
    } catch (err) {
      if ((err as Error)?.name === 'AbortError') {
        throw err;
      }
    }
  }

  downloadPngBlob(blob, finalName);
  return { method: 'download-fallback' };
}

export async function copyPngToClipboard(blob: Blob): Promise<boolean> {
  if (
    typeof navigator === 'undefined' ||
    !navigator.clipboard ||
    typeof ClipboardItem === 'undefined' ||
    typeof navigator.clipboard.write !== 'function'
  ) {
    return false;
  }
  await navigator.clipboard.write([
    new ClipboardItem({
      'image/png': blob,
    }),
  ]);
  return true;
}

export function isClipboardImageSupported(): boolean {
  return (
    typeof navigator !== 'undefined' &&
    Boolean(navigator.clipboard) &&
    typeof ClipboardItem !== 'undefined' &&
    typeof navigator.clipboard.write === 'function'
  );
}
