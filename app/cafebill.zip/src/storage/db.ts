import { openDB, type DBSchema, type IDBPDatabase } from 'idb';
import { DEFAULT_TRANSLATIONS } from '../i18n/translations';
import type {
  AppDataState,
  AppPreferences,
  BackupPayload,
  BankAccount,
  BusinessProfile,
  Customer,
  Invoice,
  OpenTableOrder,
  QuickMenuItem,
  TranslationMap,
} from '../types/invoice';

interface StoredWorkspaceRecord {
  userId: string;
  data: AppDataState;
  pendingSync: boolean;
  updatedAt: string;
}

interface CafeBillUserDBSchema extends DBSchema {
  workspaces: {
    key: string;
    value: StoredWorkspaceRecord;
  };
}

const DB_NAME = 'cafebill-user-workspaces';
const DB_VERSION = 1;

export const CATEGORY_IMAGES = {
  Coffee: '/src/assets/images/menu_coffee_latte_1795184084752.jpg',
  Tea: '/src/assets/images/menu_tea_cup_1795184084305.jpg',
  'Cold Drinks': '/src/assets/images/menu_iced_drink_1795184083055.jpg',
  Food: '/src/assets/images/menu_cafe_food_1795184083451.jpg',
  Desserts: '/src/assets/images/menu_dessert_cake_1795184083679.jpg',
  Others: '/src/assets/images/menu_water_bottle_1795184083712.jpg',
} as const;

export const DEFAULT_BUSINESS_PROFILE: BusinessProfile = {
  name: 'CafePOS',
  address: "Male', Maldives",
  phone: '',
  email: '',
  socialHandle: '',
  registrationNumber: '',
  defaultFooterEn: 'Thank you for visiting! We appreciate your business.',
  defaultFooterDv: 'ޒިޔާރަތް ކުރެއްވި ކަމަށްޓަކައި ޝުކުރިއްޔާ!',
};

export const DEFAULT_PREFERENCES: AppPreferences = {
  invoicePrefix: 'INV-',
  nextInvoiceSequence: 1,
  defaultLanguage: 'en',
  defaultCurrency: 'MVR',
  defaultLayoutStyle: 'pos',
  defaultPosWidth: '80mm',
  defaultShowBankDetails: true,
  exchangeRateUsdToMvr: 15.42,
};

export const DEFAULT_QUICK_MENU: QuickMenuItem[] = [
  {
    id: 'qm_def_gulha',
    nameEn: 'Gulha',
    nameDv: 'ގުޅަ',
    category: 'Food',
    imageUrl: '/assets/aistudio/Gulha_e0473dac.jpg',
    priceMvr: 5,
    priceUsd: 0.35,
  },
  {
    id: 'qm_def_bajiyaa',
    nameEn: 'Bajiyaa',
    nameDv: 'ބަޖިޔާ',
    category: 'Food',
    imageUrl: '/assets/aistudio/Bajiya_1126ceb2.jpg',
    priceMvr: 8,
    priceUsd: 0.55,
  },
  {
    id: 'qm_def_kavaabu',
    nameEn: 'Kavaabu',
    nameDv: 'ކަވާބު',
    category: 'Food',
    imageUrl: '/assets/aistudio/Kavaabu_4c8ad556.jpg',
    priceMvr: 8,
    priceUsd: 0.55,
  },
  {
    id: 'qm_def_masroshi',
    nameEn: 'Masroshi',
    nameDv: 'މަސްރޮށި',
    category: 'Food',
    imageUrl: '/assets/aistudio/Masroshi_85badbd6.jpg',
    priceMvr: 10,
    priceUsd: 0.65,
  },
  {
    id: 'qm_def_kulhi_boakiba',
    nameEn: 'Kulhi Boakiba',
    nameDv: 'ކުޅި ބޯކިބާ',
    category: 'Food',
    imageUrl: '/assets/aistudio/Kulhi_Boakiba_9c4ba751.jpg',
    priceMvr: 10,
    priceUsd: 0.65,
  },
  {
    id: 'qm_def_bis_keemiya',
    nameEn: 'Bis Keemiya',
    nameDv: 'ބިސް ކީމިޔާ',
    category: 'Food',
    imageUrl: '/assets/aistudio/Bis_Keemiya_0a5b8a54.jpg',
    priceMvr: 12,
    priceUsd: 0.8,
  },
  {
    id: 'qm_def_sosage_rolls',
    nameEn: 'Sosage Rolls',
    nameDv: 'ސޮސެޖް ރޯލްސް',
    category: 'Food',
    imageUrl: '/assets/aistudio/Bis_Keemiya_0a5b8a54.jpg',
    priceMvr: 15,
    priceUsd: 1.0,
  },
  {
    id: 'qm_def_cake',
    nameEn: 'Cake',
    nameDv: 'ކޭކް',
    category: 'Desserts',
    imageUrl: CATEGORY_IMAGES.Desserts,
    priceMvr: 25,
    priceUsd: 1.65,
  },
  {
    id: 'qm_def_foni_boakiba',
    nameEn: 'Foni Boakiba',
    nameDv: 'ފޮނި ބޯކިބާ',
    category: 'Desserts',
    imageUrl: '/assets/aistudio/Foni_Boakiba_80e4434e.jpg',
    priceMvr: 10,
    priceUsd: 0.65,
  },
  {
    id: 'qm_def_black_tea',
    nameEn: 'Black Tea',
    nameDv: 'ކަޅު ސައި',
    category: 'Tea',
    imageUrl: '/assets/aistudio/Black_Tea_a2176733.jpg',
    priceMvr: 8,
    priceUsd: 0.55,
  },
  {
    id: 'qm_def_milk_tea',
    nameEn: 'Milk Tea',
    nameDv: 'ކިރު ސައި',
    category: 'Tea',
    imageUrl: '/assets/aistudio/Milk_Tea_39d7f8b0.jpg',
    priceMvr: 12,
    priceUsd: 0.8,
  },
  {
    id: 'qm_def_black_coffee_nescafe',
    nameEn: 'Black Coffee (Nescafe)',
    nameDv: 'ކަޅު ކޮފީ',
    category: 'Coffee',
    imageUrl: '/assets/aistudio/Black_Coffee_5c4b8eb1.jpg',
    priceMvr: 12,
    priceUsd: 0.8,
  },
  {
    id: 'qm_def_lavaza_black',
    nameEn: 'Lavaza Black',
    nameDv: 'ލަވާޒާ ބްލެކް ކޮފީ',
    category: 'Coffee',
    imageUrl: '/assets/aistudio/Lavaza_Coffee_19a94f11.jpg',
    priceMvr: 30,
    priceUsd: 1.95,
  },
  {
    id: 'qm_def_lavaza_milk',
    nameEn: 'Lavaza Milk',
    nameDv: 'ލަވާޒާ މިލްކު ކޮފީ',
    category: 'Coffee',
    imageUrl: '/assets/aistudio/Lavaza_Coffee_19a94f11.jpg',
    priceMvr: 38,
    priceUsd: 2.5,
  },
  {
    id: 'qm_def_milk_coffee_nescafe',
    nameEn: 'Milk Coffee (Nescafe)',
    nameDv: 'ކިރު ކޮފީ',
    category: 'Coffee',
    imageUrl: '/assets/aistudio/Milk_Tea_39d7f8b0.jpg',
    priceMvr: 15,
    priceUsd: 1.0,
  },
  {
    id: 'qm_def_water_500ml',
    nameEn: 'Bottled Water 500ML',
    nameDv: 'ފެންފުޅި ކުޑަ',
    category: 'Others',
    imageUrl: '/assets/aistudio/Botteld_Water_52d006b4.jpg',
    priceMvr: 8,
    priceUsd: 0.55,
  },
  {
    id: 'qm_def_water_1l',
    nameEn: 'Bottled Water 1L',
    nameDv: 'ފެންފުޅި ބޮޑު',
    category: 'Others',
    imageUrl: '/assets/aistudio/Botteld_Water_52d006b4.jpg',
    priceMvr: 15,
    priceUsd: 1.0,
  },
  {
    id: 'qm_def_nuts',
    nameEn: 'Nuts',
    nameDv: 'ބިލެތް އަރި',
    category: 'Others',
    imageUrl: CATEGORY_IMAGES.Others,
    priceMvr: 15,
    priceUsd: 1.0,
  },
  {
    id: 'qm_def_petties',
    nameEn: 'Petties',
    nameDv: 'ޕެޓީސް',
    category: 'Food',
    imageUrl: '/assets/aistudio/Patties_20a673f1.jpg',
    priceMvr: 15,
    priceUsd: 1.0,
  },
  {
    id: 'qm_def_coke',
    nameEn: 'Coke',
    category: 'Cold Drinks',
    imageUrl: '/assets/aistudio/Coke_e5f0d5fc.jpg',
    priceMvr: 20,
    priceUsd: 1.3,
  },
  {
    id: 'qm_def_fanta',
    nameEn: 'Fanta',
    category: 'Cold Drinks',
    imageUrl: '/assets/aistudio/Fanta_e7d77c8f.jpg',
    priceMvr: 20,
    priceUsd: 1.3,
  },
  {
    id: 'qm_def_xl_energy',
    nameEn: 'XL Energy Drink',
    category: 'Cold Drinks',
    imageUrl: '/assets/aistudio/XL_Energy_Drink_1be5d8f3.jpg',
    priceMvr: 25,
    priceUsd: 1.65,
  },
];

const DEFAULT_IMAGE_BY_ID = new Map<string, string>(
  DEFAULT_QUICK_MENU.map((item) => [item.id, item.imageUrl || CATEGORY_IMAGES[item.category || 'Others']])
);

const LEGACY_STARTER_IDS = new Set([
  'qm_coffee_1',
  'qm_coffee_2',
  'qm_coffee_3',
  'qm_cold_1',
  'qm_cold_2',
  'qm_tea_1',
  'qm_tea_2',
  'qm_food_1',
  'qm_food_2',
  'qm_dessert_1',
  'qm_dessert_2',
  'qm_others_1',
  'qm_others_2',
]);

export function createEmptyAppData(partial?: Partial<AppDataState>): AppDataState {
  const rawProfile: BusinessProfile = {
    ...DEFAULT_BUSINESS_PROFILE,
    ...(partial?.businessProfile || {}),
  };
  const businessProfile: BusinessProfile = {
    ...rawProfile,
    name:
      rawProfile.name === 'CafeBill'
        ? 'CafePOS'
        : rawProfile.name === 'CafeBill Demo Café'
        ? 'CafePOS Demo Café'
        : rawProfile.name,
  };
  const bankAccounts: BankAccount[] = Array.isArray(partial?.bankAccounts)
    ? partial!.bankAccounts
    : [];
  const translations: TranslationMap = {
    en: { ...DEFAULT_TRANSLATIONS.en, ...(partial?.translations?.en || {}) },
    dv: { ...DEFAULT_TRANSLATIONS.dv, ...(partial?.translations?.dv || {}) },
  };
  const preferences: AppPreferences = {
    ...DEFAULT_PREFERENCES,
    ...(partial?.preferences || {}),
  };
  const incomingMenu = partial?.quickMenuItems;
  const isUntouchedLegacyStarter =
    Array.isArray(incomingMenu) &&
    incomingMenu.length === LEGACY_STARTER_IDS.size &&
    incomingMenu.every((item) => LEGACY_STARTER_IDS.has(item.id));

  const quickMenuItems: QuickMenuItem[] =
    Array.isArray(incomingMenu) && !isUntouchedLegacyStarter
      ? incomingMenu.map((item) => {
          const category = item.category || 'Others';
          const defaultImg = DEFAULT_IMAGE_BY_ID.get(item.id);
          const shouldUpgradePlaceholder =
            Boolean(defaultImg) &&
            (!item.imageUrl || item.imageUrl.startsWith('/src/assets/images/menu_'));
          return {
            ...item,
            category,
            imageUrl: shouldUpgradePlaceholder
              ? defaultImg!
              : item.imageUrl || CATEGORY_IMAGES[category],
          };
        })
      : DEFAULT_QUICK_MENU;
  const customers: Customer[] = Array.isArray(partial?.customers)
    ? [...partial!.customers].sort((a, b) => a.name.localeCompare(b.name))
    : [];
  const invoices: Invoice[] = Array.isArray(partial?.invoices)
    ? [...partial!.invoices].sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''))
    : [];
  const openOrders: OpenTableOrder[] = Array.isArray(partial?.openOrders)
    ? partial!.openOrders
    : [];

  return {
    businessProfile,
    bankAccounts,
    translations,
    preferences,
    quickMenuItems,
    customers,
    invoices,
    openOrders,
  };
}

let dbPromise: Promise<IDBPDatabase<CafeBillUserDBSchema>> | null = null;

function getDB(): Promise<IDBPDatabase<CafeBillUserDBSchema>> {
  if (!dbPromise) {
    dbPromise = openDB<CafeBillUserDBSchema>(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('workspaces')) {
          db.createObjectStore('workspaces', { keyPath: 'userId' });
        }
      },
    });
  }
  return dbPromise;
}

export async function loadUserLocalWorkspace(
  userId: string
): Promise<StoredWorkspaceRecord | null> {
  const db = await getDB();
  const rec = await db.get('workspaces', userId);
  if (!rec) return null;
  return {
    ...rec,
    data: createEmptyAppData(rec.data),
  };
}

export async function saveUserLocalWorkspace(
  userId: string,
  data: AppDataState,
  pendingSync: boolean
): Promise<void> {
  const db = await getDB();
  await db.put('workspaces', {
    userId,
    data: createEmptyAppData(data),
    pendingSync,
    updatedAt: new Date().toISOString(),
  });
}

export async function deleteUserLocalWorkspace(userId: string): Promise<void> {
  const db = await getDB();
  await db.delete('workspaces', userId);
}

export function createBackupPayloadFromState(data: AppDataState): BackupPayload {
  return {
    version: 1,
    exportedAt: new Date().toISOString(),
    data,
  };
}

export function mergeOrReplaceBackup(
  current: AppDataState,
  payload: BackupPayload,
  mode: 'replace' | 'merge'
): AppDataState {
  if (!payload || !payload.data) {
    throw new Error('Invalid backup file format.');
  }
  const incoming = payload.data;

  if (mode === 'replace') {
    return createEmptyAppData(incoming);
  }

  const custMap = new Map<string, Customer>();
  for (const c of current.customers) custMap.set(c.id, c);
  for (const c of incoming.customers || []) {
    if (c && c.id) custMap.set(c.id, c);
  }

  const invMap = new Map<string, Invoice>();
  for (const i of current.invoices) invMap.set(i.id, i);
  for (const i of incoming.invoices || []) {
    if (i && i.id) invMap.set(i.id, i);
  }

  const orderMap = new Map<string, OpenTableOrder>();
  for (const o of current.openOrders) orderMap.set(o.id, o);
  for (const o of incoming.openOrders || []) {
    if (o && o.id) orderMap.set(o.id, o);
  }

  return createEmptyAppData({
    businessProfile: incoming.businessProfile
      ? { ...current.businessProfile, ...incoming.businessProfile }
      : current.businessProfile,
    bankAccounts:
      Array.isArray(incoming.bankAccounts) && incoming.bankAccounts.length > 0
        ? incoming.bankAccounts
        : current.bankAccounts,
    translations: incoming.translations || current.translations,
    preferences: incoming.preferences
      ? { ...current.preferences, ...incoming.preferences }
      : current.preferences,
    quickMenuItems:
      Array.isArray(incoming.quickMenuItems) && incoming.quickMenuItems.length > 0
        ? incoming.quickMenuItems
        : current.quickMenuItems,
    customers: Array.from(custMap.values()),
    invoices: Array.from(invMap.values()),
    openOrders: Array.from(orderMap.values()),
  });
}
