export interface AuthUser {
  id: string;
  fullName: string;
  countryCode: string;
  phoneNumber: string;
  normalizedPhone: string;
  onboardingCompleted: boolean;
  createdAt: string;
  isGuest?: boolean;
}

export const GUEST_USER: AuthUser = {
  id: 'guest_demo',
  fullName: 'Guest Demo',
  countryCode: '+960',
  phoneNumber: '',
  normalizedPhone: 'Local Demo Mode',
  onboardingCompleted: true,
  createdAt: '',
  isGuest: true,
};

export type SupportReportType = 'bug' | 'issue' | 'feedback';

export interface SupportReportInput {
  type: SupportReportType;
  category?: string;
  title: string;
  description: string;
  contactInfo?: string;
  screenshotDataUrl?: string;
  appVersion?: string;
  deviceInfo?: string;
}

export interface SupportReportSummary {
  id: string;
  type: SupportReportType;
  category?: string;
  title: string;
  description: string;
  createdAt: string;
}

export interface CountryCodeOption {
  code: string;
  label: string;
}

export const COUNTRY_CODES: CountryCodeOption[] = [
  { code: '+960', label: 'Maldives (+960)' },
  { code: '+94', label: 'Sri Lanka (+94)' },
  { code: '+91', label: 'India (+91)' },
  { code: '+60', label: 'Malaysia (+60)' },
  { code: '+65', label: 'Singapore (+65)' },
  { code: '+971', label: 'UAE (+971)' },
  { code: '+966', label: 'Saudi Arabia (+966)' },
  { code: '+44', label: 'UK (+44)' },
  { code: '+1', label: 'USA / Canada (+1)' },
  { code: '+61', label: 'Australia (+61)' },
];

export const APP_VERSION = '1.0.0';
export const SUPPORT_CONTACT_NAME = 'and4yy';
export const SUPPORT_EMAIL = 'and4yy@mail.com';
