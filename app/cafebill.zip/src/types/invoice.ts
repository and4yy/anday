export type InvoiceLanguage = 'en' | 'dv';
export type CurrencyCode = 'MVR' | 'USD';
export type PaymentStatus = 'UNPAID' | 'PAID' | 'PARTIALLY_PAID';
export type PaymentMethod = 'cash' | 'bank_transfer' | 'card' | 'mobile_pay' | 'other';
export type InvoiceLayoutStyle = 'pos' | 'a4';
export type PosWidth = '58mm' | '80mm';
export type DiscountType = 'fixed' | 'percent';
export type MenuCategory = 'Coffee' | 'Tea' | 'Cold Drinks' | 'Food' | 'Desserts' | 'Others';

export interface InvoiceLineItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string; // YYYY-MM-DD
  tableName?: string;
  customerId?: string;
  customerName: string;
  customerPhone?: string;
  customerEmail?: string;
  language: InvoiceLanguage;
  currency: CurrencyCode;
  layoutStyle: InvoiceLayoutStyle;
  posWidth: PosWidth;
  items: InvoiceLineItem[];
  discountType: DiscountType;
  discountValue: number;
  additionalChargeLabel?: string;
  additionalChargeAmount: number;
  notes?: string;
  paymentInstructions?: string;
  showBankDetails: boolean;
  selectedBankIds: string[];
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  paymentDate?: string;
  amountPaid: number;
  showConversionReference: boolean;
  exchangeRateUsed?: number;
  footerMessage?: string;
  createdAt: string;
  updatedAt: string;
}

export interface OpenTableOrder {
  id: string; // e.g. 'T1', 'T2', 'Takeaway', or custom table key
  tableName: string;
  language: InvoiceLanguage;
  currency: CurrencyCode;
  customerId?: string;
  customerName: string;
  customerPhone?: string;
  customerEmail?: string;
  items: InvoiceLineItem[];
  discountType: DiscountType;
  discountValue: number;
  additionalChargeLabel?: string;
  additionalChargeAmount: number;
  notes?: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  address?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BankAccount {
  id: string;
  bankName: string;
  accountHolderName: string;
  accountNumber: string;
  branch?: string;
  instructions?: string;
  isDefault?: boolean;
}

export interface BusinessProfile {
  name: string;
  logoDataUrl?: string;
  address?: string;
  phone?: string;
  email?: string;
  socialHandle?: string;
  registrationNumber?: string;
  defaultFooterEn: string;
  defaultFooterDv: string;
}

export interface InvoiceLabels {
  invoiceTitle: string;
  receiptTitle: string;
  invoiceNumber: string;
  date: string;
  table: string;
  customer: string;
  phone: string;
  email: string;
  description: string;
  quantity: string;
  unitPrice: string;
  amount: string;
  subtotal: string;
  discount: string;
  additionalCharges: string;
  total: string;
  paymentMethod: string;
  paymentStatus: string;
  paid: string;
  unpaid: string;
  partiallyPaid: string;
  amountPaid: string;
  balanceDue: string;
  paymentDate: string;
  bankTransferDetails: string;
  bankName: string;
  accountName: string;
  accountNumber: string;
  branch: string;
  notes: string;
  paymentInstructions: string;
  thankYou: string;
  cash: string;
  bankTransfer: string;
  card: string;
  mobilePay: string;
  other: string;
  regNo: string;
  convertedRef: string;
}

export interface TranslationMap {
  en: InvoiceLabels;
  dv: InvoiceLabels;
}

export interface QuickMenuItem {
  id: string;
  nameEn: string;
  nameDv?: string;
  category: MenuCategory;
  imageUrl?: string;
  priceMvr: number;
  priceUsd: number;
}

export interface AppPreferences {
  invoicePrefix: string;
  nextInvoiceSequence: number;
  defaultLanguage: InvoiceLanguage;
  defaultCurrency: CurrencyCode;
  defaultLayoutStyle: InvoiceLayoutStyle;
  defaultPosWidth: PosWidth;
  defaultShowBankDetails: boolean;
  exchangeRateUsdToMvr: number;
  customFontName?: string;
  customFontDataUrl?: string;
}

export interface AppDataState {
  businessProfile: BusinessProfile;
  bankAccounts: BankAccount[];
  translations: TranslationMap;
  preferences: AppPreferences;
  quickMenuItems: QuickMenuItem[];
  customers: Customer[];
  invoices: Invoice[];
  openOrders: OpenTableOrder[];
}

export interface BackupPayload {
  version: number;
  exportedAt: string;
  data: AppDataState;
}
