import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Copy,
  Edit3,
  Eye,
  FilePlus2,
  Plus,
  Search,
  Trash2,
  UserPlus,
  Users,
} from 'lucide-react';
import type {
  CurrencyCode,
  Customer,
  Invoice,
  PaymentStatus,
} from '../types/invoice';
import {
  createId,
  type DateFilterPreset,
  formatCurrency,
  formatDateReadable,
  getInvoiceComputedTotals,
  isDateInFilter,
} from '../utils/calculations';
import { ConfirmModal } from './ConfirmModal';

interface InvoicesViewProps {
  invoices: Invoice[];
  customers: Customer[];
  onCreateInvoice: (preselectedCustomer?: Customer) => void;
  onEditInvoice: (invoice: Invoice) => void;
  onDuplicateInvoice: (invoice: Invoice) => void;
  onPreviewInvoice: (invoice: Invoice) => void;
  onMarkPaid: (invoice: Invoice) => void;
  onDeleteInvoice: (id: string) => void;
  onSaveCustomer: (customer: Customer) => void;
  onDeleteCustomer: (id: string) => void;
}

export const InvoicesView: React.FC<InvoicesViewProps> = ({
  invoices,
  customers,
  onCreateInvoice,
  onEditInvoice,
  onDuplicateInvoice,
  onPreviewInvoice,
  onMarkPaid,
  onDeleteInvoice,
  onSaveCustomer,
  onDeleteCustomer,
}) => {
  const [subTab, setSubTab] = useState<'invoices' | 'customers'>('invoices');

  // Invoice filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | PaymentStatus>('ALL');
  const [currencyFilter, setCurrencyFilter] = useState<'ALL' | CurrencyCode>('ALL');
  const [dateFilter, setDateFilter] = useState<DateFilterPreset>('all');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');
  const [pendingDeleteInvoice, setPendingDeleteInvoice] = useState<Invoice | null>(null);

  // Customer management
  const [customerSearch, setCustomerSearch] = useState('');
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [showCustomerForm, setShowCustomerForm] = useState(false);
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [custEmail, setCustEmail] = useState('');
  const [custAddress, setCustAddress] = useState('');
  const [pendingDeleteCustomer, setPendingDeleteCustomer] = useState<Customer | null>(null);

  const filteredInvoices = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return invoices.filter((inv) => {
      if (statusFilter !== 'ALL' && inv.paymentStatus !== statusFilter) return false;
      if (currencyFilter !== 'ALL' && inv.currency !== currencyFilter) return false;
      if (!isDateInFilter(inv.date, dateFilter, customStart, customEnd)) return false;
      if (q) {
        const matchNum = inv.invoiceNumber.toLowerCase().includes(q);
        const matchName = (inv.customerName || '').toLowerCase().includes(q);
        const matchPhone = (inv.customerPhone || '').toLowerCase().includes(q);
        if (!matchNum && !matchName && !matchPhone) return false;
      }
      return true;
    });
  }, [invoices, searchQuery, statusFilter, currencyFilter, dateFilter, customStart, customEnd]);

  const filteredCustomers = useMemo(() => {
    const q = customerSearch.trim().toLowerCase();
    if (!q) return customers;
    return customers.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        (c.phone || '').toLowerCase().includes(q) ||
        (c.email || '').toLowerCase().includes(q)
    );
  }, [customers, customerSearch]);

  const openNewCustomer = () => {
    setEditingCustomer(null);
    setCustName('');
    setCustPhone('');
    setCustEmail('');
    setCustAddress('');
    setShowCustomerForm(true);
  };

  const openEditCustomer = (c: Customer) => {
    setEditingCustomer(c);
    setCustName(c.name);
    setCustPhone(c.phone || '');
    setCustEmail(c.email || '');
    setCustAddress(c.address || '');
    setShowCustomerForm(true);
  };

  const submitCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!custName.trim()) return;
    const now = new Date().toISOString();
    const record: Customer = {
      id: editingCustomer?.id || createId('cust'),
      name: custName.trim(),
      phone: custPhone.trim() || undefined,
      email: custEmail.trim() || undefined,
      address: custAddress.trim() || undefined,
      createdAt: editingCustomer?.createdAt || now,
      updatedAt: now,
    };
    onSaveCustomer(record);
    setShowCustomerForm(false);
    setEditingCustomer(null);
  };

  return (
    <div className="space-y-5">
      {/* Top Sub-Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex items-center gap-1 rounded-xl border border-stone-200 bg-white p-1">
          <button
            type="button"
            onClick={() => setSubTab('invoices')}
            className={`rounded-lg px-4 py-2 text-sm font-semibold transition-colors min-h-[40px] ${
              subTab === 'invoices'
                ? 'bg-[#2C1B18] text-white'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            Invoices ({invoices.length})
          </button>
          <button
            type="button"
            onClick={() => setSubTab('customers')}
            className={`rounded-lg px-4 py-2 text-sm font-semibold transition-colors min-h-[40px] ${
              subTab === 'customers'
                ? 'bg-[#2C1B18] text-white'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            Customers ({customers.length})
          </button>
        </div>

        {subTab === 'invoices' ? (
          <button
            type="button"
            onClick={() => onCreateInvoice()}
            className="inline-flex items-center gap-2 rounded-xl bg-[#2C1B18] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#3E2723] min-h-[44px]"
          >
            <Plus className="h-4 w-4" />
            <span>New Invoice</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={openNewCustomer}
            className="inline-flex items-center gap-2 rounded-xl bg-[#2C1B18] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#3E2723] min-h-[44px]"
          >
            <UserPlus className="h-4 w-4" />
            <span>Add Customer</span>
          </button>
        )}
      </div>

      {subTab === 'invoices' ? (
        <>
          {/* Search & Filters */}
          <div className="rounded-2xl border border-stone-200/90 bg-white p-4 space-y-3">
            <div className="relative">
              <Search className="pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-stone-400" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search invoice number or customer name..."
                className="w-full rounded-xl border border-stone-200 bg-stone-50/50 py-2.5 pr-4 pl-10 text-sm text-[#1C1917] placeholder:text-stone-400 focus:border-[#2C1B18] focus:bg-white focus:outline-none min-h-[44px]"
              />
            </div>

            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as 'ALL' | PaymentStatus)}
                aria-label="Filter by payment status"
                className="rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-semibold text-[#1C1917] min-h-[42px]"
              >
                <option value="ALL">All Statuses</option>
                <option value="PAID">Paid</option>
                <option value="PARTIALLY_PAID">Partially Paid</option>
                <option value="UNPAID">Unpaid</option>
              </select>

              <select
                value={currencyFilter}
                onChange={(e) => setCurrencyFilter(e.target.value as 'ALL' | CurrencyCode)}
                aria-label="Filter by currency"
                className="rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-semibold text-[#1C1917] min-h-[42px]"
              >
                <option value="ALL">All Currencies (MVR & USD)</option>
                <option value="MVR">MVR Only</option>
                <option value="USD">USD Only</option>
              </select>

              <select
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value as DateFilterPreset)}
                aria-label="Filter by date"
                className="rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-semibold text-[#1C1917] min-h-[42px]"
              >
                <option value="all">All Dates</option>
                <option value="today">Today</option>
                <option value="week">This Week</option>
                <option value="month">This Month</option>
                <option value="custom">Custom Range</option>
              </select>
            </div>

            {dateFilter === 'custom' && (
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <input
                  type="date"
                  value={customStart}
                  onChange={(e) => setCustomStart(e.target.value)}
                  className="rounded-xl border border-stone-200 px-3 py-2 text-xs min-h-[40px]"
                />
                <span className="text-xs text-stone-500">to</span>
                <input
                  type="date"
                  value={customEnd}
                  onChange={(e) => setCustomEnd(e.target.value)}
                  className="rounded-xl border border-stone-200 px-3 py-2 text-xs min-h-[40px]"
                />
              </div>
            )}
          </div>

          {/* Invoice List */}
          {filteredInvoices.length === 0 ? (
            <div className="rounded-2xl border border-stone-200/90 bg-white px-6 py-12 text-center">
              <p className="text-sm font-semibold text-[#1C1917]">No matching invoices</p>
              <p className="mt-1 text-xs text-stone-500">
                Try clearing your search or create a new invoice.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredInvoices.map((inv) => {
                const totals = getInvoiceComputedTotals(inv);
                return (
                  <div
                    key={inv.id}
                    className="rounded-2xl border border-stone-200/90 bg-white p-4 sm:p-5"
                  >
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
                          <span className="font-mono-num text-sm font-bold text-[#2C1B18]">
                            {inv.invoiceNumber}
                          </span>
                          <span className="text-stone-300" aria-hidden="true">
                            ·
                          </span>
                          <span dir="auto" className="text-sm font-semibold text-[#1C1917] break-words">
                            {inv.customerName || 'Walk-in Customer'}
                          </span>
                        </div>

                        <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-stone-500">
                          <span>{formatDateReadable(inv.date)}</span>
                          <span aria-hidden="true">·</span>
                          <span>{inv.language === 'dv' ? 'ދިވެހި' : 'English'}</span>
                          <span aria-hidden="true">·</span>
                          <span>{inv.layoutStyle === 'pos' ? `POS ${inv.posWidth}` : 'A4'}</span>
                          <span aria-hidden="true">·</span>
                          <span
                            className={`inline-flex items-center gap-1 font-semibold ${
                              inv.paymentStatus === 'PAID'
                                ? 'text-emerald-700'
                                : inv.paymentStatus === 'PARTIALLY_PAID'
                                ? 'text-amber-700'
                                : 'text-stone-700'
                            }`}
                          >
                            {inv.paymentStatus === 'PAID' ? (
                              <CheckCircle2 className="h-3.5 w-3.5" />
                            ) : inv.paymentStatus === 'PARTIALLY_PAID' ? (
                              <Clock className="h-3.5 w-3.5" />
                            ) : (
                              <AlertCircle className="h-3.5 w-3.5" />
                            )}
                            {inv.paymentStatus === 'PAID'
                              ? 'PAID'
                              : inv.paymentStatus === 'PARTIALLY_PAID'
                              ? `PARTIAL · Due ${formatCurrency(totals.balanceDue, inv.currency)}`
                              : 'UNPAID'}
                          </span>
                        </div>
                      </div>

                      <div className="text-start sm:text-end shrink-0">
                        <div className="font-mono-num text-lg font-bold text-[#1C1917]">
                          {formatCurrency(totals.grandTotal, inv.currency)}
                        </div>
                        {inv.paymentStatus === 'PARTIALLY_PAID' && (
                          <div className="font-mono-num text-xs text-emerald-700">
                            Paid: {formatCurrency(totals.amountPaid, inv.currency)}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Action Row */}
                    <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-stone-100 pt-3">
                      <button
                        type="button"
                        onClick={() => onPreviewInvoice(inv)}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-[#2C1B18] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#3E2723] min-h-[40px]"
                      >
                        <Eye className="h-3.5 w-3.5" />
                        <span>Preview / Share PNG</span>
                      </button>

                      {inv.paymentStatus !== 'PAID' && (
                        <button
                          type="button"
                          onClick={() => onMarkPaid(inv)}
                          className="inline-flex items-center gap-1.5 rounded-xl border border-emerald-700/30 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-800 hover:bg-emerald-100 min-h-[40px]"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span>Mark Paid</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => onEditInvoice(inv)}
                        className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 min-h-[40px]"
                      >
                        <Edit3 className="h-3.5 w-3.5" />
                        <span>Edit</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onDuplicateInvoice(inv)}
                        className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 min-h-[40px]"
                      >
                        <Copy className="h-3.5 w-3.5" />
                        <span>Duplicate</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPendingDeleteInvoice(inv)}
                        className="ml-auto inline-flex items-center gap-1 rounded-xl border border-rose-200 bg-white px-3 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-50 min-h-[40px]"
                        aria-label={`Delete ${inv.invoiceNumber}`}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span className="hidden sm:inline">Delete</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      ) : (
        <>
          {/* Customer Search */}
          <div className="rounded-2xl border border-stone-200/90 bg-white p-4">
            <div className="relative">
              <Search className="pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-stone-400" />
              <input
                type="search"
                value={customerSearch}
                onChange={(e) => setCustomerSearch(e.target.value)}
                placeholder="Search saved customers by name, phone, or email..."
                className="w-full rounded-xl border border-stone-200 bg-stone-50/50 py-2.5 pr-4 pl-10 text-sm text-[#1C1917] placeholder:text-stone-400 focus:border-[#2C1B18] focus:bg-white focus:outline-none min-h-[44px]"
              />
            </div>
          </div>

          {showCustomerForm && (
            <form
              onSubmit={submitCustomer}
              className="rounded-2xl border border-stone-200 bg-white p-5 space-y-4"
            >
              <h3 className="text-base font-bold text-[#1C1917]">
                {editingCustomer ? 'Edit Customer' : 'Add New Customer'}
              </h3>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-semibold text-stone-600 mb-1">
                    Customer Name *
                  </label>
                  <input
                    type="text"
                    required
                    dir="auto"
                    value={custName}
                    onChange={(e) => setCustName(e.target.value)}
                    placeholder="e.g. Aishath / Ahmed"
                    className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-600 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    dir="ltr"
                    value={custPhone}
                    onChange={(e) => setCustPhone(e.target.value)}
                    placeholder="+960 777-0000"
                    className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-600 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    dir="ltr"
                    value={custEmail}
                    onChange={(e) => setCustEmail(e.target.value)}
                    placeholder="customer@example.com"
                    className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-600 mb-1">
                    Address (Optional)
                  </label>
                  <input
                    type="text"
                    dir="auto"
                    value={custAddress}
                    onChange={(e) => setCustAddress(e.target.value)}
                    placeholder="Male' / Hulhumale'"
                    className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                  />
                </div>
              </div>
              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCustomerForm(false)}
                  className="rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-sm font-semibold text-stone-700 hover:bg-stone-50 min-h-[44px]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-[#2C1B18] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#3E2723] min-h-[44px]"
                >
                  Save Customer
                </button>
              </div>
            </form>
          )}

          {filteredCustomers.length === 0 ? (
            <div className="rounded-2xl border border-stone-200/90 bg-white px-6 py-12 text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-stone-100 text-stone-500">
                <Users className="h-6 w-6" />
              </div>
              <p className="mt-3 text-sm font-semibold text-[#1C1917]">No customers saved yet</p>
              <p className="mt-1 text-xs text-stone-500">
                Save regular customers to auto-fill their details on future invoices.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-stone-100 rounded-2xl border border-stone-200/90 bg-white overflow-hidden">
              {filteredCustomers.map((c) => (
                <div
                  key={c.id}
                  className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div className="min-w-0">
                    <div dir="auto" className="text-sm font-bold text-[#1C1917] break-words">
                      {c.name}
                    </div>
                    <div className="mt-0.5 flex flex-wrap items-center gap-x-2 text-xs text-stone-500">
                      {c.phone && <span className="font-mono-num">{c.phone}</span>}
                      {c.phone && c.email && <span aria-hidden="true">·</span>}
                      {c.email && <span>{c.email}</span>}
                      {c.address && (
                        <>
                          {(c.phone || c.email) && <span aria-hidden="true">·</span>}
                          <span dir="auto">{c.address}</span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onCreateInvoice(c)}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-[#2C1B18] px-3 py-2 text-xs font-semibold text-white hover:bg-[#3E2723] min-h-[40px]"
                    >
                      <FilePlus2 className="h-3.5 w-3.5" />
                      <span>Bill Customer</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => openEditCustomer(c)}
                      className="inline-flex items-center gap-1 rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 min-h-[40px]"
                    >
                      <Edit3 className="h-3.5 w-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPendingDeleteCustomer(c)}
                      className="inline-flex items-center gap-1 rounded-xl border border-rose-200 bg-white px-3 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-50 min-h-[40px]"
                      aria-label={`Delete ${c.name}`}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      <ConfirmModal
        open={Boolean(pendingDeleteInvoice)}
        title="Delete Invoice?"
        message={`Delete invoice ${pendingDeleteInvoice?.invoiceNumber || ''}? This cannot be undone.`}
        confirmLabel="Delete Invoice"
        destructive
        onConfirm={() => {
          if (pendingDeleteInvoice) onDeleteInvoice(pendingDeleteInvoice.id);
          setPendingDeleteInvoice(null);
        }}
        onCancel={() => setPendingDeleteInvoice(null)}
      />

      <ConfirmModal
        open={Boolean(pendingDeleteCustomer)}
        title="Delete Customer?"
        message={`Remove ${pendingDeleteCustomer?.name || ''} from saved customers? Existing invoices will keep their saved customer details.`}
        confirmLabel="Delete Customer"
        destructive
        onConfirm={() => {
          if (pendingDeleteCustomer) onDeleteCustomer(pendingDeleteCustomer.id);
          setPendingDeleteCustomer(null);
        }}
        onCancel={() => setPendingDeleteCustomer(null)}
      />
    </div>
  );
};
