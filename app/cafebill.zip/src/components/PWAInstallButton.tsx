import React, { useState } from 'react';
import { Download, Share, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'compact' | 'full';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ variant = 'compact' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={() => void install()}
        className={
          variant === 'full'
            ? 'inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#2C1B18] px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#3E2723] min-h-[44px]'
            : 'inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs font-semibold text-[#2C1B18] transition-colors hover:bg-stone-50 whitespace-nowrap shrink-0 min-h-[40px]'
        }
      >
        <Download className="h-4 w-4 shrink-0" />
        <span>Install App</span>
      </button>
    );
  }

  if (isIOS || variant === 'full') {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowGuideModal(true)}
          className={
            variant === 'full'
              ? 'inline-flex w-full items-center justify-center gap-2 rounded-xl border border-stone-300 bg-white px-4 py-3 text-sm font-semibold text-[#2C1B18] transition-colors hover:bg-stone-50 min-h-[44px]'
              : 'inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs font-semibold text-[#2C1B18] transition-colors hover:bg-stone-50 whitespace-nowrap shrink-0 min-h-[40px]'
          }
        >
          <Smartphone className="h-4 w-4 shrink-0" />
          <span>{isIOS ? 'Install on iPhone' : 'Add to Home Screen'}</span>
        </button>

        {showGuideModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs">
            <div className="w-full max-w-sm rounded-2xl border border-stone-200 bg-white p-6 shadow-xl">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <img
                    src="/cafebill-logo.png"
                    alt="CafePOS"
                    className="h-11 w-11 rounded-xl object-cover shadow-xs"
                  />
                  <div>
                    <h3 className="text-base font-bold text-[#1C1917]">Install CafePOS</h3>
                    <p className="text-xs text-stone-500">Add to your Home Screen</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowGuideModal(false)}
                  className="flex h-9 w-9 items-center justify-center rounded-lg text-stone-500 hover:bg-stone-100"
                  aria-label="Close"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="mt-4 space-y-3 text-sm text-stone-600">
                {isIOS ? (
                  <>
                    <p className="flex items-start gap-2.5">
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-stone-100 text-xs font-bold text-[#2C1B18]">
                        1
                      </span>
                      <span>
                        Tap the <Share className="inline h-4 w-4 text-stone-700" /> <strong>Share</strong> button in Safari&apos;s toolbar.
                      </span>
                    </p>
                    <p className="flex items-start gap-2.5">
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-stone-100 text-xs font-bold text-[#2C1B18]">
                        2
                      </span>
                      <span>
                        Scroll down and tap <strong>Add to Home Screen</strong>.
                      </span>
                    </p>
                  </>
                ) : (
                  <p>
                    Open your browser menu and select <strong>Install app</strong> or{' '}
                    <strong>Add to Home Screen</strong> to use CafePOS offline like a native app.
                  </p>
                )}
              </div>
              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                className="mt-5 w-full rounded-xl bg-[#2C1B18] py-2.5 text-sm font-semibold text-white hover:bg-[#3E2723] min-h-[44px]"
              >
                Got it
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
