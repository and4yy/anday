import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Eye,
  FilePlus2,
  Receipt,
  Share2,
} from 'lucide-react';
import type { CurrencyCode, Invoice } from '../types/invoice';
import {
  type DateFilterPreset,
  formatCurrency,
  formatDateReadable,
  getInvoiceComputedTotals,
  isDateInFilter,
} from '../utils/calculations';
import { PWAInstallButton } from './PWAInstallButton';

interface DashboardViewProps {
  businessName: string;
  invoices: Invoice[];
  onCreateInvoice: () => void;
  onPreviewInvoice: (invoice: Invoice) => void;
  onMarkPaid: (invoice: Invoice) => void;
  onViewAllInvoices: () => void;
}

interface CurrencySummary {
  currency: CurrencyCode;
  invoiceCount: number;
  totalSales: number;
  paidCount: number;
  unpaidCount: number;
  partialCount: number;
  outstandingBalance: number;
}

function summarizeByCurrency(invoices: Invoice[], currency: CurrencyCode): CurrencySummary {
  const subset = invoices.filter((inv) => inv.currency === currency);
  let totalSales = 0;
  let paidCount = 0;
  let unpaidCount = 0;
  let partialCount = 0;
  let outstandingBalance = 0;

  for (const inv of subset) {
    const totals = getInvoiceComputedTotals(inv);
    totalSales += totals.grandTotal;
    outstandingBalance += totals.balanceDue;
    if (inv.paymentStatus === 'PAID') paidCount += 1;
    else if (inv.paymentStatus === 'PARTIALLY_PAID') partialCount += 1;
    else unpaidCount += 1;
  }

  return {
    currency,
    invoiceCount: subset.length,
    totalSales,
    paidCount,
    unpaidCount,
    partialCount,
    outstandingBalance,
  };
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  businessName,
  invoices,
  onCreateInvoice,
  onPreviewInvoice,
  onMarkPaid,
  onViewAllInvoices,
}) => {
  const [datePreset, setDatePreset] = useState<DateFilterPreset>('month');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');

  const filteredInvoices = useMemo(
    () =>
      invoices.filter((inv) =>
        isDateInFilter(inv.date, datePreset, customStart, customEnd)
      ),
    [invoices, datePreset, customStart, customEnd]
  );

  const mvrSummary = useMemo(
    () => summarizeByCurrency(filteredInvoices, 'MVR'),
    [filteredInvoices]
  );
  const usdSummary = useMemo(
    () => summarizeByCurrency(filteredInvoices, 'USD'),
    [filteredInvoices]
  );

  const overallPaid = filteredInvoices.filter((i) => i.paymentStatus === 'PAID').length;
  const overallUnpaid = filteredInvoices.filter((i) => i.paymentStatus !== 'PAID').length;
  const recentInvoices = filteredInvoices.slice(0, 6);

  return (
    <div className="space-y-6">
      {/* Hero Action Card */}
      <div className="flex flex-col gap-4 rounded-2xl border border-stone-200/90 bg-white p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
        <div className="space-y-1">
          <h2 className="text-xl font-bold tracking-tight text-[#1C1917] sm:text-2xl">
            {businessName || 'CafePOS'}
          </h2>
          <p className="text-sm text-stone-600">
            Create receipts in English or Dhivehi and share crisp PNGs in seconds.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <PWAInstallButton variant="compact" />
          <button
            type="button"
            onClick={onCreateInvoice}
            className="inline-flex flex-1 sm:flex-initial items-center justify-center gap-2 rounded-xl bg-[#2C1B18] px-5 py-3 text-sm font-semibold text-white shadow-xs transition-colors hover:bg-[#3E2723] min-h-[46px] whitespace-nowrap"
          >
            <FilePlus2 className="h-4 w-4 shrink-0" />
            <span>Create Invoice</span>
          </button>
        </div>
      </div>

      {/* Period Filter Bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="inline-flex flex-wrap items-center gap-1 rounded-xl border border-stone-200 bg-white p-1">
          {(
            [
              { id: 'today', label: 'Today' },
              { id: 'week', label: 'This Week' },
              { id: 'month', label: 'This Month' },
              { id: 'all', label: 'All Time' },
              { id: 'custom', label: 'Custom' },
            ] as { id: DateFilterPreset; label: string }[]
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setDatePreset(tab.id)}
              className={`rounded-lg px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap min-h-[36px] ${
                datePreset === tab.id
                  ? 'bg-[#2C1B18] text-white'
                  : 'text-stone-600 hover:bg-stone-100 hover:text-[#1C1917]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {datePreset === 'custom' && (
          <div className="flex flex-wrap items-center gap-2">
            <input
              type="date"
              value={customStart}
              onChange={(e) => setCustomStart(e.target.value)}
              aria-label="Start date"
              className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs font-medium text-[#1C1917] min-h-[40px]"
            />
            <span className="text-xs text-stone-500">to</span>
            <input
              type="date"
              value={customEnd}
              onChange={(e) => setCustomEnd(e.target.value)}
              aria-label="End date"
              className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs font-medium text-[#1C1917] min-h-[40px]"
            />
          </div>
        )}
      </div>

      {/* Overview Counts Strip */}
      <div className="grid grid-cols-3 gap-3 sm:gap-4">
        <div className="rounded-2xl border border-stone-200/90 bg-white p-4">
          <div className="text-xs font-medium text-stone-500">Total Invoices</div>
          <div className="font-mono-num mt-1 text-2xl font-bold text-[#1C1917]">
            {filteredInvoices.length}
          </div>
        </div>
        <div className="rounded-2xl border border-stone-200/90 bg-white p-4">
          <div className="text-xs font-medium text-stone-500">Paid Invoices</div>
          <div className="font-mono-num mt-1 text-2xl font-bold text-emerald-700">
            {overallPaid}
          </div>
        </div>
        <div className="rounded-2xl border border-stone-200/90 bg-white p-4">
          <div className="text-xs font-medium text-stone-500">Unpaid / Partial</div>
          <div className="font-mono-num mt-1 text-2xl font-bold text-amber-700">
            {overallUnpaid}
          </div>
        </div>
      </div>

      {/* Separate Currency Reporting (MVR & USD never combined) */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {[mvrSummary, usdSummary].map((summary) => (
          <div
            key={summary.currency}
            className="rounded-2xl border border-stone-200/90 bg-white p-5"
          >
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-[#1C1917]">
                  {summary.currency === 'MVR'
                    ? 'Maldivian Rufiyaa (MVR)'
                    : 'US Dollar (USD)'}
                </h3>
                <p className="mt-0.5 text-xs text-stone-500">
                  {summary.invoiceCount} invoice{summary.invoiceCount === 1 ? '' : 's'}
                  {' · '}
                  {summary.paidCount} paid
                  {' · '}
                  {summary.unpaidCount + summary.partialCount} open
                </p>
              </div>
              <span className="font-mono-num text-xs font-bold text-stone-500">
                {summary.currency}
              </span>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-4">
              <div>
                <div className="text-xs font-medium text-stone-500">Total Sales</div>
                <div className="font-mono-num mt-1 text-xl font-bold text-[#1C1917] sm:text-2xl">
                  {formatCurrency(summary.totalSales, summary.currency)}
                </div>
              </div>
              <div>
                <div className="text-xs font-medium text-stone-500">Outstanding Balance</div>
                <div
                  className={`font-mono-num mt-1 text-xl font-bold sm:text-2xl ${
                    summary.outstandingBalance > 0 ? 'text-amber-700' : 'text-stone-400'
                  }`}
                >
                  {formatCurrency(summary.outstandingBalance, summary.currency)}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Invoices */}
      <div className="rounded-2xl border border-stone-200/90 bg-white">
        <div className="flex items-center justify-between border-b border-stone-100 px-5 py-4">
          <h3 className="text-base font-bold text-[#1C1917]">Recent Invoices</h3>
          {invoices.length > 0 && (
            <button
              type="button"
              onClick={onViewAllInvoices}
              className="text-xs font-semibold text-[#2C1B18] hover:underline min-h-[36px] px-2"
            >
              View All
            </button>
          )}
        </div>

        {recentInvoices.length === 0 ? (
          <div className="flex flex-col items-center justify-center px-6 py-12 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-stone-100 text-stone-500">
              <Receipt className="h-6 w-6" />
            </div>
            <h4 className="mt-3 text-sm font-bold text-[#1C1917]">No invoices in this period</h4>
            <p className="mt-1 max-w-xs text-xs text-stone-500">
              Create your first invoice or thermal POS receipt to track sales and share PNGs with customers.
            </p>
            <button
              type="button"
              onClick={onCreateInvoice}
              className="mt-4 inline-flex items-center gap-2 rounded-xl bg-[#2C1B18] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#3E2723] min-h-[44px]"
            >
              <FilePlus2 className="h-4 w-4" />
              <span>Create First Invoice</span>
            </button>
          </div>
        ) : (
          <div className="divide-y divide-stone-100">
            {recentInvoices.map((inv) => {
              const totals = getInvoiceComputedTotals(inv);
              return (
                <div
                  key={inv.id}
                  className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between"
                >
                  <button
                    type="button"
                    onClick={() => onPreviewInvoice(inv)}
                    className="min-w-0 flex-1 text-start"
                  >
                    <div className="flex items-center gap-2">
                      <span dir="auto" className="truncate text-sm font-bold text-[#1C1917]">
                        {inv.customerName || 'Walk-in Customer'}
                      </span>
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-stone-500">
                      <span className="font-mono-num font-medium text-stone-700">
                        {inv.invoiceNumber}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{formatDateReadable(inv.date)}</span>
                      <span aria-hidden="true">·</span>
                      <span>{inv.language === 'dv' ? 'ދިވެހި' : 'English'}</span>
                      <span aria-hidden="true">·</span>
                      <span
                        className={`inline-flex items-center gap-1 font-semibold ${
                          inv.paymentStatus === 'PAID'
                            ? 'text-emerald-700'
                            : inv.paymentStatus === 'PARTIALLY_PAID'
                            ? 'text-amber-700'
                            : 'text-stone-700'
                        }`}
                      >
                        {inv.paymentStatus === 'PAID' ? (
                          <CheckCircle2 className="h-3.5 w-3.5" />
                        ) : inv.paymentStatus === 'PARTIALLY_PAID' ? (
                          <Clock className="h-3.5 w-3.5" />
                        ) : (
                          <AlertCircle className="h-3.5 w-3.5" />
                        )}
                        {inv.paymentStatus === 'PAID'
                          ? 'Paid'
                          : inv.paymentStatus === 'PARTIALLY_PAID'
                          ? `Partial (Due ${formatCurrency(totals.balanceDue, inv.currency)})`
                          : 'Unpaid'}
                      </span>
                    </div>
                  </button>

                  <div className="flex items-center justify-between gap-3 sm:justify-end">
                    <div className="font-mono-num text-sm font-bold text-[#1C1917]">
                      {formatCurrency(totals.grandTotal, inv.currency)}
                    </div>
                    <div className="flex items-center gap-1.5">
                      {inv.paymentStatus !== 'PAID' && (
                        <button
                          type="button"
                          onClick={() => onMarkPaid(inv)}
                          className="rounded-xl border border-emerald-700/30 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-800 hover:bg-emerald-100 min-h-[40px] whitespace-nowrap"
                        >
                          Mark Paid
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onPreviewInvoice(inv)}
                        className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-semibold text-[#1C1917] hover:bg-stone-50 min-h-[40px] whitespace-nowrap"
                        aria-label={`Preview and share ${inv.invoiceNumber}`}
                      >
                        <Eye className="h-3.5 w-3.5 sm:hidden" />
                        <Share2 className="hidden h-3.5 w-3.5 sm:inline" />
                        <span>PNG</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
