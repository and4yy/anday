import React, { useState } from 'react';
import {
  Check,
  Cloud,
  KeyRound,
  LogOut,
  Phone,
  Trash2,
  User,
} from 'lucide-react';
import { auth } from '../lib/firebase';
import {
  changeAccountPassword,
  deleteAccount,
  requestPhoneChangeOtp,
  updateAccountProfile,
  verifyPhoneChange,
} from '../services/api';
import { linkGoogleCloudSync, unlinkGoogleCloudSync } from '../services/firestoreSync';
import { COUNTRY_CODES, type AuthUser } from '../types/auth';
import { ConfirmModal } from './ConfirmModal';

interface AccountProfileSectionProps {
  user: AuthUser;
  onUserUpdated: (user: AuthUser) => void;
  onLogout: () => void;
  onAccountDeleted: () => void;
  onSyncToCloud: () => Promise<void>;
  onNotify: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export const AccountProfileSection: React.FC<AccountProfileSectionProps> = ({
  user,
  onUserUpdated,
  onLogout,
  onAccountDeleted,
  onSyncToCloud,
  onNotify,
}) => {
  const [fullName, setFullName] = useState(user.fullName);
  const [savingName, setSavingName] = useState(false);

  // Change Mobile Number with OTP
  const [newCountryCode, setNewCountryCode] = useState(user.countryCode || '+960');
  const [newPhone, setNewPhone] = useState('');
  const [phoneOtpStep, setPhoneOtpStep] = useState<'idle' | 'verify'>('idle');
  const [phoneOtp, setPhoneOtp] = useState('');
  const [phonePreviewOtp, setPhonePreviewOtp] = useState<string | null>(null);
  const [phonePassword, setPhonePassword] = useState('');
  const [changingPhone, setChangingPhone] = useState(false);

  // Change Password
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [changingPass, setChangingPass] = useState(false);

  // Google Cloud Sync state
  const [googleEmail, setGoogleEmail] = useState<string | null>(
    auth.currentUser?.email || null
  );
  const [syncingCloud, setSyncingCloud] = useState(false);

  // Delete Account modal
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deletePassword, setDeletePassword] = useState('');
  const [deleting, setDeleting] = useState(false);

  const handleSaveName = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingName(true);
    try {
      const updated = await updateAccountProfile(fullName);
      onUserUpdated(updated);
      onNotify('Profile name updated.', 'success');
    } catch (err) {
      onNotify((err as Error).message || 'Could not update profile.', 'error');
    } finally {
      setSavingName(false);
    }
  };

  const handleRequestPhoneOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setChangingPhone(true);
    try {
      const res = await requestPhoneChangeOtp({
        countryCode: newCountryCode,
        phoneNumber: newPhone,
      });
      setPhonePreviewOtp(res.previewOtp || null);
      setPhoneOtpStep('verify');
      onNotify('OTP sent to verify new mobile number.', 'info');
    } catch (err) {
      onNotify((err as Error).message || 'Could not send OTP.', 'error');
    } finally {
      setChangingPhone(false);
    }
  };

  const handleVerifyPhoneChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setChangingPhone(true);
    try {
      const updated = await verifyPhoneChange({
        countryCode: newCountryCode,
        phoneNumber: newPhone,
        otp: phoneOtp,
        currentPassword: phonePassword,
      });
      onUserUpdated(updated);
      setPhoneOtpStep('idle');
      setNewPhone('');
      setPhoneOtp('');
      setPhonePassword('');
      setPhonePreviewOtp(null);
      onNotify('Mobile number updated successfully.', 'success');
    } catch (err) {
      onNotify((err as Error).message || 'Verification failed.', 'error');
    } finally {
      setChangingPhone(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmNewPassword) {
      onNotify('New passwords do not match.', 'error');
      return;
    }
    setChangingPass(true);
    try {
      await changeAccountPassword({ currentPassword, newPassword });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      onNotify('Password updated.', 'success');
    } catch (err) {
      onNotify((err as Error).message || 'Could not change password.', 'error');
    } finally {
      setChangingPass(false);
    }
  };

  const handleConnectGoogleSync = async () => {
    setSyncingCloud(true);
    try {
      const info = await linkGoogleCloudSync();
      setGoogleEmail(info.email || 'Connected');
      await onSyncToCloud();
      onNotify('Connected & synced workspace to Firestore cloud.', 'success');
    } catch (err) {
      onNotify((err as Error).message || 'Could not link Google Cloud Sync.', 'error');
    } finally {
      setSyncingCloud(false);
    }
  };

  const handleDisconnectGoogleSync = async () => {
    await unlinkGoogleCloudSync();
    setGoogleEmail(null);
    onNotify('Google Cloud Sync disconnected.', 'info');
  };

  const handleConfirmDeleteAccount = async () => {
    if (!deletePassword) {
      onNotify('Please enter your password to confirm deletion.', 'error');
      return;
    }
    setDeleting(true);
    try {
      await deleteAccount(deletePassword);
      setShowDeleteModal(false);
      onAccountDeleted();
    } catch (err) {
      onNotify((err as Error).message || 'Could not delete account.', 'error');
    } finally {
      setDeleting(false);
    }
  };

  if (user.isGuest) {
    return (
      <div className="rounded-2xl border border-stone-200/90 bg-white p-6 space-y-4">
        <div className="flex items-center gap-2.5">
          <User className="h-5 w-5 text-[#4E2A16]" />
          <h3 className="text-base font-bold text-[#1C1917]">Guest Demo Mode</h3>
        </div>
        <p className="text-sm leading-relaxed text-stone-600">
          You are currently testing CafePOS without logging in. All demo invoices, menu items, and settings are stored locally on this browser. Sign in or create a free account to sync your private café workspace across sessions.
        </p>
        <button
          type="button"
          onClick={onLogout}
          className="inline-flex items-center gap-2 rounded-xl bg-[#4E2A16] px-5 py-3 text-sm font-bold text-white hover:bg-[#3E2723] min-h-[46px]"
        >
          <LogOut className="h-4 w-4" />
          <span>Sign In or Create Account</span>
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Profile Details */}
      <form
        onSubmit={(e) => void handleSaveName(e)}
        className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4"
      >
        <div className="flex items-center gap-2">
          <User className="h-5 w-5 text-[#4E2A16]" />
          <h3 className="text-base font-bold text-[#1C1917]">Profile Information</h3>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">Full Name</label>
            <input
              type="text"
              required
              dir="auto"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[44px]"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Registered Mobile Number
            </label>
            <div className="flex items-center rounded-xl border border-stone-200 bg-[#FAF9F7] px-3.5 py-2.5 font-mono text-sm text-stone-700 min-h-[44px]">
              {user.normalizedPhone}
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={savingName}
          className="inline-flex items-center gap-2 rounded-xl bg-[#4E2A16] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#3E2723] disabled:opacity-60 min-h-[44px]"
        >
          <Check className="h-4 w-4" />
          <span>{savingName ? 'Saving...' : 'Save Profile'}</span>
        </button>
      </form>

      {/* Change Mobile Number with OTP */}
      <div className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4">
        <div className="flex items-center gap-2">
          <Phone className="h-5 w-5 text-[#4E2A16]" />
          <h3 className="text-base font-bold text-[#1C1917]">
            Change Mobile Number (OTP Verification)
          </h3>
        </div>

        {phoneOtpStep === 'idle' ? (
          <form onSubmit={(e) => void handleRequestPhoneOtp(e)} className="space-y-3">
            <div className="flex flex-col gap-2 sm:flex-row">
              <select
                value={newCountryCode}
                onChange={(e) => setNewCountryCode(e.target.value)}
                className="sm:w-36 rounded-xl border border-stone-300 bg-white px-3 py-2.5 text-xs font-semibold min-h-[44px]"
              >
                {COUNTRY_CODES.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.label}
                  </option>
                ))}
              </select>
              <input
                type="tel"
                required
                dir="ltr"
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
                placeholder="New mobile number"
                className="flex-1 rounded-xl border border-stone-300 px-3.5 py-2.5 font-mono text-sm min-h-[44px]"
              />
              <button
                type="submit"
                disabled={changingPhone}
                className="rounded-xl bg-[#4E2A16] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#3E2723] disabled:opacity-60 min-h-[44px]"
              >
                {changingPhone ? 'Sending...' : 'Send OTP'}
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={(e) => void handleVerifyPhoneChange(e)} className="space-y-3">
            {phonePreviewOtp && (
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-950">
                Verification Code:{' '}
                <span className="font-mono text-sm font-bold">{phonePreviewOtp}</span>
              </div>
            )}
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <input
                type="text"
                required
                dir="ltr"
                value={phoneOtp}
                onChange={(e) => setPhoneOtp(e.target.value)}
                placeholder="Enter 6-digit OTP"
                className="rounded-xl border border-stone-300 px-3.5 py-2.5 font-mono text-sm min-h-[44px]"
              />
              <input
                type="password"
                required
                value={phonePassword}
                onChange={(e) => setPhonePassword(e.target.value)}
                placeholder="Confirm current password"
                className="rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[44px]"
              />
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setPhoneOtpStep('idle')}
                className="rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-xs font-semibold text-stone-700 min-h-[42px]"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={changingPhone}
                className="rounded-xl bg-[#4E2A16] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#3E2723] min-h-[42px]"
              >
                Verify &amp; Update Number
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Change Password */}
      <form
        onSubmit={(e) => void handleChangePassword(e)}
        className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4"
      >
        <div className="flex items-center gap-2">
          <KeyRound className="h-5 w-5 text-[#4E2A16]" />
          <h3 className="text-base font-bold text-[#1C1917]">Change Password</h3>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <input
            type="password"
            required
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            placeholder="Current password"
            className="rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[44px]"
          />
          <input
            type="password"
            required
            minLength={6}
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="New password"
            className="rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[44px]"
          />
          <input
            type="password"
            required
            minLength={6}
            value={confirmNewPassword}
            onChange={(e) => setConfirmNewPassword(e.target.value)}
            placeholder="Confirm new password"
            className="rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[44px]"
          />
        </div>

        <button
          type="submit"
          disabled={changingPass}
          className="rounded-xl bg-[#4E2A16] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#3E2723] disabled:opacity-60 min-h-[44px]"
        >
          {changingPass ? 'Updating...' : 'Update Password'}
        </button>
      </form>

      {/* Optional Google Firestore Cloud Backup */}
      <div className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-3">
        <div className="flex items-center gap-2">
          <Cloud className="h-5 w-5 text-[#4E2A16]" />
          <h3 className="text-base font-bold text-[#1C1917]">
            Cloud Backup Sync (Google / Firestore)
          </h3>
        </div>
        <p className="text-xs text-stone-600">
          Optionally connect your Google account to mirror your private café workspace to encrypted Firestore cloud storage.
        </p>
        {googleEmail ? (
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs">
            <span className="font-semibold text-emerald-900">
              Connected: {googleEmail}
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={syncingCloud}
                onClick={() => void onSyncToCloud().then(() => onNotify('Synced to cloud.', 'success'))}
                className="rounded-lg bg-emerald-700 px-3 py-1.5 font-bold text-white"
              >
                Sync Now
              </button>
              <button
                type="button"
                onClick={() => void handleDisconnectGoogleSync()}
                className="rounded-lg border border-emerald-700/30 bg-white px-3 py-1.5 font-semibold text-emerald-900"
              >
                Disconnect
              </button>
            </div>
          </div>
        ) : (
          <button
            type="button"
            disabled={syncingCloud}
            onClick={() => void handleConnectGoogleSync()}
            className="inline-flex items-center gap-2 rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-xs font-bold text-[#1C1917] hover:bg-stone-50 min-h-[44px]"
          >
            <Cloud className="h-4 w-4 text-[#4E2A16]" />
            <span>{syncingCloud ? 'Connecting...' : 'Connect Google Cloud Sync'}</span>
          </button>
        )}
      </div>

      {/* Logout & Delete Account */}
      <div className="rounded-2xl border border-stone-200/90 bg-white p-5 flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={onLogout}
          className="inline-flex items-center gap-2 rounded-xl border border-stone-300 bg-white px-5 py-3 text-sm font-bold text-[#1C1917] hover:bg-stone-50 min-h-[46px]"
        >
          <LogOut className="h-4 w-4" />
          <span>Sign Out</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setDeletePassword('');
            setShowDeleteModal(true);
          }}
          className="inline-flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-5 py-3 text-sm font-bold text-rose-800 hover:bg-rose-100 min-h-[46px]"
        >
          <Trash2 className="h-4 w-4" />
          <span>Delete Account</span>
        </button>
      </div>

      {/* Password Confirmation Modal for Deleting Account */}
      {showDeleteModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-sm rounded-2xl border border-stone-200 bg-white p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-rose-900">Delete Account Permanently?</h3>
            <p className="text-xs leading-relaxed text-stone-600">
              This will permanently delete your account, business settings, customers, and all invoices from this server. Enter your password to confirm.
            </p>
            <input
              type="password"
              value={deletePassword}
              onChange={(e) => setDeletePassword(e.target.value)}
              placeholder="Enter your password"
              className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[44px]"
            />
            <div className="flex justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setShowDeleteModal(false)}
                className="rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-xs font-semibold text-stone-700 min-h-[42px]"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={deleting}
                onClick={() => void handleConfirmDeleteAccount()}
                className="rounded-xl bg-rose-700 px-4 py-2.5 text-xs font-bold text-white hover:bg-rose-800 disabled:opacity-60 min-h-[42px]"
              >
                {deleting ? 'Deleting...' : 'Permanently Delete'}
              </button>
            </div>
          </div>
        </div>
      )}

      <ConfirmModal
        open={false}
        title=""
        message=""
        onConfirm={() => {}}
        onCancel={() => {}}
      />
    </div>
  );
};
