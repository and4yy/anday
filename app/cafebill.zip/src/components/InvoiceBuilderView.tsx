import React, { useMemo, useRef, useState } from 'react';
import {
  Armchair,
  BookmarkCheck,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  Eye,
  Minus,
  Pencil,
  Plus,
  Save,
  Search,
  Share2,
  ShoppingBag,
  SlidersHorizontal,
  Trash2,
  UserCheck,
  X,
} from 'lucide-react';
import type {
  AppPreferences,
  BankAccount,
  BusinessProfile,
  CurrencyCode,
  Customer,
  DiscountType,
  Invoice,
  InvoiceLanguage,
  InvoiceLayoutStyle,
  InvoiceLineItem,
  MenuCategory,
  OpenTableOrder,
  PaymentMethod,
  PaymentStatus,
  PosWidth,
  QuickMenuItem,
  TranslationMap,
} from '../types/invoice';
import {
  calculateInvoiceTotals,
  calculateLineTotal,
  createId,
  formatCurrency,
  formatInvoiceNumber,
  getTodayISO,
} from '../utils/calculations';
import { generateInvoicePngBlob, shareInvoicePng } from '../utils/pngExport';
import { InvoiceDocument } from './InvoiceDocument';

interface InvoiceBuilderViewProps {
  editingInvoice: Invoice | null;
  preselectedCustomer: Customer | null;
  businessProfile: BusinessProfile;
  bankAccounts: BankAccount[];
  translations: TranslationMap;
  preferences: AppPreferences;
  quickMenuItems: QuickMenuItem[];
  customers: Customer[];
  openOrders: OpenTableOrder[];
  onSaveInvoice: (invoice: Invoice, isNew: boolean, fromTableKey?: string) => Promise<void>;
  onSaveOpenOrder: (order: OpenTableOrder) => Promise<void>;
  onDeleteOpenOrder: (tableKey: string) => Promise<void>;
  onQuickSaveCustomer: (customer: Customer) => Promise<void>;
  onOpenPreviewModal: (invoice: Invoice) => void;
  onViewHistory: () => void;
  onNotify: (msg: string, type?: 'success' | 'info' | 'error') => void;
  onCancelEdit: () => void;
}

const DEFAULT_TABLES = ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9', 'T10'];
const CATEGORIES: ('All' | MenuCategory)[] = [
  'All',
  'Coffee',
  'Tea',
  'Cold Drinks',
  'Food',
  'Desserts',
  'Others',
];

export const InvoiceBuilderView: React.FC<InvoiceBuilderViewProps> = ({
  editingInvoice,
  preselectedCustomer,
  businessProfile,
  bankAccounts,
  translations,
  preferences,
  quickMenuItems,
  customers,
  openOrders,
  onSaveInvoice,
  onSaveOpenOrder,
  onDeleteOpenOrder,
  onQuickSaveCustomer,
  onOpenPreviewModal,
  onViewHistory,
  onNotify,
  onCancelEdit,
}) => {
  const isEditingExisting = Boolean(editingInvoice && editingInvoice.id);
  const hiddenExportRef = useRef<HTMLDivElement>(null);

  const defaultBankIds = useMemo(() => {
    const defaults = bankAccounts.filter((b) => b.isDefault).map((b) => b.id);
    if (defaults.length > 0) return defaults;
    return bankAccounts.length > 0 ? [bankAccounts[0].id] : [];
  }, [bankAccounts]);

  // Core order & invoice fields
  const [invoiceId, setInvoiceId] = useState<string>(
    () => editingInvoice?.id || createId('inv')
  );
  const [invoiceNumber, setInvoiceNumber] = useState<string>(
    () =>
      editingInvoice?.invoiceNumber ||
      formatInvoiceNumber(preferences.invoicePrefix, preferences.nextInvoiceSequence)
  );
  const [date, setDate] = useState<string>(
    () => editingInvoice?.date || getTodayISO()
  );
  const [tableName, setTableName] = useState<string>(
    () => editingInvoice?.tableName || ''
  );
  const [customTableInput, setCustomTableInput] = useState('');
  const [showCustomTableBox, setShowCustomTableBox] = useState(false);

  const [language, setLanguage] = useState<InvoiceLanguage>(
    () => editingInvoice?.language || preferences.defaultLanguage
  );
  const [currency, setCurrency] = useState<CurrencyCode>(
    () => editingInvoice?.currency || preferences.defaultCurrency
  );
  const [layoutStyle, setLayoutStyle] = useState<InvoiceLayoutStyle>(
    () => editingInvoice?.layoutStyle || preferences.defaultLayoutStyle
  );
  const [posWidth, setPosWidth] = useState<PosWidth>(
    () => editingInvoice?.posWidth || preferences.defaultPosWidth
  );

  // Customer fields
  const [customerId, setCustomerId] = useState<string | undefined>(
    () => editingInvoice?.customerId || preselectedCustomer?.id
  );
  const [customerName, setCustomerName] = useState<string>(
    () => editingInvoice?.customerName || preselectedCustomer?.name || ''
  );
  const [customerPhone, setCustomerPhone] = useState<string>(
    () => editingInvoice?.customerPhone || preselectedCustomer?.phone || ''
  );
  const [customerEmail, setCustomerEmail] = useState<string>(
    () => editingInvoice?.customerEmail || preselectedCustomer?.email || ''
  );

  // Menu search & category
  const [menuSearch, setMenuSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<'All' | MenuCategory>('All');

  // Items
  const [items, setItems] = useState<InvoiceLineItem[]>(
    () => editingInvoice?.items || []
  );

  // Custom item modal
  const [showCustomItemModal, setShowCustomItemModal] = useState(false);
  const [customItemDesc, setCustomItemDesc] = useState('');
  const [customItemQty, setCustomItemQty] = useState(1);
  const [customItemPrice, setCustomItemPrice] = useState('');

  // Discount & Charges
  const [discountType, setDiscountType] = useState<DiscountType>(
    () => editingInvoice?.discountType || 'fixed'
  );
  const [discountValue, setDiscountValue] = useState<number>(
    () => editingInvoice?.discountValue ?? 0
  );
  const [showDiscountEditor, setShowDiscountEditor] = useState(false);
  const [additionalChargeLabel, setAdditionalChargeLabel] = useState<string>(
    () => editingInvoice?.additionalChargeLabel || ''
  );
  const [additionalChargeAmount, setAdditionalChargeAmount] = useState<number>(
    () => editingInvoice?.additionalChargeAmount ?? 0
  );

  // Payment & Advanced options
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(
    () => editingInvoice?.paymentMethod || 'cash'
  );
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>(
    () => editingInvoice?.paymentStatus || 'UNPAID'
  );
  const [paymentDate, setPaymentDate] = useState<string>(
    () => editingInvoice?.paymentDate || getTodayISO()
  );
  const [amountPaid, setAmountPaid] = useState<number>(
    () => editingInvoice?.amountPaid ?? 0
  );
  const [showBankDetails, setShowBankDetails] = useState<boolean>(
    () => editingInvoice?.showBankDetails ?? preferences.defaultShowBankDetails
  );
  const [selectedBankIds, setSelectedBankIds] = useState<string[]>(
    () => editingInvoice?.selectedBankIds || defaultBankIds
  );
  const [paymentInstructions, setPaymentInstructions] = useState<string>(
    () => editingInvoice?.paymentInstructions || ''
  );
  const [notes, setNotes] = useState<string>(() => editingInvoice?.notes || '');
  const [footerMessage, setFooterMessage] = useState<string>(
    () => editingInvoice?.footerMessage || ''
  );
  const [showConversionReference, setShowConversionReference] = useState<boolean>(
    () => editingInvoice?.showConversionReference ?? false
  );

  const [showMoreOptions, setShowMoreOptions] = useState(false);
  const [showPostSaveModal, setShowPostSaveModal] = useState(false);
  const [lastSavedInvoice, setLastSavedInvoice] = useState<Invoice | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isSharing, setIsSharing] = useState(false);

  const totals = useMemo(
    () =>
      calculateInvoiceTotals(
        items,
        discountType,
        discountValue,
        additionalChargeAmount,
        amountPaid,
        paymentStatus
      ),
    [items, discountType, discountValue, additionalChargeAmount, amountPaid, paymentStatus]
  );

  const openOrderMap = useMemo(() => {
    const map = new Map<string, OpenTableOrder>();
    for (const ord of openOrders) {
      map.set(ord.id, ord);
    }
    return map;
  }, [openOrders]);

  const filteredMenu = useMemo(() => {
    const q = menuSearch.trim().toLowerCase();
    return quickMenuItems.filter((m) => {
      if (activeCategory !== 'All' && m.category !== activeCategory) return false;
      if (q) {
        const matchEn = m.nameEn.toLowerCase().includes(q);
        const matchDv = (m.nameDv || '').toLowerCase().includes(q);
        if (!matchEn && !matchDv) return false;
      }
      return true;
    });
  }, [quickMenuItems, activeCategory, menuSearch]);

  const currentDraftInvoice: Invoice = useMemo(() => {
    const now = new Date().toISOString();
    return {
      id: invoiceId,
      invoiceNumber: invoiceNumber.trim() || 'INV-0001',
      date,
      tableName: tableName.trim() || undefined,
      customerId,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim() || undefined,
      customerEmail: customerEmail.trim() || undefined,
      language,
      currency,
      layoutStyle,
      posWidth,
      items: items.length > 0 ? items : [{ id: 'empty', description: 'Order Item', quantity: 1, unitPrice: 0 }],
      discountType,
      discountValue,
      additionalChargeLabel: additionalChargeLabel.trim() || undefined,
      additionalChargeAmount,
      notes: notes.trim() || undefined,
      paymentInstructions: paymentInstructions.trim() || undefined,
      showBankDetails,
      selectedBankIds,
      paymentMethod,
      paymentStatus,
      paymentDate: paymentStatus === 'PAID' ? paymentDate || getTodayISO() : undefined,
      amountPaid:
        paymentStatus === 'PAID'
          ? totals.grandTotal
          : paymentStatus === 'PARTIALLY_PAID'
          ? totals.amountPaid
          : 0,
      showConversionReference,
      exchangeRateUsed: showConversionReference
        ? preferences.exchangeRateUsdToMvr
        : undefined,
      footerMessage: footerMessage.trim() || undefined,
      createdAt: editingInvoice?.createdAt || now,
      updatedAt: now,
    };
  }, [
    invoiceId,
    invoiceNumber,
    date,
    tableName,
    customerId,
    customerName,
    customerPhone,
    customerEmail,
    language,
    currency,
    layoutStyle,
    posWidth,
    items,
    discountType,
    discountValue,
    additionalChargeLabel,
    additionalChargeAmount,
    notes,
    paymentInstructions,
    showBankDetails,
    selectedBankIds,
    paymentMethod,
    paymentStatus,
    paymentDate,
    totals.grandTotal,
    totals.amountPaid,
    showConversionReference,
    preferences.exchangeRateUsdToMvr,
    footerMessage,
    editingInvoice,
  ]);

  const handleSelectTable = (targetTable: string) => {
    setTableName(targetTable);
    setShowCustomTableBox(false);

    if (!targetTable || isEditingExisting) return;

    const existingOpen = openOrderMap.get(targetTable);
    if (existingOpen) {
      setItems(existingOpen.items);
      setLanguage(existingOpen.language);
      setCurrency(existingOpen.currency);
      setCustomerId(existingOpen.customerId);
      setCustomerName(existingOpen.customerName);
      setCustomerPhone(existingOpen.customerPhone || '');
      setCustomerEmail(existingOpen.customerEmail || '');
      setDiscountType(existingOpen.discountType);
      setDiscountValue(existingOpen.discountValue);
      setAdditionalChargeLabel(existingOpen.additionalChargeLabel || '');
      setAdditionalChargeAmount(existingOpen.additionalChargeAmount);
      setNotes(existingOpen.notes || '');
      onNotify(`Loaded open order for ${targetTable} (${existingOpen.items.length} items).`, 'info');
    }
  };

  const handleTapMenuItem = (menuItem: QuickMenuItem) => {
    const label =
      language === 'dv' && menuItem.nameDv ? menuItem.nameDv : menuItem.nameEn;
    const price = currency === 'USD' ? menuItem.priceUsd : menuItem.priceMvr;

    setItems((prev) => {
      const existingIdx = prev.findIndex(
        (it) =>
          (it.description === menuItem.nameEn || it.description === menuItem.nameDv) &&
          Math.abs(it.unitPrice - price) < 0.01
      );
      if (existingIdx >= 0) {
        return prev.map((it, idx) =>
          idx === existingIdx ? { ...it, quantity: it.quantity + 1 } : it
        );
      }
      return [
        ...prev,
        {
          id: createId('item'),
          description: label,
          quantity: 1,
          unitPrice: price,
        },
      ];
    });
  };

  const getItemCountInOrder = (menuItem: QuickMenuItem): number => {
    const price = currency === 'USD' ? menuItem.priceUsd : menuItem.priceMvr;
    return items
      .filter(
        (it) =>
          (it.description === menuItem.nameEn || it.description === menuItem.nameDv) &&
          Math.abs(it.unitPrice - price) < 0.01
      )
      .reduce((sum, it) => sum + it.quantity, 0);
  };

  const updateItemQty = (id: string, delta: number) => {
    setItems((prev) =>
      prev
        .map((it) => (it.id === id ? { ...it, quantity: it.quantity + delta } : it))
        .filter((it) => it.quantity > 0)
    );
  };

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((it) => it.id !== id));
  };

  const handleAddCustomItem = (e: React.FormEvent) => {
    e.preventDefault();
    const desc = customItemDesc.trim();
    const price = Number(customItemPrice) || 0;
    const qty = Math.max(1, customItemQty || 1);
    if (!desc) return;
    setItems((prev) => [
      ...prev,
      {
        id: createId('item'),
        description: desc,
        quantity: qty,
        unitPrice: price,
      },
    ]);
    setCustomItemDesc('');
    setCustomItemQty(1);
    setCustomItemPrice('');
    setShowCustomItemModal(false);
  };

  const handleCurrencyChange = (nextCurrency: CurrencyCode) => {
    setCurrency(nextCurrency);
  };

  const handleLanguageChange = (nextLang: InvoiceLanguage) => {
    setLanguage(nextLang);
    // Remap unmodified menu item descriptions when toggling language
    setItems((prev) =>
      prev.map((it) => {
        const match = quickMenuItems.find(
          (m) => m.nameEn === it.description || m.nameDv === it.description
        );
        if (!match) return it;
        return {
          ...it,
          description: nextLang === 'dv' && match.nameDv ? match.nameDv : match.nameEn,
        };
      })
    );
  };

  const handleSelectCustomer = (selectedId: string) => {
    if (!selectedId) {
      setCustomerId(undefined);
      return;
    }
    const found = customers.find((c) => c.id === selectedId);
    if (found) {
      setCustomerId(found.id);
      setCustomerName(found.name);
      setCustomerPhone(found.phone || '');
      setCustomerEmail(found.email || '');
    }
  };

  const handleSaveNewCustomerInline = async () => {
    if (!customerName.trim()) {
      onNotify('Enter a customer name first.', 'error');
      return;
    }
    const now = new Date().toISOString();
    const newCust: Customer = {
      id: customerId || createId('cust'),
      name: customerName.trim(),
      phone: customerPhone.trim() || undefined,
      email: customerEmail.trim() || undefined,
      createdAt: now,
      updatedAt: now,
    };
    await onQuickSaveCustomer(newCust);
    setCustomerId(newCust.id);
    onNotify(`Saved customer "${newCust.name}".`, 'success');
  };

  const handleSaveOpenTableOrder = async () => {
    if (!tableName.trim()) {
      onNotify('Select a table (e.g. T3) or Takeaway to hold an open order.', 'error');
      return;
    }
    if (items.length === 0) {
      onNotify('Add at least one item before saving the table order.', 'error');
      return;
    }
    const order: OpenTableOrder = {
      id: tableName.trim(),
      tableName: tableName.trim(),
      language,
      currency,
      customerId,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim() || undefined,
      customerEmail: customerEmail.trim() || undefined,
      items,
      discountType,
      discountValue,
      additionalChargeLabel: additionalChargeLabel.trim() || undefined,
      additionalChargeAmount,
      notes: notes.trim() || undefined,
      updatedAt: new Date().toISOString(),
    };
    await onSaveOpenOrder(order);
    onNotify(`Saved open order for ${order.tableName}. Tap ${order.tableName} anytime to add more items.`, 'success');
  };

  const handleSaveFinalInvoice = async () => {
    if (items.length === 0) {
      onNotify('Tap at least one menu item to add to the order.', 'error');
      return;
    }
    setIsSaving(true);
    try {
      const toSave: Invoice = {
        ...currentDraftInvoice,
        items,
      };
      await onSaveInvoice(toSave, !isEditingExisting, tableName.trim() || undefined);
      setLastSavedInvoice(toSave);
      setShowPostSaveModal(true);
      onNotify(`Invoice ${toSave.invoiceNumber} saved!`, 'success');
    } catch {
      onNotify('Could not save invoice.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleQuickShareCurrent = async () => {
    if (items.length === 0) {
      onNotify('Add at least one item first.', 'error');
      return;
    }
    if (!hiddenExportRef.current) return;
    setIsSharing(true);
    try {
      const blob = await generateInvoicePngBlob(
        hiddenExportRef.current,
        preferences.customFontDataUrl
      );
      const res = await shareInvoicePng(
        blob,
        `${currentDraftInvoice.invoiceNumber}.png`,
        `${businessProfile.name} — ${currentDraftInvoice.invoiceNumber}`,
        `Receipt ${currentDraftInvoice.invoiceNumber}`
      );
      if (res.method === 'web-share') {
        onNotify('Receipt shared.', 'success');
      } else {
        onNotify('PNG downloaded — attach it in WhatsApp or your messaging app.', 'info');
      }
    } catch (err) {
      if ((err as Error)?.name !== 'AbortError') {
        onNotify('Unable to export PNG right now.', 'error');
      }
    } finally {
      setIsSharing(false);
    }
  };

  const updateSavedInvoiceStatus = async (status: PaymentStatus) => {
    if (!lastSavedInvoice) return;
    const savedTotals = calculateInvoiceTotals(
      lastSavedInvoice.items,
      lastSavedInvoice.discountType,
      lastSavedInvoice.discountValue,
      lastSavedInvoice.additionalChargeAmount,
      lastSavedInvoice.amountPaid,
      status
    );
    const updated: Invoice = {
      ...lastSavedInvoice,
      paymentStatus: status,
      paymentDate: status === 'PAID' ? getTodayISO() : undefined,
      amountPaid:
        status === 'PAID'
          ? savedTotals.grandTotal
          : status === 'PARTIALLY_PAID'
          ? lastSavedInvoice.amountPaid
          : 0,
      updatedAt: new Date().toISOString(),
    };
    setPaymentStatus(status);
    setLastSavedInvoice(updated);
    await onSaveInvoice(updated, false);
    onNotify(
      status === 'PAID'
        ? `Marked ${updated.invoiceNumber} as PAID.`
        : status === 'PARTIALLY_PAID'
        ? `Updated ${updated.invoiceNumber} to Partially Paid.`
        : `Marked ${updated.invoiceNumber} as Unpaid.`,
      'success'
    );
  };

  const resetForNextOrder = () => {
    const nextSeq = preferences.nextInvoiceSequence;
    setInvoiceId(createId('inv'));
    setInvoiceNumber(formatInvoiceNumber(preferences.invoicePrefix, nextSeq));
    setDate(getTodayISO());
    setTableName('');
    setCustomerId(undefined);
    setCustomerName('');
    setCustomerPhone('');
    setCustomerEmail('');
    setItems([]);
    setDiscountValue(0);
    setAdditionalChargeLabel('');
    setAdditionalChargeAmount(0);
    setPaymentStatus('UNPAID');
    setAmountPaid(0);
    setNotes('');
    setPaymentInstructions('');
    setFooterMessage('');
    setLastSavedInvoice(null);
    setShowPostSaveModal(false);
  };

  const allTableButtons = useMemo(() => {
    const set = new Set<string>(DEFAULT_TABLES);
    for (const ord of openOrders) {
      if (ord.tableName && ord.tableName !== 'Takeaway') {
        set.add(ord.tableName);
      }
    }
    if (tableName && tableName !== 'Takeaway' && !set.has(tableName)) {
      set.add(tableName);
    }
    return Array.from(set);
  }, [openOrders, tableName]);

  return (
    <div className="space-y-5">
      {/* Top Context Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-[#1C1917]">
            {isEditingExisting ? `Editing ${invoiceNumber}` : 'Create Invoice'}
          </h2>
          <p className="text-xs text-stone-500">
            Tap a table &amp; menu items to build an order in seconds
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* Quick Language & Currency Switchers */}
          <div className="inline-flex rounded-xl border border-stone-200 bg-white p-1">
            <button
              type="button"
              onClick={() => handleLanguageChange('en')}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold min-h-[36px] ${
                language === 'en'
                  ? 'bg-[#4E2A16] text-white'
                  : 'text-stone-600 hover:text-[#1C1917]'
              }`}
            >
              EN
            </button>
            <button
              type="button"
              onClick={() => handleLanguageChange('dv')}
              className={`font-thaana rounded-lg px-2.5 py-1.5 text-xs font-semibold min-h-[36px] ${
                language === 'dv'
                  ? 'bg-[#4E2A16] text-white'
                  : 'text-stone-600 hover:text-[#1C1917]'
              }`}
            >
              ދިވެހި
            </button>
          </div>

          <div className="inline-flex rounded-xl border border-stone-200 bg-white p-1">
            <button
              type="button"
              onClick={() => handleCurrencyChange('MVR')}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold min-h-[36px] ${
                currency === 'MVR'
                  ? 'bg-[#4E2A16] text-white'
                  : 'text-stone-600 hover:text-[#1C1917]'
              }`}
            >
              MVR
            </button>
            <button
              type="button"
              onClick={() => handleCurrencyChange('USD')}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold min-h-[36px] ${
                currency === 'USD'
                  ? 'bg-[#4E2A16] text-white'
                  : 'text-stone-600 hover:text-[#1C1917]'
              }`}
            >
              USD
            </button>
          </div>

          {isEditingExisting ? (
            <button
              type="button"
              onClick={onCancelEdit}
              className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 min-h-[40px]"
            >
              Cancel Edit
            </button>
          ) : (
            <button
              type="button"
              onClick={onViewHistory}
              className="hidden sm:inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-semibold text-[#4E2A16] hover:bg-stone-50 min-h-[40px]"
            >
              History
            </button>
          )}
        </div>
      </div>

      {/* Main Responsive Split: Left (Tables + Menu), Right (Order Summary + Save/Export) */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-start">
        {/* LEFT COLUMN: Table Selection & Visual Menu */}
        <div className="space-y-5 lg:col-span-7">
          {/* 1. Select Table */}
          <section className="rounded-2xl border border-stone-200/90 bg-white p-4 sm:p-5">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <Armchair className="h-4 w-4 text-[#4E2A16]" />
                <h3 className="text-sm font-bold text-[#1C1917]">Select Table</h3>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => handleSelectTable('Takeaway')}
                  className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-semibold transition-colors min-h-[38px] ${
                    tableName === 'Takeaway'
                      ? 'border-[#4E2A16] bg-[#4E2A16] text-white'
                      : 'border-stone-200 bg-[#FAF9F7] text-[#1C1917] hover:bg-stone-100'
                  }`}
                >
                  <ShoppingBag className="h-3.5 w-3.5" />
                  <span>Takeaway</span>
                  {openOrderMap.has('Takeaway') && (
                    <span className="ml-0.5 font-mono text-[10px] font-bold text-amber-500">
                      ({openOrderMap.get('Takeaway')?.items.reduce((s, i) => s + i.quantity, 0)})
                    </span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setTableName('');
                    setShowCustomTableBox(false);
                  }}
                  className={`rounded-xl border px-2.5 py-1.5 text-xs font-semibold transition-colors min-h-[38px] ${
                    tableName === ''
                      ? 'border-stone-400 bg-stone-200/70 text-[#1C1917]'
                      : 'border-stone-200 bg-white text-stone-600 hover:bg-stone-50'
                  }`}
                >
                  No Table
                </button>

                <button
                  type="button"
                  onClick={() => setShowCustomTableBox((v) => !v)}
                  className="rounded-xl border border-stone-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-[#4E2A16] hover:bg-stone-50 min-h-[38px]"
                >
                  + Custom
                </button>
              </div>
            </div>

            {showCustomTableBox && (
              <div className="mb-3 flex items-center gap-2">
                <input
                  type="text"
                  dir="auto"
                  value={customTableInput}
                  onChange={(e) => setCustomTableInput(e.target.value)}
                  placeholder="Enter custom table name (e.g. Patio 1, VIP)"
                  className="flex-1 rounded-xl border border-stone-300 px-3 py-2 text-sm min-h-[42px]"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (customTableInput.trim()) {
                      handleSelectTable(customTableInput.trim());
                      setCustomTableInput('');
                    }
                  }}
                  className="rounded-xl bg-[#4E2A16] px-4 py-2 text-xs font-semibold text-white min-h-[42px]"
                >
                  Apply
                </button>
              </div>
            )}

            <div className="grid grid-cols-5 gap-2 sm:gap-2.5">
              {allTableButtons.map((tbl) => {
                const isSelected = tableName === tbl;
                const openTab = openOrderMap.get(tbl);
                const openQty = openTab
                  ? openTab.items.reduce((sum, i) => sum + i.quantity, 0)
                  : 0;
                return (
                  <button
                    key={tbl}
                    type="button"
                    onClick={() => handleSelectTable(tbl)}
                    className={`relative flex flex-col items-center justify-center rounded-xl border py-2.5 px-1 text-center transition-colors min-h-[60px] ${
                      isSelected
                        ? 'border-[#4E2A16] bg-[#4E2A16] text-white shadow-xs'
                        : openTab
                        ? 'border-amber-400 bg-amber-50/70 text-[#4E2A16] hover:bg-amber-100/70'
                        : 'border-stone-200 bg-[#FAF9F7] text-[#4E2A16] hover:bg-stone-100'
                    }`}
                  >
                    <Armchair
                      className={`h-4 w-4 mb-0.5 ${
                        isSelected ? 'text-white' : 'text-[#8C6D59]'
                      }`}
                    />
                    <span className="text-xs font-bold leading-tight truncate max-w-full">
                      {tbl}
                    </span>
                    {openTab && (
                      <span
                        className={`mt-0.5 text-[10px] font-semibold leading-none ${
                          isSelected ? 'text-amber-200' : 'text-amber-800'
                        }`}
                      >
                        {openQty} open
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </section>

          {/* 2. Visual Menu (Add Items) */}
          <section className="rounded-2xl border border-stone-200/90 bg-white p-4 sm:p-5 space-y-4">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <h3 className="text-sm font-bold text-[#1C1917]">Add Items</h3>

              <div className="flex items-center gap-2 flex-1 sm:max-w-xs">
                <div className="relative flex-1">
                  <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-stone-400" />
                  <input
                    type="search"
                    value={menuSearch}
                    onChange={(e) => setMenuSearch(e.target.value)}
                    placeholder="Search item..."
                    className="w-full rounded-xl border border-stone-200 bg-[#FAF9F7] py-2 pr-3 pl-9 text-sm text-[#1C1917] placeholder:text-stone-400 focus:border-[#4E2A16] focus:bg-white focus:outline-none min-h-[42px]"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => setShowCustomItemModal(true)}
                  className="inline-flex items-center gap-1 rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs font-semibold text-[#4E2A16] hover:bg-stone-50 min-h-[42px] whitespace-nowrap shrink-0"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Custom</span>
                </button>
              </div>
            </div>

            {/* Categories */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setActiveCategory(cat)}
                  className={`rounded-xl px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 min-h-[38px] ${
                    activeCategory === cat
                      ? 'bg-[#4E2A16] text-white'
                      : 'bg-[#FAF9F7] text-stone-700 hover:bg-stone-200/70'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Touch-Friendly Visual Item Grid */}
            {filteredMenu.length === 0 ? (
              <div className="rounded-xl border border-dashed border-stone-200 py-10 text-center">
                <p className="text-sm font-medium text-stone-600">No items match your search</p>
                <button
                  type="button"
                  onClick={() => setShowCustomItemModal(true)}
                  className="mt-3 inline-flex items-center gap-1.5 rounded-xl bg-[#4E2A16] px-4 py-2 text-xs font-semibold text-white min-h-[40px]"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Add Custom Item</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-4">
                {filteredMenu.map((menuItem) => {
                  const qtyInOrder = getItemCountInOrder(menuItem);
                  const displayName =
                    language === 'dv' && menuItem.nameDv
                      ? menuItem.nameDv
                      : menuItem.nameEn;
                  const price =
                    currency === 'USD' ? menuItem.priceUsd : menuItem.priceMvr;

                  return (
                    <button
                      key={menuItem.id}
                      type="button"
                      onClick={() => handleTapMenuItem(menuItem)}
                      className={`group relative flex flex-col items-center rounded-2xl border p-2.5 text-center transition-all active:scale-[0.98] ${
                        qtyInOrder > 0
                          ? 'border-[#4E2A16] bg-[#FAF6F0] ring-1 ring-[#4E2A16]/20'
                          : 'border-stone-200/90 bg-white hover:border-stone-300'
                      }`}
                    >
                      {qtyInOrder > 0 && (
                        <span className="absolute top-2 right-2 z-10 flex h-6 min-w-[24px] items-center justify-center rounded-full bg-[#4E2A16] px-1.5 font-mono text-xs font-bold text-white shadow-xs">
                          {qtyInOrder}
                        </span>
                      )}

                      <div className="h-20 w-full overflow-hidden rounded-xl bg-stone-100">
                        {menuItem.imageUrl ? (
                          <img
                            src={menuItem.imageUrl}
                            alt={displayName}
                            referrerPolicy="no-referrer"
                            className="h-full w-full object-cover transition-transform duration-200 group-hover:scale-105"
                          />
                        ) : (
                          <div className="flex h-full w-full items-center justify-center text-xs font-bold text-stone-400">
                            {menuItem.category}
                          </div>
                        )}
                      </div>

                      <div
                        dir="auto"
                        className={`mt-2 w-full text-xs font-bold text-[#1C1917] line-clamp-2 leading-snug ${
                          language === 'dv' ? 'font-thaana' : ''
                        }`}
                      >
                        {displayName}
                      </div>
                      <div className="font-mono-num mt-1 text-[11.5px] font-semibold text-[#522E17]">
                        {formatCurrency(price, currency)}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </section>
        </div>

        {/* RIGHT COLUMN: Order Summary, Customer/Invoice Options & Save/Share */}
        <div className="space-y-4 lg:col-span-5 lg:sticky lg:top-6">
          <section className="rounded-2xl border border-stone-200/90 bg-white p-4 sm:p-5 space-y-4">
            {/* Order Summary Header */}
            <div className="flex items-center justify-between gap-2 border-b border-stone-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-[#1C1917]">Order Summary</h3>
                <div className="mt-0.5 flex flex-wrap items-center gap-x-2 text-xs text-stone-600">
                  <span className="font-semibold text-[#4E2A16]">
                    {tableName ? `Table: ${tableName}` : 'Walk-in Order'}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-num">{invoiceNumber}</span>
                </div>
              </div>

              {items.length > 0 && (
                <button
                  type="button"
                  onClick={() => setItems([])}
                  className="inline-flex items-center gap-1 rounded-xl px-2.5 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-50 min-h-[38px]"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  <span>Clear All</span>
                </button>
              )}
            </div>

            {/* Selected Items List */}
            {items.length === 0 ? (
              <div className="rounded-xl bg-[#FAF9F7] px-4 py-8 text-center">
                <p className="text-sm font-medium text-stone-600">No items added yet</p>
                <p className="mt-1 text-xs text-stone-500">
                  Tap items on the menu or tap &ldquo;+ Custom&rdquo; to begin.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-stone-100 max-h-[340px] overflow-y-auto pr-1">
                {items.map((item, idx) => {
                  const lineTotal = calculateLineTotal(item.quantity, item.unitPrice);
                  return (
                    <div key={item.id} className="flex items-center gap-2.5 py-3">
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-stone-100 font-mono text-xs font-bold text-stone-600">
                        {idx + 1}
                      </span>

                      <div className="min-w-0 flex-1">
                        <input
                          type="text"
                          dir="auto"
                          value={item.description}
                          onChange={(e) =>
                            setItems((prev) =>
                              prev.map((it) =>
                                it.id === item.id ? { ...it, description: e.target.value } : it
                              )
                            )
                          }
                          aria-label="Item description"
                          className="w-full bg-transparent text-sm font-semibold text-[#1C1917] focus:outline-none focus:underline"
                        />
                        <div className="flex items-center gap-1.5 text-[11px] text-stone-500">
                          <span>@</span>
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            value={item.unitPrice}
                            onChange={(e) =>
                              setItems((prev) =>
                                prev.map((it) =>
                                  it.id === item.id
                                    ? { ...it, unitPrice: Math.max(0, Number(e.target.value) || 0) }
                                    : it
                                )
                              )
                            }
                            aria-label="Unit price"
                            className="w-20 rounded border border-stone-200 bg-stone-50 px-1.5 py-0.5 font-mono text-[11px] text-[#1C1917]"
                          />
                        </div>
                      </div>

                      {/* Large + and - touch buttons */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => updateItemQty(item.id, -1)}
                          className="flex h-10 w-10 items-center justify-center rounded-xl border border-stone-200 bg-[#FAF9F7] text-[#4E2A16] hover:bg-stone-200/70 active:scale-95"
                          aria-label={`Decrease quantity of ${item.description}`}
                        >
                          <Minus className="h-4 w-4" />
                        </button>
                        <span className="font-mono-num w-6 text-center text-sm font-bold text-[#1C1917]">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => updateItemQty(item.id, 1)}
                          className="flex h-10 w-10 items-center justify-center rounded-xl border border-stone-200 bg-[#FAF9F7] text-[#4E2A16] hover:bg-stone-200/70 active:scale-95"
                          aria-label={`Increase quantity of ${item.description}`}
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="font-mono-num w-20 text-end text-sm font-bold text-[#1C1917]">
                          {formatCurrency(lineTotal, currency)}
                        </span>
                        <button
                          type="button"
                          onClick={() => removeItem(item.id)}
                          className="flex h-9 w-8 items-center justify-center rounded-lg text-stone-400 hover:bg-rose-50 hover:text-rose-700"
                          aria-label={`Remove ${item.description}`}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Totals Strip */}
            <div className="rounded-xl border border-stone-200/80 bg-[#FAF9F7] p-3.5">
              <div className="grid grid-cols-3 items-center gap-2">
                <div>
                  <div className="text-[11px] font-medium text-stone-500">Subtotal</div>
                  <div className="font-mono-num text-sm font-bold text-[#1C1917]">
                    {formatCurrency(totals.subtotal, currency)}
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-1 text-[11px] font-medium text-stone-500">
                    <span>Discount</span>
                    <button
                      type="button"
                      onClick={() => setShowDiscountEditor((v) => !v)}
                      className="inline-flex h-6 w-6 items-center justify-center rounded-md hover:bg-stone-200/70 text-[#4E2A16]"
                      aria-label="Edit discount"
                    >
                      <Pencil className="h-3 w-3" />
                    </button>
                  </div>
                  <div className="font-mono-num text-sm font-bold text-[#1C1917]">
                    {formatCurrency(totals.discountAmount, currency)}
                  </div>
                </div>

                <div className="text-end">
                  <div className="text-[11px] font-medium text-stone-500">Total</div>
                  <div className="font-mono-num text-base font-bold text-[#4E2A16] sm:text-lg">
                    {formatCurrency(totals.grandTotal, currency)}
                  </div>
                </div>
              </div>

              {showDiscountEditor && (
                <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-stone-200 pt-3">
                  <div className="inline-flex rounded-lg border border-stone-200 bg-white p-0.5">
                    <button
                      type="button"
                      onClick={() => setDiscountType('fixed')}
                      className={`rounded-md px-2.5 py-1 text-xs font-semibold ${
                        discountType === 'fixed' ? 'bg-[#4E2A16] text-white' : 'text-stone-600'
                      }`}
                    >
                      {currency}
                    </button>
                    <button
                      type="button"
                      onClick={() => setDiscountType('percent')}
                      className={`rounded-md px-2.5 py-1 text-xs font-semibold ${
                        discountType === 'percent' ? 'bg-[#4E2A16] text-white' : 'text-stone-600'
                      }`}
                    >
                      %
                    </button>
                  </div>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={discountValue || ''}
                    onChange={(e) => setDiscountValue(Math.max(0, Number(e.target.value) || 0))}
                    placeholder="0"
                    className="w-28 rounded-lg border border-stone-300 bg-white px-2.5 py-1.5 font-mono text-sm min-h-[38px]"
                  />
                  {additionalChargeAmount > 0 && (
                    <span className="text-xs text-stone-600">
                      + Extra: {formatCurrency(additionalChargeAmount, currency)}
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Expandable Customer, Layout & Payment Details */}
            <div className="rounded-xl border border-stone-200/80">
              <button
                type="button"
                onClick={() => setShowMoreOptions((v) => !v)}
                className="flex w-full items-center justify-between px-4 py-3 text-xs font-bold text-[#1C1917] hover:bg-stone-50 min-h-[44px]"
              >
                <span className="flex items-center gap-2">
                  <SlidersHorizontal className="h-3.5 w-3.5 text-[#4E2A16]" />
                  <span>Customer, Receipt Style &amp; Payment Options</span>
                </span>
                {showMoreOptions ? (
                  <ChevronUp className="h-4 w-4 text-stone-500" />
                ) : (
                  <ChevronDown className="h-4 w-4 text-stone-500" />
                )}
              </button>

              {showMoreOptions && (
                <div className="space-y-4 border-t border-stone-100 p-4 text-xs">
                  {/* Customer Picker */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="font-bold text-stone-700">Customer</label>
                      {customerName.trim() && !customerId && (
                        <button
                          type="button"
                          onClick={() => void handleSaveNewCustomerInline()}
                          className="inline-flex items-center gap-1 font-semibold text-[#4E2A16] hover:underline"
                        >
                          <UserCheck className="h-3.5 w-3.5" />
                          Save Customer
                        </button>
                      )}
                    </div>
                    {customers.length > 0 && (
                      <select
                        value={customerId || ''}
                        onChange={(e) => handleSelectCustomer(e.target.value)}
                        className="w-full rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-medium min-h-[42px]"
                      >
                        <option value="">-- Select Saved Customer (Optional) --</option>
                        {customers.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name} {c.phone ? `(${c.phone})` : ''}
                          </option>
                        ))}
                      </select>
                    )}
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                      <input
                        type="text"
                        dir="auto"
                        value={customerName}
                        onChange={(e) => {
                          setCustomerName(e.target.value);
                          setCustomerId(undefined);
                        }}
                        placeholder="Customer name"
                        className="rounded-xl border border-stone-200 px-3 py-2 text-xs min-h-[40px]"
                      />
                      <input
                        type="tel"
                        dir="ltr"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="Phone (+960 ...)"
                        className="rounded-xl border border-stone-200 px-3 py-2 text-xs min-h-[40px]"
                      />
                    </div>
                  </div>

                  {/* Invoice Number, Date & Layout */}
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Invoice #</label>
                      <input
                        type="text"
                        value={invoiceNumber}
                        onChange={(e) => setInvoiceNumber(e.target.value)}
                        className="w-full rounded-xl border border-stone-200 px-3 py-2 font-mono text-xs min-h-[40px]"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Date</label>
                      <input
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full rounded-xl border border-stone-200 px-3 py-2 text-xs min-h-[40px]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-stone-700 mb-1">
                      Receipt / Invoice Format
                    </label>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setLayoutStyle('pos');
                          setPosWidth('58mm');
                        }}
                        className={`rounded-xl border py-2 text-xs font-semibold min-h-[40px] ${
                          layoutStyle === 'pos' && posWidth === '58mm'
                            ? 'border-[#4E2A16] bg-[#4E2A16] text-white'
                            : 'border-stone-200 bg-white text-stone-700'
                        }`}
                      >
                        POS 58mm
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setLayoutStyle('pos');
                          setPosWidth('80mm');
                        }}
                        className={`rounded-xl border py-2 text-xs font-semibold min-h-[40px] ${
                          layoutStyle === 'pos' && posWidth === '80mm'
                            ? 'border-[#4E2A16] bg-[#4E2A16] text-white'
                            : 'border-stone-200 bg-white text-stone-700'
                        }`}
                      >
                        POS 80mm
                      </button>
                      <button
                        type="button"
                        onClick={() => setLayoutStyle('a4')}
                        className={`rounded-xl border py-2 text-xs font-semibold min-h-[40px] ${
                          layoutStyle === 'a4'
                            ? 'border-[#4E2A16] bg-[#4E2A16] text-white'
                            : 'border-stone-200 bg-white text-stone-700'
                        }`}
                      >
                        A4 Invoice
                      </button>
                    </div>
                  </div>

                  {/* Payment Method & Status */}
                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Payment Method</label>
                      <select
                        value={paymentMethod}
                        onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                        className="w-full rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-medium min-h-[40px]"
                      >
                        <option value="cash">Cash</option>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="card">Card</option>
                        <option value="mobile_pay">Mobile Pay</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Payment Status</label>
                      <select
                        value={paymentStatus}
                        onChange={(e) => setPaymentStatus(e.target.value as PaymentStatus)}
                        className="w-full rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-medium min-h-[40px]"
                      >
                        <option value="UNPAID">Unpaid</option>
                        <option value="PAID">Paid</option>
                        <option value="PARTIALLY_PAID">Partially Paid</option>
                      </select>
                    </div>
                  </div>

                  {paymentStatus === 'PAID' && (
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">Payment Date</label>
                      <input
                        type="date"
                        value={paymentDate}
                        onChange={(e) => setPaymentDate(e.target.value)}
                        className="w-full rounded-xl border border-stone-200 px-3 py-2 text-xs min-h-[40px]"
                      />
                    </div>
                  )}

                  {paymentStatus === 'PARTIALLY_PAID' && (
                    <div className="grid grid-cols-2 gap-2.5 rounded-xl bg-amber-50 p-3">
                      <div>
                        <label className="block font-bold text-amber-900 mb-1">
                          Amount Received ({currency})
                        </label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={amountPaid || ''}
                          onChange={(e) => setAmountPaid(Math.max(0, Number(e.target.value) || 0))}
                          className="w-full rounded-lg border border-amber-300 bg-white px-2.5 py-1.5 font-mono text-xs min-h-[38px]"
                        />
                      </div>
                      <div>
                        <div className="font-bold text-amber-900 mb-1">Remaining Balance</div>
                        <div className="font-mono-num pt-2 text-sm font-bold text-amber-900">
                          {formatCurrency(totals.balanceDue, currency)}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Additional Charges */}
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">
                        Extra Charge Label
                      </label>
                      <input
                        type="text"
                        dir="auto"
                        value={additionalChargeLabel}
                        onChange={(e) => setAdditionalChargeLabel(e.target.value)}
                        placeholder="e.g. Delivery / Service"
                        className="w-full rounded-xl border border-stone-200 px-3 py-2 text-xs min-h-[40px]"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-stone-700 mb-1">
                        Extra Amount ({currency})
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={additionalChargeAmount || ''}
                        onChange={(e) =>
                          setAdditionalChargeAmount(Math.max(0, Number(e.target.value) || 0))
                        }
                        placeholder="0.00"
                        className="w-full rounded-xl border border-stone-200 px-3 py-2 font-mono text-xs min-h-[40px]"
                      />
                    </div>
                  </div>

                  {/* Bank Details Toggle */}
                  {bankAccounts.length > 0 && (
                    <div className="space-y-2 rounded-xl bg-stone-50 p-3">
                      <label className="flex items-center justify-between gap-2 cursor-pointer">
                        <span className="font-bold text-stone-700">
                          Show Bank Transfer Details
                        </span>
                        <input
                          type="checkbox"
                          checked={showBankDetails}
                          onChange={(e) => setShowBankDetails(e.target.checked)}
                          className="h-4 w-4 accent-[#4E2A16]"
                        />
                      </label>
                      {showBankDetails && (
                        <div className="space-y-1.5 pt-1">
                          {bankAccounts.map((b) => (
                            <label
                              key={b.id}
                              className="flex items-center gap-2 text-xs text-stone-700 cursor-pointer"
                            >
                              <input
                                type="checkbox"
                                checked={selectedBankIds.includes(b.id)}
                                onChange={(e) =>
                                  setSelectedBankIds((prev) =>
                                    e.target.checked
                                      ? [...prev, b.id]
                                      : prev.filter((id) => id !== b.id)
                                  )
                                }
                                className="h-4 w-4 accent-[#4E2A16]"
                              />
                              <span>
                                {b.bankName} — <span className="font-mono">{b.accountNumber}</span>
                              </span>
                            </label>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Optional Conversion & Notes */}
                  <label className="flex items-center justify-between gap-2 cursor-pointer">
                    <span className="font-medium text-stone-700">
                      Show {currency === 'USD' ? 'MVR' : 'USD'} Reference Conversion (1 USD ={' '}
                      {preferences.exchangeRateUsdToMvr} MVR)
                    </span>
                    <input
                      type="checkbox"
                      checked={showConversionReference}
                      onChange={(e) => setShowConversionReference(e.target.checked)}
                      className="h-4 w-4 accent-[#4E2A16]"
                    />
                  </label>

                  <div className="space-y-2">
                    <input
                      type="text"
                      dir="auto"
                      value={paymentInstructions}
                      onChange={(e) => setPaymentInstructions(e.target.value)}
                      placeholder="Payment instructions (optional)"
                      className="w-full rounded-xl border border-stone-200 px-3 py-2 text-xs min-h-[40px]"
                    />
                    <input
                      type="text"
                      dir="auto"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Order notes (optional)"
                      className="w-full rounded-xl border border-stone-200 px-3 py-2 text-xs min-h-[40px]"
                    />
                    <input
                      type="text"
                      dir="auto"
                      value={footerMessage}
                      onChange={(e) => setFooterMessage(e.target.value)}
                      placeholder="Custom footer message (optional)"
                      className="w-full rounded-xl border border-stone-200 px-3 py-2 text-xs min-h-[40px]"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Hold / Save Open Table Order Button */}
            {!isEditingExisting && tableName.trim() !== '' && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void handleSaveOpenTableOrder()}
                  className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-amber-700/30 bg-amber-50 px-4 py-2.5 text-xs font-bold text-amber-900 hover:bg-amber-100 min-h-[44px]"
                >
                  <BookmarkCheck className="h-4 w-4" />
                  <span>Save Open Order ({tableName})</span>
                </button>
                {openOrderMap.has(tableName) && (
                  <button
                    type="button"
                    onClick={() => {
                      void onDeleteOpenOrder(tableName);
                      setItems([]);
                      onNotify(`Cleared open order for ${tableName}.`, 'info');
                    }}
                    className="rounded-xl border border-stone-200 bg-white px-3 py-2.5 text-xs font-semibold text-stone-600 hover:bg-stone-50 min-h-[44px]"
                  >
                    Discard Tab
                  </button>
                )}
              </div>
            )}

            {/* Primary Save & Preview/Share Actions */}
            <div className="space-y-2.5 pt-1">
              <button
                type="button"
                disabled={isSaving}
                onClick={() => void handleSaveFinalInvoice()}
                className="flex w-full items-center justify-center gap-2.5 rounded-xl bg-[#4E2A16] px-5 py-3.5 text-base font-bold text-white shadow-sm transition-colors hover:bg-[#3E2723] disabled:opacity-60 min-h-[52px]"
              >
                <Save className="h-5 w-5" />
                <span>{isSaving ? 'Saving...' : isEditingExisting ? 'Update Invoice' : 'Save Invoice'}</span>
              </button>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => onOpenPreviewModal(currentDraftInvoice)}
                  className="flex items-center justify-center gap-2 rounded-xl bg-[#EFE6DC] px-4 py-3 text-sm font-bold text-[#3E2723] transition-colors hover:bg-[#E6D9CA] min-h-[46px]"
                >
                  <Eye className="h-4 w-4" />
                  <span>Preview</span>
                </button>
                <button
                  type="button"
                  disabled={isSharing}
                  onClick={() => void handleQuickShareCurrent()}
                  className="flex items-center justify-center gap-2 rounded-xl bg-[#DCECE1] px-4 py-3 text-sm font-bold text-[#14532D] transition-colors hover:bg-[#CDE3D4] disabled:opacity-60 min-h-[46px]"
                >
                  <Share2 className="h-4 w-4" />
                  <span>{isSharing ? 'Exporting...' : 'Share / Send'}</span>
                </button>
              </div>
            </div>
          </section>
        </div>
      </div>

      {/* Hidden offscreen render target for instant Share/Send PNG from builder */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed -left-[9999px] top-0 opacity-100"
      >
        <InvoiceDocument
          invoice={currentDraftInvoice}
          businessProfile={businessProfile}
          bankAccounts={bankAccounts}
          translations={translations}
          exchangeRateUsdToMvr={preferences.exchangeRateUsdToMvr}
          exportRef={hiddenExportRef}
        />
      </div>

      {/* Add Custom Item Modal */}
      {showCustomItemModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
        >
          <form
            onSubmit={handleAddCustomItem}
            className="w-full max-w-sm rounded-2xl border border-stone-200 bg-white p-5 shadow-xl space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-[#1C1917]">Add Custom Item</h3>
              <button
                type="button"
                onClick={() => setShowCustomItemModal(false)}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-stone-500 hover:bg-stone-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div>
              <label className="block text-xs font-semibold text-stone-600 mb-1">
                Item Name / Description (English or Dhivehi) *
              </label>
              <input
                type="text"
                required
                dir="auto"
                value={customItemDesc}
                onChange={(e) => setCustomItemDesc(e.target.value)}
                placeholder="e.g. Tuna Pasta / މަސްޕާސްތާ"
                className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Quantity
                </label>
                <input
                  type="number"
                  min="1"
                  step="1"
                  value={customItemQty}
                  onChange={(e) => setCustomItemQty(Math.max(1, Number(e.target.value) || 1))}
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 font-mono text-sm min-h-[44px]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Unit Price ({currency}) *
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  step="0.01"
                  value={customItemPrice}
                  onChange={(e) => setCustomItemPrice(e.target.value)}
                  placeholder="0.00"
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 font-mono text-sm min-h-[44px]"
                />
              </div>
            </div>
            <button
              type="submit"
              className="w-full rounded-xl bg-[#4E2A16] py-3 text-sm font-bold text-white hover:bg-[#3E2723] min-h-[46px]"
            >
              Add to Order
            </button>
          </form>
        </div>
      )}

      {/* Post-Save Payment & Receipt Modal */}
      {showPostSaveModal && lastSavedInvoice && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md rounded-2xl border border-stone-200 bg-white p-6 shadow-xl space-y-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Saved {lastSavedInvoice.invoiceNumber}</span>
                </div>
                <h3 className="mt-1 text-lg font-bold text-[#1C1917]">
                  Payment &amp; Receipt Export
                </h3>
                <p className="mt-0.5 text-xs text-stone-500">
                  Total:{' '}
                  <span className="font-mono font-bold text-[#1C1917]">
                    {formatCurrency(
                      calculateInvoiceTotals(
                        lastSavedInvoice.items,
                        lastSavedInvoice.discountType,
                        lastSavedInvoice.discountValue,
                        lastSavedInvoice.additionalChargeAmount,
                        lastSavedInvoice.amountPaid,
                        lastSavedInvoice.paymentStatus
                      ).grandTotal,
                      lastSavedInvoice.currency
                    )}
                  </span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowPostSaveModal(false)}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-stone-500 hover:bg-stone-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Payment Status Quick Buttons */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-stone-600">Mark Payment Status</div>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => void updateSavedInvoiceStatus('PAID')}
                  className={`flex flex-col items-center justify-center gap-1 rounded-xl border py-3 px-2 text-xs font-bold min-h-[56px] ${
                    lastSavedInvoice.paymentStatus === 'PAID'
                      ? 'border-emerald-700 bg-emerald-50 text-emerald-800'
                      : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  <CheckCircle2 className="h-4 w-4 text-emerald-700" />
                  <span>Paid</span>
                </button>
                <button
                  type="button"
                  onClick={() => void updateSavedInvoiceStatus('PARTIALLY_PAID')}
                  className={`flex flex-col items-center justify-center gap-1 rounded-xl border py-3 px-2 text-xs font-bold min-h-[56px] ${
                    lastSavedInvoice.paymentStatus === 'PARTIALLY_PAID'
                      ? 'border-amber-600 bg-amber-50 text-amber-900'
                      : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  <Clock className="h-4 w-4 text-amber-600" />
                  <span>Partial</span>
                </button>
                <button
                  type="button"
                  onClick={() => void updateSavedInvoiceStatus('UNPAID')}
                  className={`flex flex-col items-center justify-center gap-1 rounded-xl border py-3 px-2 text-xs font-bold min-h-[56px] ${
                    lastSavedInvoice.paymentStatus === 'UNPAID'
                      ? 'border-stone-800 bg-stone-100 text-stone-900'
                      : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  <span>Unpaid</span>
                </button>
              </div>
            </div>

            {lastSavedInvoice.paymentStatus === 'PARTIALLY_PAID' && (
              <div className="flex items-center gap-3 rounded-xl bg-amber-50 p-3">
                <div className="flex-1">
                  <label className="block text-[11px] font-bold text-amber-900 mb-1">
                    Amount Paid ({lastSavedInvoice.currency})
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={lastSavedInvoice.amountPaid || ''}
                    onChange={(e) => {
                      const val = Math.max(0, Number(e.target.value) || 0);
                      const updated = { ...lastSavedInvoice, amountPaid: val };
                      setLastSavedInvoice(updated);
                      setAmountPaid(val);
                      void onSaveInvoice(updated, false);
                    }}
                    className="w-full rounded-lg border border-amber-300 bg-white px-2.5 py-1.5 font-mono text-sm min-h-[38px]"
                  />
                </div>
                <div className="text-end">
                  <div className="text-[11px] font-bold text-amber-900">Balance Due</div>
                  <div className="font-mono-num text-sm font-bold text-amber-900 mt-1">
                    {formatCurrency(
                      calculateInvoiceTotals(
                        lastSavedInvoice.items,
                        lastSavedInvoice.discountType,
                        lastSavedInvoice.discountValue,
                        lastSavedInvoice.additionalChargeAmount,
                        lastSavedInvoice.amountPaid,
                        'PARTIALLY_PAID'
                      ).balanceDue,
                      lastSavedInvoice.currency
                    )}
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-2.5 pt-1">
              <button
                type="button"
                onClick={() => {
                  setShowPostSaveModal(false);
                  onOpenPreviewModal(lastSavedInvoice);
                }}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#4E2A16] px-4 py-3 text-sm font-bold text-white hover:bg-[#3E2723] min-h-[48px]"
              >
                <Eye className="h-4 w-4" />
                <span>Preview, Download &amp; Share Receipt PNG</span>
              </button>

              {!isEditingExisting && (
                <button
                  type="button"
                  onClick={resetForNextOrder}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-sm font-semibold text-[#1C1917] hover:bg-stone-50 min-h-[44px]"
                >
                  <Plus className="h-4 w-4" />
                  <span>Start Next Order</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
