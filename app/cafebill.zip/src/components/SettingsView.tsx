import React, { useEffect, useState } from 'react';
import {
  Building2,
  Check,
  DatabaseBackup,
  Download,
  ImagePlus,
  Languages,
  Landmark,
  LifeBuoy,
  Mail,
  Plus,
  RotateCcw,
  Trash2,
  Type,
  Upload,
  UserCog,
  UtensilsCrossed,
} from 'lucide-react';
import { DEFAULT_TRANSLATIONS, TRANSLATION_FIELD_META } from '../i18n/translations';
import { CATEGORY_IMAGES, DEFAULT_QUICK_MENU } from '../storage/db';
import { SUPPORT_EMAIL, type AuthUser } from '../types/auth';
import type {
  AppPreferences,
  BackupPayload,
  BankAccount,
  BusinessProfile,
  InvoiceLabels,
  MenuCategory,
  QuickMenuItem,
  TranslationMap,
} from '../types/invoice';
import { createId } from '../utils/calculations';
import { AccountProfileSection } from './AccountProfileSection';
import { ConfirmModal } from './ConfirmModal';
import { HelpSupportSection } from './HelpSupportSection';
import { PWAInstallButton } from './PWAInstallButton';

interface SettingsViewProps {
  user: AuthUser;
  businessProfile: BusinessProfile;
  bankAccounts: BankAccount[];
  translations: TranslationMap;
  preferences: AppPreferences;
  quickMenuItems: QuickMenuItem[];
  onUserUpdated: (user: AuthUser) => void;
  onLogout: () => void;
  onAccountDeleted: () => void;
  onSyncToCloud: () => Promise<void>;
  onSaveBusinessProfile: (profile: BusinessProfile) => Promise<void>;
  onSaveBankAccounts: (banks: BankAccount[]) => Promise<void>;
  onSaveTranslations: (translations: TranslationMap) => Promise<void>;
  onSavePreferences: (prefs: AppPreferences) => Promise<void>;
  onSaveQuickMenu: (items: QuickMenuItem[]) => Promise<void>;
  onExportBackup: () => Promise<void>;
  onImportBackup: (payload: BackupPayload, mode: 'replace' | 'merge') => Promise<void>;
  onNotify: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

type SettingsTab = 'business' | 'bank' | 'languages' | 'menu' | 'account' | 'help' | 'backup';

const MENU_CATEGORIES: MenuCategory[] = [
  'Coffee',
  'Tea',
  'Cold Drinks',
  'Food',
  'Desserts',
  'Others',
];

async function resizeLogoToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxSide = 400;
        const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(typeof reader.result === 'string' ? reader.result : '');
          return;
        }
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/png'));
      };
      img.onerror = () => reject(new Error('Invalid image file'));
      img.src = typeof reader.result === 'string' ? reader.result : '';
    };
    reader.onerror = () => reject(new Error('Could not read file'));
    reader.readAsDataURL(file);
  });
}

async function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(typeof reader.result === 'string' ? reader.result : '');
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  user,
  businessProfile,
  bankAccounts,
  translations,
  preferences,
  quickMenuItems,
  onUserUpdated,
  onLogout,
  onAccountDeleted,
  onSyncToCloud,
  onSaveBusinessProfile,
  onSaveBankAccounts,
  onSaveTranslations,
  onSavePreferences,
  onSaveQuickMenu,
  onExportBackup,
  onImportBackup,
  onNotify,
}) => {
  const [activeTab, setActiveTab] = useState<SettingsTab>('business');

  // Business form state
  const [profile, setProfile] = useState<BusinessProfile>(businessProfile);
  const [prefs, setPrefs] = useState<AppPreferences>(preferences);

  // Bank form state
  const [editingBank, setEditingBank] = useState<BankAccount | null>(null);
  const [bankName, setBankName] = useState('');
  const [accountHolderName, setAccountHolderName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [branch, setBranch] = useState('');
  const [instructions, setInstructions] = useState('');
  const [showBankForm, setShowBankForm] = useState(false);

  // Translations state
  const [transDraft, setTransDraft] = useState<TranslationMap>(translations);

  // Menu items state
  const [menuDraft, setMenuDraft] = useState<QuickMenuItem[]>(quickMenuItems);
  const [newMenuNameEn, setNewMenuNameEn] = useState('');
  const [newMenuNameDv, setNewMenuNameDv] = useState('');
  const [newMenuCategory, setNewMenuCategory] = useState<MenuCategory>('Coffee');
  const [newMenuPriceMvr, setNewMenuPriceMvr] = useState('');
  const [newMenuPriceUsd, setNewMenuPriceUsd] = useState('');
  const [newMenuImageUrl, setNewMenuImageUrl] = useState('');

  // Backup restore confirmation
  const [pendingBackup, setPendingBackup] = useState<BackupPayload | null>(null);

  useEffect(() => {
    setProfile(businessProfile);
  }, [businessProfile]);

  useEffect(() => {
    setPrefs(preferences);
  }, [preferences]);

  useEffect(() => {
    setTransDraft(translations);
  }, [translations]);

  useEffect(() => {
    setMenuDraft(quickMenuItems);
  }, [quickMenuItems]);

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await resizeLogoToDataUrl(file);
      const updated = { ...profile, logoDataUrl: dataUrl };
      setProfile(updated);
      await onSaveBusinessProfile(updated);
      onNotify('Business logo updated.', 'success');
    } catch {
      onNotify('Please choose a valid PNG, JPG, or WEBP image.', 'error');
    }
    e.target.value = '';
  };

  const handleSaveBusiness = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSaveBusinessProfile(profile);
    await onSavePreferences(prefs);
    onNotify('Business settings saved.', 'success');
  };

  const openAddBank = () => {
    setEditingBank(null);
    setBankName('');
    setAccountHolderName('');
    setAccountNumber('');
    setBranch('');
    setInstructions('');
    setShowBankForm(true);
  };

  const openEditBank = (b: BankAccount) => {
    setEditingBank(b);
    setBankName(b.bankName);
    setAccountHolderName(b.accountHolderName);
    setAccountNumber(b.accountNumber);
    setBranch(b.branch || '');
    setInstructions(b.instructions || '');
    setShowBankForm(true);
  };

  const submitBank = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bankName.trim() || !accountNumber.trim()) return;
    const nextBank: BankAccount = {
      id: editingBank?.id || createId('bank'),
      bankName: bankName.trim(),
      accountHolderName: accountHolderName.trim(),
      accountNumber: accountNumber.trim(),
      branch: branch.trim() || undefined,
      instructions: instructions.trim() || undefined,
      isDefault: editingBank ? editingBank.isDefault : bankAccounts.length === 0,
    };
    const nextList = editingBank
      ? bankAccounts.map((b) => (b.id === editingBank.id ? nextBank : b))
      : [...bankAccounts, nextBank];
    await onSaveBankAccounts(nextList);
    setShowBankForm(false);
    onNotify('Bank account saved.', 'success');
  };

  const setDefaultBank = async (id: string) => {
    const next = bankAccounts.map((b) => ({ ...b, isDefault: b.id === id }));
    await onSaveBankAccounts(next);
    onNotify('Default bank account updated.', 'success');
  };

  const deleteBank = async (id: string) => {
    const next = bankAccounts.filter((b) => b.id !== id);
    await onSaveBankAccounts(next);
    onNotify('Bank account removed.', 'info');
  };

  const handleFontUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await readFileAsDataUrl(file);
      const nextPrefs: AppPreferences = {
        ...prefs,
        customFontName: file.name,
        customFontDataUrl: dataUrl,
      };
      setPrefs(nextPrefs);
      await onSavePreferences(nextPrefs);
      onNotify(`Custom Dhivehi font "${file.name}" applied.`, 'success');
    } catch {
      onNotify('Could not load font file.', 'error');
    }
    e.target.value = '';
  };

  const resetCustomFont = async () => {
    const nextPrefs: AppPreferences = {
      ...prefs,
      customFontName: undefined,
      customFontDataUrl: undefined,
    };
    setPrefs(nextPrefs);
    await onSavePreferences(nextPrefs);
    onNotify('Reverted to built-in Noto Sans Thaana font.', 'info');
  };

  const updateTranslationField = (
    lang: 'en' | 'dv',
    key: keyof InvoiceLabels,
    value: string
  ) => {
    setTransDraft((prev) => ({
      ...prev,
      [lang]: {
        ...prev[lang],
        [key]: value,
      },
    }));
  };

  const handleSaveTranslations = async () => {
    await onSaveTranslations(transDraft);
    onNotify('Invoice translations saved.', 'success');
  };

  const handleResetTranslations = async () => {
    setTransDraft(DEFAULT_TRANSLATIONS);
    await onSaveTranslations(DEFAULT_TRANSLATIONS);
    onNotify('Translations reset to defaults.', 'info');
  };

  const handleMenuPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await resizeLogoToDataUrl(file);
      setNewMenuImageUrl(url);
    } catch {
      onNotify('Invalid image file.', 'error');
    }
    e.target.value = '';
  };

  const handleAddMenuItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMenuNameEn.trim()) return;
    const item: QuickMenuItem = {
      id: createId('qm'),
      nameEn: newMenuNameEn.trim(),
      nameDv: newMenuNameDv.trim() || undefined,
      category: newMenuCategory,
      imageUrl: newMenuImageUrl || CATEGORY_IMAGES[newMenuCategory],
      priceMvr: Math.max(0, Number(newMenuPriceMvr) || 0),
      priceUsd: Math.max(0, Number(newMenuPriceUsd) || 0),
    };
    const next = [...menuDraft, item];
    setMenuDraft(next);
    await onSaveQuickMenu(next);
    setNewMenuNameEn('');
    setNewMenuNameDv('');
    setNewMenuPriceMvr('');
    setNewMenuPriceUsd('');
    setNewMenuImageUrl('');
    onNotify(`Added "${item.nameEn}" to POS menu.`, 'success');
  };

  const handleRemoveMenuItem = async (id: string) => {
    const next = menuDraft.filter((m) => m.id !== id);
    setMenuDraft(next);
    await onSaveQuickMenu(next);
    onNotify('Menu item removed.', 'info');
  };

  const handleUpdateMenuPrice = (
    id: string,
    field: 'priceMvr' | 'priceUsd',
    value: string
  ) => {
    const parsed = Math.max(0, Number(value) || 0);
    setMenuDraft((prev) =>
      prev.map((m) => (m.id === id ? { ...m, [field]: parsed } : m))
    );
  };

  const handleSaveMenuPrices = async () => {
    await onSaveQuickMenu(menuDraft);
    onNotify('Menu item prices saved.', 'success');
  };

  const handleResetDefaultMenu = async () => {
    setMenuDraft(DEFAULT_QUICK_MENU);
    await onSaveQuickMenu(DEFAULT_QUICK_MENU);
    onNotify('POS menu reset to default items.', 'info');
  };

  const handleBackupFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as BackupPayload;
      if (!parsed || !parsed.data) {
        throw new Error('Invalid format');
      }
      setPendingBackup(parsed);
    } catch {
      onNotify('Invalid JSON backup file.', 'error');
    }
    e.target.value = '';
  };

  return (
    <div className="space-y-5">
      {/* Settings Section Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto rounded-2xl border border-stone-200/90 bg-white p-1.5">
        {(
          [
            { id: 'business', label: 'Business', icon: Building2 },
            { id: 'bank', label: 'Bank & Currency', icon: Landmark },
            { id: 'languages', label: 'Languages & Font', icon: Languages },
            { id: 'menu', label: 'POS Menu', icon: UtensilsCrossed },
            { id: 'account', label: 'Account & Profile', icon: UserCog },
            { id: 'help', label: 'Help & Support', icon: LifeBuoy },
            { id: 'backup', label: 'App & Backup', icon: DatabaseBackup },
          ] as { id: SettingsTab; label: string; icon: React.ComponentType<{ className?: string }> }[]
        ).map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`inline-flex items-center gap-2 rounded-xl px-3.5 py-2.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 min-h-[42px] ${
                active
                  ? 'bg-[#2C1B18] text-white'
                  : 'text-stone-600 hover:bg-stone-100 hover:text-[#1C1917]'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: BUSINESS PROFILE */}
      {activeTab === 'business' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <form
            onSubmit={(e) => void handleSaveBusiness(e)}
            className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4 lg:col-span-7"
          >
            <h3 className="text-base font-bold text-[#1C1917]">Business Profile</h3>

            {/* Logo Upload */}
            <div className="flex flex-wrap items-center gap-4 rounded-xl border border-stone-200 bg-[#FAF9F7] p-4">
              <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-stone-200 bg-white">
                {profile.logoDataUrl ? (
                  <img
                    src={profile.logoDataUrl}
                    alt="Business Logo"
                    className="h-full w-full object-contain p-1"
                  />
                ) : (
                  <ImagePlus className="h-6 w-6 text-stone-400" />
                )}
              </div>
              <div className="flex-1 min-w-[180px] space-y-2">
                <div className="text-xs font-bold text-[#1C1917]">
                  Business Logo (PNG, JPG, WEBP)
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-xl bg-[#2C1B18] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#3E2723] min-h-[40px]">
                    <Upload className="h-3.5 w-3.5" />
                    <span>Upload Logo</span>
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      onChange={(e) => void handleLogoUpload(e)}
                      className="hidden"
                    />
                  </label>
                  {profile.logoDataUrl && (
                    <button
                      type="button"
                      onClick={() => {
                        const next = { ...profile, logoDataUrl: undefined };
                        setProfile(next);
                        void onSaveBusinessProfile(next);
                      }}
                      className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-50 min-h-[40px]"
                    >
                      Remove
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Business Name *
                </label>
                <input
                  type="text"
                  required
                  dir="auto"
                  value={profile.name}
                  onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Address
                </label>
                <input
                  type="text"
                  dir="auto"
                  value={profile.address || ''}
                  onChange={(e) => setProfile({ ...profile, address: e.target.value })}
                  placeholder="Orchid Magu, Male', Maldives"
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  dir="ltr"
                  value={profile.phone || ''}
                  onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                  placeholder="+960 330-0000"
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  dir="ltr"
                  value={profile.email || ''}
                  onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  placeholder="hello@mycafe.mv"
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Instagram / Social Handle (Optional)
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={profile.socialHandle || ''}
                  onChange={(e) => setProfile({ ...profile, socialHandle: e.target.value })}
                  placeholder="@mycafe.mv"
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Business Registration No. (Optional)
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={profile.registrationNumber || ''}
                  onChange={(e) =>
                    setProfile({ ...profile, registrationNumber: e.target.value })
                  }
                  placeholder="SP-0000-2026"
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Default Footer Message (English)
                </label>
                <input
                  type="text"
                  value={profile.defaultFooterEn}
                  onChange={(e) =>
                    setProfile({ ...profile, defaultFooterEn: e.target.value })
                  }
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Default Footer Message (Dhivehi)
                </label>
                <input
                  type="text"
                  dir="rtl"
                  value={profile.defaultFooterDv}
                  onChange={(e) =>
                    setProfile({ ...profile, defaultFooterDv: e.target.value })
                  }
                  className="font-thaana w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Invoice Prefix
                </label>
                <input
                  type="text"
                  value={prefs.invoicePrefix}
                  onChange={(e) => setPrefs({ ...prefs, invoicePrefix: e.target.value })}
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 font-mono text-sm min-h-[44px]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Next Invoice Number
                </label>
                <input
                  type="number"
                  min="1"
                  value={prefs.nextInvoiceSequence}
                  onChange={(e) =>
                    setPrefs({
                      ...prefs,
                      nextInvoiceSequence: Math.max(1, Number(e.target.value) || 1),
                    })
                  }
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 font-mono text-sm min-h-[44px]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-xl bg-[#2C1B18] px-5 py-3 text-sm font-bold text-white hover:bg-[#3E2723] min-h-[46px]"
            >
              <Check className="h-4 w-4" />
              <span>Save Business Profile</span>
            </button>
          </form>

          {/* Live Invoice Header Preview */}
          <div className="rounded-2xl border border-stone-200/90 bg-white p-5 lg:col-span-5 h-fit">
            <div className="text-xs font-bold text-stone-500 mb-3">
              Live Invoice Header Preview
            </div>
            <div className="rounded-xl border border-stone-200 bg-white p-5 shadow-xs">
              <div className="flex items-start gap-3">
                {profile.logoDataUrl && (
                  <img
                    src={profile.logoDataUrl}
                    alt={profile.name}
                    className="h-14 w-14 shrink-0 rounded-lg border border-stone-200 object-contain p-1"
                  />
                )}
                <div className="min-w-0 flex-1">
                  <div dir="auto" className="text-lg font-bold text-[#1C1917] break-words">
                    {profile.name || 'CafePOS'}
                  </div>
                  {profile.address && (
                    <div dir="auto" className="text-xs text-stone-600 mt-0.5">
                      {profile.address}
                    </div>
                  )}
                  <div className="mt-1 flex flex-wrap gap-x-2 text-xs text-stone-500">
                    {profile.phone && <span>{profile.phone}</span>}
                    {profile.email && <span>{profile.email}</span>}
                    {profile.socialHandle && <span>{profile.socialHandle}</span>}
                  </div>
                  {profile.registrationNumber && (
                    <div className="mt-1 text-[11px] text-stone-500">
                      Reg No: {profile.registrationNumber}
                    </div>
                  )}
                </div>
              </div>
              <div className="mt-4 border-t border-dashed border-stone-300 pt-3 text-center text-xs text-stone-500">
                <p>{profile.defaultFooterEn}</p>
                <p dir="rtl" className="font-thaana mt-1">
                  {profile.defaultFooterDv}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: BANK & CURRENCY */}
      {activeTab === 'bank' && (
        <div className="space-y-5">
          <div className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-[#1C1917]">Bank Transfer Accounts</h3>
                <p className="text-xs text-stone-500">
                  Add one or more bank accounts (e.g. BML, MIB) to show on invoices.
                </p>
              </div>
              <button
                type="button"
                onClick={openAddBank}
                className="inline-flex items-center gap-1.5 rounded-xl bg-[#2C1B18] px-4 py-2.5 text-xs font-bold text-white hover:bg-[#3E2723] min-h-[42px]"
              >
                <Plus className="h-4 w-4" />
                <span>Add Bank Account</span>
              </button>
            </div>

            {showBankForm && (
              <form
                onSubmit={(e) => void submitBank(e)}
                className="rounded-xl border border-stone-200 bg-[#FAF9F7] p-4 space-y-3"
              >
                <h4 className="text-sm font-bold text-[#1C1917]">
                  {editingBank ? 'Edit Bank Account' : 'New Bank Account'}
                </h4>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-semibold text-stone-600 mb-1">
                      Bank Name *
                    </label>
                    <input
                      type="text"
                      required
                      dir="auto"
                      value={bankName}
                      onChange={(e) => setBankName(e.target.value)}
                      placeholder="e.g. Bank of Maldives (BML)"
                      className="w-full rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm min-h-[42px]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-600 mb-1">
                      Account Holder Name *
                    </label>
                    <input
                      type="text"
                      required
                      dir="auto"
                      value={accountHolderName}
                      onChange={(e) => setAccountHolderName(e.target.value)}
                      placeholder="Account name"
                      className="w-full rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm min-h-[42px]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-600 mb-1">
                      Account Number *
                    </label>
                    <input
                      type="text"
                      required
                      dir="ltr"
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      placeholder="7730000000000"
                      className="w-full rounded-xl border border-stone-300 bg-white px-3 py-2 font-mono text-sm min-h-[42px]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-600 mb-1">
                      Branch (Optional)
                    </label>
                    <input
                      type="text"
                      dir="auto"
                      value={branch}
                      onChange={(e) => setBranch(e.target.value)}
                      placeholder="Male' Main Branch"
                      className="w-full rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm min-h-[42px]"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-stone-600 mb-1">
                      Additional Payment Instructions (Optional)
                    </label>
                    <input
                      type="text"
                      dir="auto"
                      value={instructions}
                      onChange={(e) => setInstructions(e.target.value)}
                      placeholder="Please send transfer slip via WhatsApp"
                      className="w-full rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm min-h-[42px]"
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowBankForm(false)}
                    className="rounded-xl border border-stone-300 bg-white px-4 py-2 text-xs font-semibold text-stone-700 min-h-[40px]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="rounded-xl bg-[#2C1B18] px-4 py-2 text-xs font-bold text-white min-h-[40px]"
                  >
                    Save Bank Account
                  </button>
                </div>
              </form>
            )}

            {bankAccounts.length === 0 ? (
              <p className="rounded-xl bg-stone-50 p-6 text-center text-xs text-stone-500">
                No bank accounts configured yet. Add BML, MIB, or any other account above.
              </p>
            ) : (
              <div className="divide-y divide-stone-100 rounded-xl border border-stone-200">
                {bankAccounts.map((bank) => (
                  <div
                    key={bank.id}
                    className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-[#1C1917]">{bank.bankName}</span>
                        {bank.isDefault && (
                          <span className="text-xs font-bold text-emerald-700">· Default</span>
                        )}
                      </div>
                      <div className="text-xs text-stone-600 mt-0.5">
                        {bank.accountHolderName} ·{' '}
                        <span className="font-mono font-bold text-[#1C1917]">
                          {bank.accountNumber}
                        </span>
                        {bank.branch ? ` · ${bank.branch}` : ''}
                      </div>
                      {bank.instructions && (
                        <div className="text-xs text-stone-500 mt-0.5">{bank.instructions}</div>
                      )}
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {!bank.isDefault && (
                        <button
                          type="button"
                          onClick={() => void setDefaultBank(bank.id)}
                          className="rounded-xl border border-stone-200 px-3 py-1.5 text-xs font-semibold text-stone-700 hover:bg-stone-50 min-h-[38px]"
                        >
                          Set Default
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => openEditBank(bank)}
                        className="rounded-xl border border-stone-200 px-3 py-1.5 text-xs font-semibold text-stone-700 hover:bg-stone-50 min-h-[38px]"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={() => void deleteBank(bank.id)}
                        className="rounded-xl border border-rose-200 px-2.5 py-1.5 text-xs font-semibold text-rose-700 hover:bg-rose-50 min-h-[38px]"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Currency & Default Preferences */}
          <div className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4">
            <h3 className="text-base font-bold text-[#1C1917]">Currency &amp; Invoice Defaults</h3>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Default Currency
                </label>
                <select
                  value={prefs.defaultCurrency}
                  onChange={(e) =>
                    setPrefs({
                      ...prefs,
                      defaultCurrency: e.target.value as 'MVR' | 'USD',
                    })
                  }
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                >
                  <option value="MVR">MVR (Maldivian Rufiyaa)</option>
                  <option value="USD">USD (US Dollar)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Default Language
                </label>
                <select
                  value={prefs.defaultLanguage}
                  onChange={(e) =>
                    setPrefs({
                      ...prefs,
                      defaultLanguage: e.target.value as 'en' | 'dv',
                    })
                  }
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                >
                  <option value="en">English</option>
                  <option value="dv">Dhivehi (ދިވެހި)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  USD to MVR Rate (Optional Ref.)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="1"
                  value={prefs.exchangeRateUsdToMvr}
                  onChange={(e) =>
                    setPrefs({
                      ...prefs,
                      exchangeRateUsdToMvr: Math.max(1, Number(e.target.value) || 15.42),
                    })
                  }
                  className="w-full rounded-xl border border-stone-300 px-3 py-2.5 font-mono text-sm min-h-[44px]"
                />
              </div>
            </div>

            <label className="flex items-center gap-2.5 text-sm text-stone-700 cursor-pointer">
              <input
                type="checkbox"
                checked={prefs.defaultShowBankDetails}
                onChange={(e) =>
                  setPrefs({ ...prefs, defaultShowBankDetails: e.target.checked })
                }
                className="h-4 w-4 accent-[#2C1B18]"
              />
              <span>Show bank transfer details on new invoices by default</span>
            </label>

            <button
              type="button"
              onClick={() => {
                void onSavePreferences(prefs);
                onNotify('Currency & default preferences saved.', 'success');
              }}
              className="rounded-xl bg-[#2C1B18] px-5 py-2.5 text-sm font-bold text-white hover:bg-[#3E2723] min-h-[44px]"
            >
              Save Defaults
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: LANGUAGES & CUSTOM DHIVEHI FONT */}
      {activeTab === 'languages' && (
        <div className="space-y-5">
          {/* Custom Dhivehi Font Card */}
          <div className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h3 className="flex items-center gap-2 text-base font-bold text-[#1C1917]">
                  <Type className="h-4 w-4 text-[#4E2A16]" />
                  <span>Dhivehi Thaana Font</span>
                </h3>
                <p className="mt-0.5 text-xs text-stone-500">
                  Active font:{' '}
                  <strong className="text-[#1C1917]">
                    {prefs.customFontName || 'Dhanbumaa Regular (Built-in Default)'}
                  </strong>
                </p>
                {!prefs.customFontDataUrl && (
                  <p className="mt-1 text-xs text-stone-500">
                    <span className="font-mono text-[#1C1917]">Dhanbumaa_Regular.otf</span> is
                    built-in and embedded into all Dhivehi previews and exported PNG receipts.
                    Optionally upload another font to override it.
                  </p>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-xl bg-[#2C1B18] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#3E2723] min-h-[40px]">
                  <Upload className="h-3.5 w-3.5" />
                  <span>Upload Custom Font</span>
                  <input
                    type="file"
                    accept=".ttf,.otf,.woff,.woff2"
                    onChange={(e) => void handleFontUpload(e)}
                    className="hidden"
                  />
                </label>
                {prefs.customFontDataUrl && (
                  <button
                    type="button"
                    onClick={() => void resetCustomFont()}
                    className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 min-h-[40px]"
                  >
                    Use Built-in Font
                  </button>
                )}
              </div>
            </div>

            <div
              dir="rtl"
              lang="dv"
              className="font-thaana rounded-xl border border-stone-200 bg-[#FAF9F7] p-4 text-right text-base text-[#1C1917]"
            >
              މަރުޙަބާ — އިންވޮއިސް ނަންބަރު <span dir="ltr" className="font-mono">INV-0001</span> ·
              ޖުމްލަ އަގު <span dir="ltr" className="font-mono">MVR 150.00</span> · ޝުކުރިއްޔާ!
            </div>
          </div>

          {/* Editable Translations */}
          <div className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-[#1C1917]">
                  Editable Invoice Labels (English &amp; Dhivehi)
                </h3>
                <p className="text-xs text-stone-500">
                  Customize any label shown on your printed or PNG invoices.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void handleResetTranslations()}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 min-h-[40px]"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Reset Defaults</span>
                </button>
                <button
                  type="button"
                  onClick={() => void handleSaveTranslations()}
                  className="rounded-xl bg-[#2C1B18] px-4 py-2 text-xs font-bold text-white hover:bg-[#3E2723] min-h-[40px]"
                >
                  Save Translations
                </button>
              </div>
            </div>

            <div className="divide-y divide-stone-100">
              {TRANSLATION_FIELD_META.map((field) => (
                <div
                  key={field.key}
                  className="grid grid-cols-1 gap-2 py-3 sm:grid-cols-12 sm:items-center"
                >
                  <div className="text-xs font-semibold text-stone-600 sm:col-span-4">
                    {field.label}
                  </div>
                  <div className="sm:col-span-4">
                    <input
                      type="text"
                      value={transDraft.en[field.key]}
                      onChange={(e) => updateTranslationField('en', field.key, e.target.value)}
                      aria-label={`${field.label} English`}
                      className="w-full rounded-xl border border-stone-200 px-3 py-2 text-xs min-h-[40px]"
                    />
                  </div>
                  <div className="sm:col-span-4">
                    <input
                      type="text"
                      dir="rtl"
                      value={transDraft.dv[field.key]}
                      onChange={(e) => updateTranslationField('dv', field.key, e.target.value)}
                      aria-label={`${field.label} Dhivehi`}
                      className="font-thaana w-full rounded-xl border border-stone-200 px-3 py-2 text-xs min-h-[40px]"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: POS MENU ITEMS */}
      {activeTab === 'menu' && (
        <div className="space-y-5">
          <form
            onSubmit={(e) => void handleAddMenuItem(e)}
            className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4"
          >
            <h3 className="text-base font-bold text-[#1C1917]">Add POS Menu Item</h3>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Item Name (English) *
                </label>
                <input
                  type="text"
                  required
                  value={newMenuNameEn}
                  onChange={(e) => setNewMenuNameEn(e.target.value)}
                  placeholder="e.g. Iced Mocha"
                  className="w-full rounded-xl border border-stone-300 px-3 py-2 text-sm min-h-[42px]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Item Name (Dhivehi)
                </label>
                <input
                  type="text"
                  dir="rtl"
                  value={newMenuNameDv}
                  onChange={(e) => setNewMenuNameDv(e.target.value)}
                  placeholder="އައިސްޑް މޯކާ"
                  className="font-thaana w-full rounded-xl border border-stone-300 px-3 py-2 text-sm min-h-[42px]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Category
                </label>
                <select
                  value={newMenuCategory}
                  onChange={(e) => setNewMenuCategory(e.target.value as MenuCategory)}
                  className="w-full rounded-xl border border-stone-300 px-3 py-2 text-sm min-h-[42px]"
                >
                  {MENU_CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Price (MVR) *
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  step="0.01"
                  value={newMenuPriceMvr}
                  onChange={(e) => setNewMenuPriceMvr(e.target.value)}
                  placeholder="55.00"
                  className="w-full rounded-xl border border-stone-300 px-3 py-2 font-mono text-sm min-h-[42px]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Price (USD) *
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  step="0.01"
                  value={newMenuPriceUsd}
                  onChange={(e) => setNewMenuPriceUsd(e.target.value)}
                  placeholder="3.60"
                  className="w-full rounded-xl border border-stone-300 px-3 py-2 font-mono text-sm min-h-[42px]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-600 mb-1">
                  Item Photo (Optional)
                </label>
                <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-stone-300 bg-stone-50 px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-100 min-h-[42px]">
                  <ImagePlus className="h-4 w-4" />
                  <span>{newMenuImageUrl ? 'Photo Ready' : 'Upload Image'}</span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    onChange={(e) => void handleMenuPhotoUpload(e)}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-xl bg-[#2C1B18] px-4 py-2.5 text-xs font-bold text-white hover:bg-[#3E2723] min-h-[42px]"
            >
              <Plus className="h-4 w-4" />
              <span>Add Menu Item</span>
            </button>
          </form>

          <div className="rounded-2xl border border-stone-200/90 bg-white overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-100 px-4 py-3.5 bg-[#FAF9F7]">
              <div>
                <h3 className="text-sm font-bold text-[#1C1917]">
                  Menu Items &amp; Prices ({menuDraft.length})
                </h3>
                <p className="text-[11px] text-stone-500">
                  Adjust MVR or USD prices anytime, then tap Save Prices.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void handleResetDefaultMenu()}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 min-h-[38px]"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Reset Default Menu</span>
                </button>
                <button
                  type="button"
                  onClick={() => void handleSaveMenuPrices()}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-[#2C1B18] px-4 py-2 text-xs font-bold text-white hover:bg-[#3E2723] min-h-[38px]"
                >
                  <Check className="h-3.5 w-3.5" />
                  <span>Save Prices</span>
                </button>
              </div>
            </div>

            <div className="divide-y divide-stone-100">
              {menuDraft.map((item) => (
                <div
                  key={item.id}
                  className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={item.imageUrl || CATEGORY_IMAGES[item.category]}
                      alt={item.nameEn}
                      referrerPolicy="no-referrer"
                      className="h-12 w-12 shrink-0 rounded-xl object-cover bg-stone-100"
                    />
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-[#1C1917] truncate">
                        {item.nameEn}
                        {item.nameDv ? ` · ${item.nameDv}` : ''}
                      </div>
                      <div className="text-xs text-stone-500">{item.category}</div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 sm:shrink-0">
                    <label className="flex items-center gap-1.5 rounded-xl border border-stone-200 bg-[#FAF9F7] px-2.5 py-1.5 text-xs">
                      <span className="font-semibold text-stone-500">MVR</span>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={item.priceMvr}
                        onChange={(e) =>
                          handleUpdateMenuPrice(item.id, 'priceMvr', e.target.value)
                        }
                        onBlur={() => void onSaveQuickMenu(menuDraft)}
                        aria-label={`${item.nameEn} MVR price`}
                        className="w-20 bg-transparent font-mono font-bold text-[#1C1917] focus:outline-none"
                      />
                    </label>
                    <label className="flex items-center gap-1.5 rounded-xl border border-stone-200 bg-[#FAF9F7] px-2.5 py-1.5 text-xs">
                      <span className="font-semibold text-stone-500">USD</span>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={item.priceUsd}
                        onChange={(e) =>
                          handleUpdateMenuPrice(item.id, 'priceUsd', e.target.value)
                        }
                        onBlur={() => void onSaveQuickMenu(menuDraft)}
                        aria-label={`${item.nameEn} USD price`}
                        className="w-16 bg-transparent font-mono font-bold text-[#1C1917] focus:outline-none"
                      />
                    </label>
                    <button
                      type="button"
                      onClick={() => void handleRemoveMenuItem(item.id)}
                      className="rounded-xl border border-rose-200 px-3 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-50 min-h-[38px]"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: ACCOUNT & PROFILE */}
      {activeTab === 'account' && (
        <AccountProfileSection
          user={user}
          onUserUpdated={onUserUpdated}
          onLogout={onLogout}
          onAccountDeleted={onAccountDeleted}
          onSyncToCloud={onSyncToCloud}
          onNotify={onNotify}
        />
      )}

      {/* TAB 6: HELP & CUSTOMER SUPPORT */}
      {activeTab === 'help' && (
        <HelpSupportSection isGuest={user.isGuest} onNotify={onNotify} />
      )}

      {/* TAB 7: APP & BACKUP */}
      {activeTab === 'backup' && (
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
          <div className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4">
            <h3 className="text-base font-bold text-[#1C1917]">Install CafePOS App (PWA)</h3>
            <p className="text-xs leading-relaxed text-stone-600">
              Install CafePOS on your iPhone, Android phone, or desktop for instant offline access. All invoices, customers, logos, and bank details stay safely stored on your device.
            </p>
            <PWAInstallButton variant="full" />
          </div>

          <div className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4">
            <h3 className="text-base font-bold text-[#1C1917]">JSON Data Backup &amp; Restore</h3>
            <p className="text-xs leading-relaxed text-stone-600">
              Export a complete JSON backup of all your invoices, customers, business settings, logo, bank accounts, and translations — or restore from a previous backup.
            </p>
            <div className="flex flex-col gap-2.5 sm:flex-row">
              <button
                type="button"
                onClick={() => void onExportBackup()}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-[#2C1B18] px-4 py-3 text-xs font-bold text-white hover:bg-[#3E2723] min-h-[44px]"
              >
                <Download className="h-4 w-4" />
                <span>Export Full Backup</span>
              </button>

              <label className="inline-flex flex-1 cursor-pointer items-center justify-center gap-2 rounded-xl border border-stone-300 bg-white px-4 py-3 text-xs font-bold text-[#1C1917] hover:bg-stone-50 min-h-[44px]">
                <Upload className="h-4 w-4" />
                <span>Import Backup JSON</span>
                <input
                  type="file"
                  accept="application/json,.json"
                  onChange={(e) => void handleBackupFileSelect(e)}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>
      )}

      {/* Persistent Clickable Support Footer */}
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-stone-200/80 bg-white px-4 py-3 text-xs text-stone-500">
        <span>Need assistance with CafePOS?</span>
        <a
          href={`mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent('CafePOS Customer Support')}`}
          className="inline-flex items-center gap-1.5 font-bold text-[#4E2A16] hover:underline"
        >
          <Mail className="h-3.5 w-3.5" />
          <span>{SUPPORT_EMAIL}</span>
        </a>
      </div>

      <ConfirmModal
        open={Boolean(pendingBackup)}
        title="Restore Backup Data"
        message="Do you want to merge this backup with your existing invoices and settings, or replace everything?"
        confirmLabel="Merge With Existing"
        cancelLabel="Cancel"
        onConfirm={() => {
          if (pendingBackup) void onImportBackup(pendingBackup, 'merge');
          setPendingBackup(null);
        }}
        onCancel={() => setPendingBackup(null)}
      />
    </div>
  );
};
