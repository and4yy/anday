import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Building2,
  CheckCircle2,
  ImagePlus,
  Landmark,
  Languages,
  Upload,
} from 'lucide-react';
import {
  DEFAULT_PREFERENCES,
  createEmptyAppData,
} from '../storage/db';
import type { AuthUser } from '../types/auth';
import type {
  AppDataState,
  BankAccount,
  BusinessProfile,
  CurrencyCode,
  InvoiceLanguage,
} from '../types/invoice';
import { createId } from '../utils/calculations';

interface OnboardingWizardProps {
  user: AuthUser;
  onComplete: (initialWorkspace: AppDataState) => Promise<void>;
}

async function resizeLogo(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxSide = 400;
        const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(typeof reader.result === 'string' ? reader.result : '');
          return;
        }
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/png'));
      };
      img.onerror = () => reject(new Error('Invalid image'));
      img.src = typeof reader.result === 'string' ? reader.result : '';
    };
    reader.onerror = () => reject(new Error('Read error'));
    reader.readAsDataURL(file);
  });
}

export const OnboardingWizard: React.FC<OnboardingWizardProps> = ({ user, onComplete }) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [businessName, setBusinessName] = useState('');
  const [logoDataUrl, setLogoDataUrl] = useState<string | undefined>(undefined);
  const [phone, setPhone] = useState(user.normalizedPhone || '');
  const [address, setAddress] = useState("Male', Maldives");

  // Bank details (optional)
  const [bankName, setBankName] = useState('');
  const [accountHolderName, setAccountHolderName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [branch, setBranch] = useState('');

  // Language & Currency
  const [defaultLanguage, setDefaultLanguage] = useState<InvoiceLanguage>('en');
  const [defaultCurrency, setDefaultCurrency] = useState<CurrencyCode>('MVR');

  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleLogoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const resized = await resizeLogo(file);
      setLogoDataUrl(resized);
    } catch {
      setErrorMsg('Please select a valid PNG, JPG, or WEBP image.');
    }
    e.target.value = '';
  };

  const handleFinish = async () => {
    setErrorMsg(null);
    setSaving(true);
    try {
      const profile: BusinessProfile = {
        name: businessName.trim() || `${user.fullName}'s Café`,
        logoDataUrl,
        phone: phone.trim(),
        address: address.trim(),
        defaultFooterEn: 'Thank you for visiting! We appreciate your business.',
        defaultFooterDv: 'ޒިޔާރަތް ކުރެއްވި ކަމަށްޓަކައި ޝުކުރިއްޔާ!',
      };

      const banks: BankAccount[] =
        bankName.trim() && accountNumber.trim()
          ? [
              {
                id: createId('bank'),
                bankName: bankName.trim(),
                accountHolderName: accountHolderName.trim() || profile.name,
                accountNumber: accountNumber.trim(),
                branch: branch.trim() || undefined,
                isDefault: true,
              },
            ]
          : [];

      const initialWorkspace = createEmptyAppData({
        businessProfile: profile,
        bankAccounts: banks,
        preferences: {
          ...DEFAULT_PREFERENCES,
          defaultLanguage,
          defaultCurrency,
        },
      });

      await onComplete(initialWorkspace);
    } catch (err) {
      setErrorMsg((err as Error).message || 'Could not complete setup. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF9F7] flex flex-col justify-center px-4 py-8">
      <div className="mx-auto w-full max-w-lg space-y-5">
        <div className="text-center space-y-2">
          <img
            src="/cafebill-logo.png"
            alt="CafePOS"
            className="mx-auto h-16 w-16 rounded-2xl object-cover shadow-sm border border-[#4E2A16]/15"
          />
          <h1 className="text-xl font-bold text-[#1C1917]">
            Welcome, {user.fullName}
          </h1>
          <p className="text-xs text-stone-600">
            Let&apos;s set up your café workspace · Step {step} of 4
          </p>
        </div>

        {/* Progress Bar */}
        <div className="grid grid-cols-4 gap-2">
          {[1, 2, 3, 4].map((s) => (
            <div
              key={s}
              className={`h-1.5 rounded-full transition-colors ${
                s <= step ? 'bg-[#4E2A16]' : 'bg-stone-200'
              }`}
            />
          ))}
        </div>

        <div className="rounded-2xl border border-stone-200/90 bg-white p-5 sm:p-6 shadow-xs space-y-5">
          {errorMsg && (
            <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-semibold text-rose-900">
              {errorMsg}
            </div>
          )}

          {/* STEP 1: Business Name & Logo */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-[#4E2A16]" />
                <h2 className="text-base font-bold text-[#1C1917]">
                  Business Name &amp; Logo
                </h2>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  Café / Business Name *
                </label>
                <input
                  type="text"
                  dir="auto"
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  placeholder="e.g. Island Brew Café"
                  className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[46px]"
                />
              </div>

              <div className="flex items-center gap-4 rounded-xl border border-stone-200 bg-[#FAF9F7] p-4">
                <div className="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-stone-200 bg-white">
                  {logoDataUrl ? (
                    <img
                      src={logoDataUrl}
                      alt="Business Logo"
                      className="h-full w-full object-contain p-1"
                    />
                  ) : (
                    <ImagePlus className="h-6 w-6 text-stone-400" />
                  )}
                </div>
                <div className="flex-1 space-y-2">
                  <div className="text-xs font-bold text-[#1C1917]">
                    Business Logo (Optional)
                  </div>
                  <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-xl bg-[#4E2A16] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#3E2723] min-h-[40px]">
                    <Upload className="h-3.5 w-3.5" />
                    <span>{logoDataUrl ? 'Change Logo' : 'Upload Logo'}</span>
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      onChange={(e) => void handleLogoChange(e)}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  if (!businessName.trim()) {
                    setErrorMsg('Please enter your business name.');
                    return;
                  }
                  setErrorMsg(null);
                  setStep(2);
                }}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#4E2A16] py-3.5 text-sm font-bold text-white hover:bg-[#3E2723] min-h-[48px]"
              >
                <span>Continue</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          )}

          {/* STEP 2: Phone & Address */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-[#4E2A16]" />
                <h2 className="text-base font-bold text-[#1C1917]">
                  Contact &amp; Address
                </h2>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  Business Phone Number
                </label>
                <input
                  type="tel"
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+960 330-0000"
                  className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 font-mono text-sm min-h-[46px]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  Business Address
                </label>
                <input
                  type="text"
                  dir="auto"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Orchid Magu, Male', Maldives"
                  className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[46px]"
                />
              </div>

              <div className="flex gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-stone-300 bg-white px-4 py-3 text-sm font-semibold text-stone-700 min-h-[48px]"
                >
                  <ArrowLeft className="h-4 w-4" />
                  <span>Back</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-[#4E2A16] py-3 text-sm font-bold text-white hover:bg-[#3E2723] min-h-[48px]"
                >
                  <span>Continue</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Bank Transfer Details */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Landmark className="h-5 w-5 text-[#4E2A16]" />
                <h2 className="text-base font-bold text-[#1C1917]">
                  Bank Transfer Details (Optional)
                </h2>
              </div>
              <p className="text-xs text-stone-600">
                Add your primary bank account (e.g. BML or MIB) so customers can transfer directly from receipts.
              </p>

              <div className="space-y-3">
                <input
                  type="text"
                  dir="auto"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  placeholder="Bank Name (e.g. Bank of Maldives)"
                  className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[44px]"
                />
                <input
                  type="text"
                  dir="auto"
                  value={accountHolderName}
                  onChange={(e) => setAccountHolderName(e.target.value)}
                  placeholder="Account Holder Name"
                  className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[44px]"
                />
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <input
                    type="text"
                    dir="ltr"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    placeholder="Account Number"
                    className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 font-mono text-sm min-h-[44px]"
                  />
                  <input
                    type="text"
                    dir="auto"
                    value={branch}
                    onChange={(e) => setBranch(e.target.value)}
                    placeholder="Branch (Optional)"
                    className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[44px]"
                  />
                </div>
              </div>

              <div className="flex gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-stone-300 bg-white px-4 py-3 text-sm font-semibold text-stone-700 min-h-[48px]"
                >
                  <ArrowLeft className="h-4 w-4" />
                  <span>Back</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStep(4)}
                  className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-[#4E2A16] py-3 text-sm font-bold text-white hover:bg-[#3E2723] min-h-[48px]"
                >
                  <span>{bankName.trim() ? 'Continue' : 'Skip for Now'}</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: Language & Currency */}
          {step === 4 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Languages className="h-5 w-5 text-[#4E2A16]" />
                <h2 className="text-base font-bold text-[#1C1917]">
                  Default Invoice Language &amp; Currency
                </h2>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-2">
                  Default Invoice Language
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setDefaultLanguage('en')}
                    className={`rounded-xl border py-3.5 px-3 text-sm font-bold min-h-[52px] ${
                      defaultLanguage === 'en'
                        ? 'border-[#4E2A16] bg-[#4E2A16] text-white'
                        : 'border-stone-200 bg-[#FAF9F7] text-[#1C1917]'
                    }`}
                  >
                    English
                  </button>
                  <button
                    type="button"
                    onClick={() => setDefaultLanguage('dv')}
                    className={`font-thaana rounded-xl border py-3.5 px-3 text-sm font-bold min-h-[52px] ${
                      defaultLanguage === 'dv'
                        ? 'border-[#4E2A16] bg-[#4E2A16] text-white'
                        : 'border-stone-200 bg-[#FAF9F7] text-[#1C1917]'
                    }`}
                  >
                    ދިވެހި (Dhivehi)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-2">
                  Preferred Currency
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setDefaultCurrency('MVR')}
                    className={`rounded-xl border py-3.5 px-3 text-sm font-bold min-h-[52px] ${
                      defaultCurrency === 'MVR'
                        ? 'border-[#4E2A16] bg-[#4E2A16] text-white'
                        : 'border-stone-200 bg-[#FAF9F7] text-[#1C1917]'
                    }`}
                  >
                    MVR (Rufiyaa)
                  </button>
                  <button
                    type="button"
                    onClick={() => setDefaultCurrency('USD')}
                    className={`rounded-xl border py-3.5 px-3 text-sm font-bold min-h-[52px] ${
                      defaultCurrency === 'USD'
                        ? 'border-[#4E2A16] bg-[#4E2A16] text-white'
                        : 'border-stone-200 bg-[#FAF9F7] text-[#1C1917]'
                    }`}
                  >
                    USD ($ Dollar)
                  </button>
                </div>
              </div>

              <div className="flex gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-stone-300 bg-white px-4 py-3 text-sm font-semibold text-stone-700 min-h-[48px]"
                >
                  <ArrowLeft className="h-4 w-4" />
                  <span>Back</span>
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => void handleFinish()}
                  className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-[#4E2A16] py-3 text-sm font-bold text-white hover:bg-[#3E2723] disabled:opacity-60 min-h-[48px]"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  <span>{saving ? 'Completing Setup...' : 'Complete Setup & Open POS'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
