import React from 'react';
import {
  getLabels,
  getPaymentMethodLabel,
  getPaymentStatusLabel,
} from '../i18n/translations';
import type {
  BankAccount,
  BusinessProfile,
  Invoice,
  TranslationMap,
} from '../types/invoice';
import {
  calculateLineTotal,
  formatCurrency,
  formatDateReadable,
  getInvoiceComputedTotals,
} from '../utils/calculations';

interface InvoiceDocumentProps {
  invoice: Invoice;
  businessProfile: BusinessProfile;
  bankAccounts: BankAccount[];
  translations: TranslationMap;
  exchangeRateUsdToMvr: number;
  exportRef?: React.Ref<HTMLDivElement>;
}

export const InvoiceDocument: React.FC<InvoiceDocumentProps> = ({
  invoice,
  businessProfile,
  bankAccounts,
  translations,
  exchangeRateUsdToMvr,
  exportRef,
}) => {
  const isRtl = invoice.language === 'dv';
  const labels = getLabels(translations, invoice.language);
  const totals = getInvoiceComputedTotals(invoice);

  const selectedBanks = invoice.showBankDetails
    ? bankAccounts.filter((b) =>
        invoice.selectedBankIds.length > 0
          ? invoice.selectedBankIds.includes(b.id)
          : Boolean(b.isDefault)
      )
    : [];
  const activeBanks =
    invoice.showBankDetails && selectedBanks.length === 0 && bankAccounts.length > 0
      ? [bankAccounts[0]]
      : selectedBanks;

  const defaultFooter = isRtl
    ? businessProfile.defaultFooterDv
    : businessProfile.defaultFooterEn;
  const footerText =
    invoice.footerMessage !== undefined && invoice.footerMessage.trim() !== ''
      ? invoice.footerMessage
      : defaultFooter;

  const rate = invoice.exchangeRateUsed || exchangeRateUsdToMvr || 15.42;
  const convertedAmount =
    invoice.currency === 'USD'
      ? totals.grandTotal * rate
      : totals.grandTotal / rate;
  const convertedCurrency = invoice.currency === 'USD' ? 'MVR' : 'USD';

  const docFontStyle: React.CSSProperties = isRtl
    ? {
        fontFamily:
          "'CustomDhivehiFont', 'Dhanbumaa', 'Noto Sans Thaana', 'Plus Jakarta Sans', sans-serif",
      }
    : {
        fontFamily:
          "'Plus Jakarta Sans', 'CustomDhivehiFont', 'Dhanbumaa', 'Noto Sans Thaana', sans-serif",
      };

  const renderPaidStamp = (compact = false) => {
    if (invoice.paymentStatus === 'PAID') {
      return (
        <div
          className={`inline-flex flex-col items-center justify-center rounded-xl border-[2.5px] border-[#15803D] bg-[#F0FDF4] text-[#15803D] ${
            compact ? 'px-3 py-1.5 -rotate-3' : 'px-4 py-2 -rotate-6'
          }`}
        >
          <div className="flex items-center gap-1.5">
            <svg
              className={compact ? 'h-4 w-4' : 'h-5 w-5'}
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M20 6L9 17l-5-5" />
            </svg>
            <span
              className={`font-bold tracking-wide ${
                compact ? 'text-sm' : 'text-base'
              }`}
            >
              {labels.paid}
            </span>
          </div>
          {invoice.paymentDate && (
            <span
              dir="ltr"
              className="bidi-isolate mt-0.5 font-mono text-[10px] font-semibold text-[#166534]"
            >
              {formatDateReadable(invoice.paymentDate)}
            </span>
          )}
        </div>
      );
    }

    if (invoice.paymentStatus === 'PARTIALLY_PAID') {
      return (
        <div
          className={`inline-flex items-center gap-1.5 rounded-lg border-2 border-[#B45309] bg-[#FFFBEB] text-[#92400E] ${
            compact ? 'px-2.5 py-1 text-xs' : 'px-3 py-1.5 text-xs'
          } font-bold`}
        >
          <span>{labels.partiallyPaid}</span>
        </div>
      );
    }

    return (
      <div
        className={`inline-flex items-center gap-1.5 rounded-lg border-2 border-stone-800 bg-stone-100 text-stone-900 ${
          compact ? 'px-2.5 py-1 text-xs' : 'px-3 py-1.5 text-xs'
        } font-bold`}
      >
        <span>{labels.unpaid}</span>
      </div>
    );
  };

  if (invoice.layoutStyle === 'pos') {
    const posPixelWidth = invoice.posWidth === '58mm' ? 320 : 420;
    const isNarrow = invoice.posWidth === '58mm';

    return (
      <div
        ref={exportRef}
        dir={isRtl ? 'rtl' : 'ltr'}
        lang={isRtl ? 'dv' : 'en'}
        style={{
          ...docFontStyle,
          width: `${posPixelWidth}px`,
          backgroundColor: '#ffffff',
          color: '#111827',
        }}
        className="mx-auto bg-white text-neutral-950 select-text"
      >
        <div className={isNarrow ? 'p-4 text-[12px]' : 'p-5 text-[13px]'}>
          {/* Header */}
          <div className="flex flex-col items-center text-center">
            {businessProfile.logoDataUrl && (
              <img
                src={businessProfile.logoDataUrl}
                alt={businessProfile.name}
                className={`${
                  isNarrow ? 'h-14 max-w-[140px]' : 'h-16 max-w-[180px]'
                } mb-2.5 object-contain grayscale contrast-125`}
              />
            )}
            <h1
              dir="auto"
              className={`${
                isNarrow ? 'text-base' : 'text-lg'
              } font-bold tracking-tight text-black break-words w-full`}
            >
              {businessProfile.name || 'CafePOS'}
            </h1>
            {businessProfile.address && (
              <p dir="auto" className="mt-0.5 text-[11px] text-neutral-700 break-words w-full">
                {businessProfile.address}
              </p>
            )}
            {(businessProfile.phone || businessProfile.email) && (
              <p className="mt-0.5 text-[11px] text-neutral-700 break-words w-full">
                {businessProfile.phone && (
                  <span dir="ltr" className="bidi-isolate inline-block">
                    {businessProfile.phone}
                  </span>
                )}
                {businessProfile.phone && businessProfile.email && ' · '}
                {businessProfile.email && (
                  <span dir="ltr" className="bidi-isolate inline-block">
                    {businessProfile.email}
                  </span>
                )}
              </p>
            )}
            {businessProfile.socialHandle && (
              <p dir="ltr" className="bidi-isolate mt-0.5 text-[11px] text-neutral-700">
                {businessProfile.socialHandle}
              </p>
            )}
            {businessProfile.registrationNumber && (
              <p className="mt-0.5 text-[11px] text-neutral-600">
                {labels.regNo}:{' '}
                <span dir="ltr" className="bidi-isolate inline-block">
                  {businessProfile.registrationNumber}
                </span>
              </p>
            )}
          </div>

          <div className="my-3 border-t border-dashed border-neutral-400" />

          {/* Receipt Title & Meta */}
          <div className="text-center font-bold tracking-wide text-black text-sm mb-2">
            {labels.receiptTitle}
          </div>

          <div className="space-y-1 text-[11.5px]">
            <div className="flex items-start justify-between gap-2">
              <span className="text-neutral-600 shrink-0">{labels.invoiceNumber}</span>
              <span dir="ltr" className="bidi-isolate font-mono font-semibold text-black">
                {invoice.invoiceNumber}
              </span>
            </div>
            <div className="flex items-start justify-between gap-2">
              <span className="text-neutral-600 shrink-0">{labels.date}</span>
              <span dir="ltr" className="bidi-isolate font-mono text-black">
                {formatDateReadable(invoice.date)}
              </span>
            </div>
            {invoice.tableName && (
              <div className="flex items-start justify-between gap-2">
                <span className="text-neutral-600 shrink-0">{labels.table}</span>
                <span dir="auto" className="font-bold text-black">
                  {invoice.tableName}
                </span>
              </div>
            )}
            {invoice.customerName && (
              <div className="flex items-start justify-between gap-2">
                <span className="text-neutral-600 shrink-0">{labels.customer}</span>
                <span dir="auto" className="font-medium text-black text-end break-words max-w-[65%]">
                  {invoice.customerName}
                </span>
              </div>
            )}
            {invoice.customerPhone && (
              <div className="flex items-start justify-between gap-2">
                <span className="text-neutral-600 shrink-0">{labels.phone}</span>
                <span dir="ltr" className="bidi-isolate font-mono text-black">
                  {invoice.customerPhone}
                </span>
              </div>
            )}
          </div>

          <div className="my-3 border-t border-dashed border-neutral-400" />

          {/* Items Header */}
          <div className="flex items-center justify-between text-[11px] font-bold text-neutral-700 pb-1.5 border-b border-neutral-300">
            <span>{labels.description}</span>
            <span>{labels.amount}</span>
          </div>

          {/* Items List */}
          <div className="divide-y divide-dotted divide-neutral-300">
            {invoice.items.map((item) => {
              const lineTotal = calculateLineTotal(item.quantity, item.unitPrice);
              return (
                <div key={item.id} className="py-2">
                  <div className="flex items-start justify-between gap-2">
                    <span
                      dir="auto"
                      className="font-medium text-black break-words leading-snug flex-1 min-w-0"
                    >
                      {item.description || '—'}
                    </span>
                    <span
                      dir="ltr"
                      className="bidi-isolate font-mono font-semibold text-black shrink-0"
                    >
                      {formatCurrency(lineTotal, invoice.currency)}
                    </span>
                  </div>
                  <div
                    dir="ltr"
                    className="bidi-isolate mt-0.5 text-[11px] font-mono text-neutral-600"
                  >
                    {item.quantity} × {formatCurrency(item.unitPrice, invoice.currency)}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="my-2.5 border-t border-dashed border-neutral-400" />

          {/* Totals */}
          <div className="space-y-1 text-[12px]">
            <div className="flex items-center justify-between gap-2">
              <span className="text-neutral-700">{labels.subtotal}</span>
              <span dir="ltr" className="bidi-isolate font-mono text-black">
                {formatCurrency(totals.subtotal, invoice.currency)}
              </span>
            </div>

            {totals.discountAmount > 0 && (
              <div className="flex items-center justify-between gap-2">
                <span className="text-neutral-700">
                  {labels.discount}
                  {invoice.discountType === 'percent' ? ` (${invoice.discountValue}%)` : ''}
                </span>
                <span dir="ltr" className="bidi-isolate font-mono text-black">
                  -{formatCurrency(totals.discountAmount, invoice.currency)}
                </span>
              </div>
            )}

            {totals.additionalChargeAmount > 0 && (
              <div className="flex items-center justify-between gap-2">
                <span dir="auto" className="text-neutral-700 break-words">
                  {invoice.additionalChargeLabel?.trim() || labels.additionalCharges}
                </span>
                <span dir="ltr" className="bidi-isolate font-mono text-black shrink-0">
                  +{formatCurrency(totals.additionalChargeAmount, invoice.currency)}
                </span>
              </div>
            )}

            <div className="my-1.5 border-t border-neutral-900" />

            <div className="flex items-center justify-between gap-2 text-[15px] font-bold text-black">
              <span>{labels.total}</span>
              <span dir="ltr" className="bidi-isolate font-mono">
                {formatCurrency(totals.grandTotal, invoice.currency)}
              </span>
            </div>

            {invoice.showConversionReference && (
              <div className="flex items-center justify-between gap-2 text-[11px] text-neutral-600">
                <span>{labels.convertedRef}</span>
                <span dir="ltr" className="bidi-isolate font-mono">
                  ≈ {formatCurrency(convertedAmount, convertedCurrency)}
                </span>
              </div>
            )}

            {invoice.paymentStatus === 'PARTIALLY_PAID' && (
              <>
                <div className="flex items-center justify-between gap-2 pt-1 text-[11.5px] text-neutral-700">
                  <span>{labels.amountPaid}</span>
                  <span dir="ltr" className="bidi-isolate font-mono font-semibold text-black">
                    {formatCurrency(totals.amountPaid, invoice.currency)}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2 text-[12px] font-bold text-black">
                  <span>{labels.balanceDue}</span>
                  <span dir="ltr" className="bidi-isolate font-mono">
                    {formatCurrency(totals.balanceDue, invoice.currency)}
                  </span>
                </div>
              </>
            )}
          </div>

          <div className="my-3 border-t border-dashed border-neutral-400" />

          {/* Payment Info + Status Stamp */}
          <div className="flex items-center justify-between gap-3">
            <div className="text-[11px] space-y-0.5 min-w-0">
              <div className="text-neutral-600">{labels.paymentMethod}</div>
              <div className="font-semibold text-black">
                {getPaymentMethodLabel(labels, invoice.paymentMethod)}
              </div>
            </div>
            <div className="shrink-0">{renderPaidStamp(true)}</div>
          </div>

          {/* Bank Transfer Details */}
          {activeBanks.length > 0 && (
            <div className="mt-3 rounded-lg border border-neutral-300 bg-neutral-50 p-2.5 text-[11px]">
              <div className="font-bold text-black mb-1">{labels.bankTransferDetails}</div>
              <div className="space-y-2">
                {activeBanks.map((bank) => (
                  <div key={bank.id} className="space-y-0.5">
                    <div className="font-semibold text-black" dir="auto">
                      {bank.bankName}
                      {bank.branch ? ` (${bank.branch})` : ''}
                    </div>
                    <div className="text-neutral-700" dir="auto">
                      {bank.accountHolderName}
                    </div>
                    <div dir="ltr" className="bidi-isolate font-mono font-bold text-black">
                      {bank.accountNumber}
                    </div>
                    {bank.instructions && (
                      <div dir="auto" className="text-neutral-600 break-words">
                        {bank.instructions}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Notes & Payment Instructions */}
          {(invoice.paymentInstructions || invoice.notes) && (
            <div className="mt-3 space-y-1.5 text-[11px] text-neutral-700">
              {invoice.paymentInstructions && (
                <div>
                  <span className="font-semibold text-black">{labels.paymentInstructions}: </span>
                  <span dir="auto" className="break-words">
                    {invoice.paymentInstructions}
                  </span>
                </div>
              )}
              {invoice.notes && (
                <div>
                  <span className="font-semibold text-black">{labels.notes}: </span>
                  <span dir="auto" className="break-words">
                    {invoice.notes}
                  </span>
                </div>
              )}
            </div>
          )}

          <div className="my-3 border-t border-dashed border-neutral-400" />

          {/* Footer */}
          <div className="text-center space-y-1">
            <div className="font-bold text-black text-[12px]">{labels.thankYou}</div>
            {footerText && (
              <p dir="auto" className="text-[11px] text-neutral-600 break-words">
                {footerText}
              </p>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Professional A4 Invoice Layout
  return (
    <div
      ref={exportRef}
      dir={isRtl ? 'rtl' : 'ltr'}
      lang={isRtl ? 'dv' : 'en'}
      style={{
        ...docFontStyle,
        width: '794px',
        backgroundColor: '#ffffff',
        color: '#1C1917',
      }}
      className="mx-auto bg-white p-10 text-[#1C1917] select-text"
    >
      {/* Top Header */}
      <div className="flex items-start justify-between gap-8 border-b border-stone-200 pb-7">
        <div className="flex items-start gap-4 min-w-0 flex-1">
          {businessProfile.logoDataUrl && (
            <img
              src={businessProfile.logoDataUrl}
              alt={businessProfile.name}
              className="h-20 w-20 shrink-0 rounded-xl border border-stone-200 bg-white object-contain p-1"
            />
          )}
          <div className="min-w-0 flex-1">
            <h1 dir="auto" className="text-2xl font-bold tracking-tight text-[#1C1917] break-words">
              {businessProfile.name || 'CafePOS'}
            </h1>
            <div className="mt-1.5 space-y-0.5 text-sm text-stone-600">
              {businessProfile.address && (
                <p dir="auto" className="break-words">
                  {businessProfile.address}
                </p>
              )}
              <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5">
                {businessProfile.phone && (
                  <span dir="ltr" className="bidi-isolate font-mono text-xs">
                    {businessProfile.phone}
                  </span>
                )}
                {businessProfile.email && (
                  <span dir="ltr" className="bidi-isolate text-xs">
                    {businessProfile.email}
                  </span>
                )}
                {businessProfile.socialHandle && (
                  <span dir="ltr" className="bidi-isolate text-xs">
                    {businessProfile.socialHandle}
                  </span>
                )}
              </div>
              {businessProfile.registrationNumber && (
                <p className="text-xs text-stone-500">
                  {labels.regNo}:{' '}
                  <span dir="ltr" className="bidi-isolate font-mono">
                    {businessProfile.registrationNumber}
                  </span>
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="shrink-0 text-end">
          <div className="text-2xl font-bold tracking-tight text-[#2C1B18]">
            {labels.invoiceTitle}
          </div>
          <div className="mt-2 space-y-1 text-sm">
            <div className="flex items-center justify-end gap-2">
              <span className="text-stone-500">{labels.invoiceNumber}:</span>
              <span dir="ltr" className="bidi-isolate font-mono font-bold text-[#1C1917]">
                {invoice.invoiceNumber}
              </span>
            </div>
            <div className="flex items-center justify-end gap-2">
              <span className="text-stone-500">{labels.date}:</span>
              <span dir="ltr" className="bidi-isolate font-mono text-[#1C1917]">
                {formatDateReadable(invoice.date)}
              </span>
            </div>
            {invoice.tableName && (
              <div className="flex items-center justify-end gap-2">
                <span className="text-stone-500">{labels.table}:</span>
                <span dir="auto" className="font-bold text-[#1C1917]">
                  {invoice.tableName}
                </span>
              </div>
            )}
          </div>
          <div className="mt-3 flex justify-end">{renderPaidStamp(false)}</div>
        </div>
      </div>

      {/* Customer & Payment Overview */}
      <div className="mt-7 grid grid-cols-2 gap-6">
        <div className="rounded-xl border border-stone-200 bg-stone-50/70 p-4">
          <div className="text-xs font-semibold text-stone-500">{labels.customer}</div>
          <div dir="auto" className="mt-1 text-base font-bold text-[#1C1917] break-words">
            {invoice.customerName || 'Walk-in Customer'}
          </div>
          {invoice.customerPhone && (
            <div className="mt-1 text-xs text-stone-600">
              {labels.phone}:{' '}
              <span dir="ltr" className="bidi-isolate font-mono">
                {invoice.customerPhone}
              </span>
            </div>
          )}
          {invoice.customerEmail && (
            <div className="mt-0.5 text-xs text-stone-600">
              {labels.email}:{' '}
              <span dir="ltr" className="bidi-isolate">
                {invoice.customerEmail}
              </span>
            </div>
          )}
        </div>

        <div className="rounded-xl border border-stone-200 bg-stone-50/70 p-4">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <div className="text-xs font-semibold text-stone-500">{labels.paymentMethod}</div>
              <div className="mt-1 font-semibold text-[#1C1917]">
                {getPaymentMethodLabel(labels, invoice.paymentMethod)}
              </div>
            </div>
            <div>
              <div className="text-xs font-semibold text-stone-500">{labels.paymentStatus}</div>
              <div className="mt-1 font-semibold text-[#1C1917]">
                {getPaymentStatusLabel(labels, invoice.paymentStatus)}
              </div>
            </div>
          </div>
          {invoice.paymentStatus === 'PAID' && invoice.paymentDate && (
            <div className="mt-2.5 text-xs text-stone-600">
              {labels.paymentDate}:{' '}
              <span dir="ltr" className="bidi-isolate font-mono font-medium text-[#1C1917]">
                {formatDateReadable(invoice.paymentDate)}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Line Items Table */}
      <div className="mt-7 overflow-visible rounded-xl border border-stone-200">
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="border-b border-stone-200 bg-stone-100/80 text-xs font-bold text-stone-700">
              <th className="px-4 py-3 text-start">{labels.description}</th>
              <th className="w-20 px-3 py-3 text-center">{labels.quantity}</th>
              <th className="w-32 px-4 py-3 text-end">{labels.unitPrice}</th>
              <th className="w-36 px-4 py-3 text-end">{labels.amount}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-200">
            {invoice.items.map((item) => {
              const lineTotal = calculateLineTotal(item.quantity, item.unitPrice);
              return (
                <tr key={item.id}>
                  <td className="px-4 py-3.5 align-top">
                    <div dir="auto" className="font-medium text-[#1C1917] break-words">
                      {item.description || '—'}
                    </div>
                  </td>
                  <td className="px-3 py-3.5 text-center align-top">
                    <span dir="ltr" className="bidi-isolate font-mono text-stone-700">
                      {item.quantity}
                    </span>
                  </td>
                  <td className="px-4 py-3.5 text-end align-top">
                    <span dir="ltr" className="bidi-isolate font-mono text-stone-700">
                      {formatCurrency(item.unitPrice, invoice.currency)}
                    </span>
                  </td>
                  <td className="px-4 py-3.5 text-end align-top">
                    <span dir="ltr" className="bidi-isolate font-mono font-semibold text-[#1C1917]">
                      {formatCurrency(lineTotal, invoice.currency)}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Summary & Bank Details */}
      <div className="mt-7 grid grid-cols-12 gap-8 items-start">
        <div className="col-span-7 space-y-4">
          {activeBanks.length > 0 && (
            <div className="rounded-xl border border-stone-200 bg-stone-50/70 p-4">
              <div className="text-xs font-bold text-[#2C1B18] mb-2">
                {labels.bankTransferDetails}
              </div>
              <div className="space-y-3 text-xs">
                {activeBanks.map((bank) => (
                  <div key={bank.id} className="space-y-0.5 border-b border-stone-200/70 pb-2 last:border-b-0 last:pb-0">
                    <div className="font-bold text-[#1C1917]" dir="auto">
                      {bank.bankName}
                      {bank.branch ? ` · ${bank.branch}` : ''}
                    </div>
                    <div className="text-stone-700">
                      <span className="text-stone-500">{labels.accountName}: </span>
                      <span dir="auto" className="font-medium">
                        {bank.accountHolderName}
                      </span>
                    </div>
                    <div className="text-stone-700">
                      <span className="text-stone-500">{labels.accountNumber}: </span>
                      <span dir="ltr" className="bidi-isolate font-mono font-bold text-[#1C1917]">
                        {bank.accountNumber}
                      </span>
                    </div>
                    {bank.instructions && (
                      <div dir="auto" className="text-stone-600 pt-0.5 break-words">
                        {bank.instructions}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {invoice.paymentInstructions && (
            <div className="text-xs text-stone-600">
              <div className="font-bold text-[#1C1917] mb-0.5">{labels.paymentInstructions}</div>
              <p dir="auto" className="break-words leading-relaxed">
                {invoice.paymentInstructions}
              </p>
            </div>
          )}

          {invoice.notes && (
            <div className="text-xs text-stone-600">
              <div className="font-bold text-[#1C1917] mb-0.5">{labels.notes}</div>
              <p dir="auto" className="break-words leading-relaxed">
                {invoice.notes}
              </p>
            </div>
          )}
        </div>

        <div className="col-span-5 rounded-xl border border-stone-200 bg-stone-50/70 p-4">
          <div className="space-y-2.5 text-sm">
            <div className="flex items-center justify-between gap-3">
              <span className="text-stone-600">{labels.subtotal}</span>
              <span dir="ltr" className="bidi-isolate font-mono font-medium text-[#1C1917]">
                {formatCurrency(totals.subtotal, invoice.currency)}
              </span>
            </div>

            {totals.discountAmount > 0 && (
              <div className="flex items-center justify-between gap-3">
                <span className="text-stone-600">
                  {labels.discount}
                  {invoice.discountType === 'percent' ? ` (${invoice.discountValue}%)` : ''}
                </span>
                <span dir="ltr" className="bidi-isolate font-mono font-medium text-rose-700">
                  -{formatCurrency(totals.discountAmount, invoice.currency)}
                </span>
              </div>
            )}

            {totals.additionalChargeAmount > 0 && (
              <div className="flex items-center justify-between gap-3">
                <span dir="auto" className="text-stone-600 break-words">
                  {invoice.additionalChargeLabel?.trim() || labels.additionalCharges}
                </span>
                <span dir="ltr" className="bidi-isolate font-mono font-medium text-[#1C1917]">
                  +{formatCurrency(totals.additionalChargeAmount, invoice.currency)}
                </span>
              </div>
            )}

            <div className="border-t border-stone-300 pt-2.5 flex items-center justify-between gap-3">
              <span className="text-base font-bold text-[#1C1917]">{labels.total}</span>
              <span dir="ltr" className="bidi-isolate font-mono text-lg font-bold text-[#2C1B18]">
                {formatCurrency(totals.grandTotal, invoice.currency)}
              </span>
            </div>

            {invoice.showConversionReference && (
              <div className="flex items-center justify-between gap-3 text-xs text-stone-500">
                <span>{labels.convertedRef}</span>
                <span dir="ltr" className="bidi-isolate font-mono">
                  ≈ {formatCurrency(convertedAmount, convertedCurrency)}
                </span>
              </div>
            )}

            {invoice.paymentStatus === 'PARTIALLY_PAID' && (
              <div className="border-t border-stone-200 pt-2.5 space-y-1.5 text-xs">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-stone-600">{labels.amountPaid}</span>
                  <span dir="ltr" className="bidi-isolate font-mono font-semibold text-emerald-700">
                    {formatCurrency(totals.amountPaid, invoice.currency)}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-3 text-sm font-bold text-[#92400E]">
                  <span>{labels.balanceDue}</span>
                  <span dir="ltr" className="bidi-isolate font-mono">
                    {formatCurrency(totals.balanceDue, invoice.currency)}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-10 border-t border-stone-200 pt-5 text-center">
        <div className="text-sm font-bold text-[#2C1B18]">{labels.thankYou}</div>
        {footerText && (
          <p dir="auto" className="mt-1 text-xs text-stone-600 break-words">
            {footerText}
          </p>
        )}
      </div>
    </div>
  );
};
