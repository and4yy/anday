import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  Bug,
  CheckCircle2,
  Headphones,
  ImagePlus,
  Info,
  Mail,
  MessageSquarePlus,
  Send,
  ShieldAlert,
} from 'lucide-react';
import { fetchSupportReports, submitSupportReport } from '../services/api';
import { saveSupportReportToFirestore } from '../services/firestoreSync';
import {
  APP_VERSION,
  SUPPORT_CONTACT_NAME,
  SUPPORT_EMAIL,
  type SupportReportSummary,
} from '../types/auth';

interface HelpSupportSectionProps {
  isGuest?: boolean;
  onNotify: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

type SupportPanel = 'menu' | 'bug' | 'issue' | 'care' | 'feedback' | 'about';

const ISSUE_CATEGORIES = [
  'Invoices',
  'Payments',
  'Calculations',
  'Account Access',
  'Dhivehi & PNG Export',
  'Offline Sync',
  'Other',
];

async function resizeScreenshot(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxSide = 1200;
        const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(typeof reader.result === 'string' ? reader.result : '');
          return;
        }
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
      img.onerror = () => reject(new Error('Invalid screenshot image'));
      img.src = typeof reader.result === 'string' ? reader.result : '';
    };
    reader.onerror = () => reject(new Error('Could not read file'));
    reader.readAsDataURL(file);
  });
}

function getDeviceInfoString(): string {
  if (typeof navigator === 'undefined') return 'Unknown device';
  const screenInfo =
    typeof window !== 'undefined' ? `${window.innerWidth}x${window.innerHeight}` : '';
  return `${navigator.userAgent} | Viewport: ${screenInfo}`.slice(0, 480);
}

export const HelpSupportSection: React.FC<HelpSupportSectionProps> = ({
  isGuest = false,
  onNotify,
}) => {
  const [panel, setPanel] = useState<SupportPanel>('menu');

  // Bug form
  const [bugTitle, setBugTitle] = useState('');
  const [bugDesc, setBugDesc] = useState('');
  const [bugScreenshot, setBugScreenshot] = useState<string | undefined>(undefined);

  // Issue form
  const [issueCategory, setIssueCategory] = useState(ISSUE_CATEGORIES[0]);
  const [issueSubject, setIssueSubject] = useState('');
  const [issueDesc, setIssueDesc] = useState('');
  const [issueScreenshot, setIssueScreenshot] = useState<string | undefined>(undefined);

  // Feedback form
  const [feedbackText, setFeedbackText] = useState('');
  const [feedbackContact, setFeedbackContact] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);
  const [submittedReports, setSubmittedReports] = useState<SupportReportSummary[]>([]);

  useEffect(() => {
    if (isGuest) return;
    fetchSupportReports()
      .then((list) => setSubmittedReports(list))
      .catch(() => {
        // Offline or unreachable — keep empty without faking data
      });
  }, [isGuest]);

  const resetMessages = () => {
    setFormError(null);
    setFormSuccess(null);
  };

  const handleScreenshot = async (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (val: string | undefined) => void
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await resizeScreenshot(file);
      setter(dataUrl);
    } catch {
      setFormError('Please select a valid PNG, JPG, or WEBP screenshot.');
    }
    e.target.value = '';
  };

  const handleSubmitBug = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    setSubmitting(true);
    try {
      const payload = {
        type: 'bug' as const,
        title: bugTitle.trim(),
        description: bugDesc.trim(),
        screenshotDataUrl: bugScreenshot,
        appVersion: APP_VERSION,
        deviceInfo: getDeviceInfoString(),
      };
      const res = await submitSupportReport(payload);
      void saveSupportReportToFirestore(res.report.id, payload).catch(() => {});
      setSubmittedReports((prev) => [res.report, ...prev]);
      setBugTitle('');
      setBugDesc('');
      setBugScreenshot(undefined);
      setFormSuccess('Bug report submitted and saved securely.');
      onNotify('Bug report submitted.', 'success');
    } catch (err) {
      const msg =
        (err as Error).message ||
        `Failed to save bug report. Please check your internet connection or email ${SUPPORT_EMAIL}.`;
      setFormError(msg);
      onNotify(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSubmitIssue = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    setSubmitting(true);
    try {
      const payload = {
        type: 'issue' as const,
        category: issueCategory,
        title: issueSubject.trim(),
        description: issueDesc.trim(),
        screenshotDataUrl: issueScreenshot,
        appVersion: APP_VERSION,
        deviceInfo: getDeviceInfoString(),
      };
      const res = await submitSupportReport(payload);
      void saveSupportReportToFirestore(res.report.id, payload).catch(() => {});
      setSubmittedReports((prev) => [res.report, ...prev]);
      setIssueSubject('');
      setIssueDesc('');
      setIssueScreenshot(undefined);
      setFormSuccess('Issue report submitted and saved securely.');
      onNotify('Issue report submitted.', 'success');
    } catch (err) {
      const msg =
        (err as Error).message ||
        `Failed to save issue report. Please check your internet connection or email ${SUPPORT_EMAIL}.`;
      setFormError(msg);
      onNotify(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSubmitFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    setSubmitting(true);
    try {
      const payload = {
        type: 'feedback' as const,
        title: 'Feedback & Suggestion',
        description: feedbackText.trim(),
        contactInfo: feedbackContact.trim() || undefined,
        appVersion: APP_VERSION,
      };
      const res = await submitSupportReport(payload);
      void saveSupportReportToFirestore(res.report.id, payload).catch(() => {});
      setSubmittedReports((prev) => [res.report, ...prev]);
      setFeedbackText('');
      setFeedbackContact('');
      setFormSuccess('Thank you! Your feedback has been saved.');
      onNotify('Feedback sent.', 'success');
    } catch (err) {
      const msg =
        (err as Error).message ||
        `Failed to submit feedback. Please check your connection or email ${SUPPORT_EMAIL}.`;
      setFormError(msg);
      onNotify(msg, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const mailtoUrl = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(
    'CafePOS Customer Support'
  )}`;

  return (
    <div className="space-y-5">
      {/* Touch-Friendly Support Navigation Grid */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {(
          [
            {
              id: 'bug',
              title: 'Report a Bug',
              desc: 'Send technical issues with device info & screenshots',
              icon: Bug,
            },
            {
              id: 'issue',
              title: 'Report an Issue',
              desc: 'Invoices, payments, calculations, or account help',
              icon: ShieldAlert,
            },
            {
              id: 'care',
              title: 'Customer Care',
              desc: `Direct email support with ${SUPPORT_CONTACT_NAME}`,
              icon: Headphones,
            },
            {
              id: 'feedback',
              title: 'Feedback & Suggestions',
              desc: 'Share ideas to make CafePOS even better',
              icon: MessageSquarePlus,
            },
            {
              id: 'about',
              title: 'About CafePOS',
              desc: `Version ${APP_VERSION} · App & developer info`,
              icon: Info,
            },
          ] as {
            id: SupportPanel;
            title: string;
            desc: string;
            icon: React.ComponentType<{ className?: string }>;
          }[]
        ).map((item) => {
          const Icon = item.icon;
          const active = panel === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                resetMessages();
                setPanel(item.id);
              }}
              className={`flex items-start gap-3.5 rounded-2xl border p-4 text-start transition-colors min-h-[76px] ${
                active
                  ? 'border-[#4E2A16] bg-[#FAF6F0]'
                  : 'border-stone-200/90 bg-white hover:border-stone-300'
              }`}
            >
              <div
                className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                  active ? 'bg-[#4E2A16] text-white' : 'bg-[#FAF9F7] text-[#4E2A16]'
                }`}
              >
                <Icon className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <div className="text-sm font-bold text-[#1C1917]">{item.title}</div>
                <div className="mt-0.5 text-xs text-stone-500">{item.desc}</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Guest Demo Notice */}
      {isGuest && (panel === 'bug' || panel === 'issue' || panel === 'feedback') && (
        <div className="flex items-start gap-2.5 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs font-medium text-amber-950">
          <AlertCircle className="h-4 w-4 shrink-0 text-amber-700 mt-0.5" />
          <span>
            You are in Guest Demo mode. Sign in to save support reports to your account, or email{' '}
            <a href={mailtoUrl} className="font-bold underline">
              {SUPPORT_EMAIL}
            </a>{' '}
            directly.
          </span>
        </div>
      )}

      {/* Feedback/Error Alerts */}
      {formError && (
        <div className="flex items-start gap-2.5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-semibold text-rose-900">
          <AlertCircle className="h-4 w-4 shrink-0 text-rose-700 mt-0.5" />
          <span>{formError}</span>
        </div>
      )}
      {formSuccess && (
        <div className="flex items-start gap-2.5 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-semibold text-emerald-900">
          <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-700 mt-0.5" />
          <span>{formSuccess}</span>
        </div>
      )}

      {/* 1. REPORT A BUG */}
      {panel === 'bug' && (
        <form
          onSubmit={(e) => void handleSubmitBug(e)}
          className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4"
        >
          <div className="flex items-center gap-2">
            <Bug className="h-5 w-5 text-[#4E2A16]" />
            <h3 className="text-base font-bold text-[#1C1917]">Report a Bug</h3>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Issue Title *
            </label>
            <input
              type="text"
              required
              dir="auto"
              value={bugTitle}
              onChange={(e) => setBugTitle(e.target.value)}
              placeholder="Short summary of the bug"
              className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[44px]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Description of the Problem *
            </label>
            <textarea
              required
              rows={4}
              dir="auto"
              value={bugDesc}
              onChange={(e) => setBugDesc(e.target.value)}
              placeholder="What happened and what steps reproduce it?"
              className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm"
            />
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-stone-300 bg-[#FAF9F7] px-4 py-2.5 text-xs font-semibold text-[#1C1917] hover:bg-stone-100 min-h-[42px]">
              <ImagePlus className="h-4 w-4 text-[#4E2A16]" />
              <span>{bugScreenshot ? 'Change Screenshot' : 'Attach Screenshot (Optional)'}</span>
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={(e) => void handleScreenshot(e, setBugScreenshot)}
                className="hidden"
              />
            </label>
            {bugScreenshot && (
              <button
                type="button"
                onClick={() => setBugScreenshot(undefined)}
                className="text-xs font-semibold text-rose-700 hover:underline"
              >
                Remove Screenshot
              </button>
            )}
          </div>

          <div className="rounded-xl bg-[#FAF9F7] p-3 text-[11px] text-stone-600">
            Automatically included: App v{APP_VERSION} · Device &amp; browser metadata
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-xl bg-[#4E2A16] px-6 py-3 text-sm font-bold text-white hover:bg-[#3E2723] disabled:opacity-60 min-h-[48px]"
          >
            <Send className="h-4 w-4" />
            <span>{submitting ? 'Submitting...' : 'Submit Bug Report'}</span>
          </button>
        </form>
      )}

      {/* 2. REPORT AN ISSUE */}
      {panel === 'issue' && (
        <form
          onSubmit={(e) => void handleSubmitIssue(e)}
          className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4"
        >
          <div className="flex items-center gap-2">
            <ShieldAlert className="h-5 w-5 text-[#4E2A16]" />
            <h3 className="text-base font-bold text-[#1C1917]">Report an Issue</h3>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Issue Category *
              </label>
              <select
                value={issueCategory}
                onChange={(e) => setIssueCategory(e.target.value)}
                className="w-full rounded-xl border border-stone-300 bg-white px-3 py-2.5 text-sm min-h-[44px]"
              >
                {ISSUE_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Subject *
              </label>
              <input
                type="text"
                required
                dir="auto"
                value={issueSubject}
                onChange={(e) => setIssueSubject(e.target.value)}
                placeholder="Brief subject"
                className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[44px]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Description *
            </label>
            <textarea
              required
              rows={4}
              dir="auto"
              value={issueDesc}
              onChange={(e) => setIssueDesc(e.target.value)}
              placeholder="Describe the invoice, payment, calculation, or account issue..."
              className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm"
            />
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-stone-300 bg-[#FAF9F7] px-4 py-2.5 text-xs font-semibold text-[#1C1917] hover:bg-stone-100 min-h-[42px]">
              <ImagePlus className="h-4 w-4 text-[#4E2A16]" />
              <span>{issueScreenshot ? 'Change Screenshot' : 'Attach Screenshot (Optional)'}</span>
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={(e) => void handleScreenshot(e, setIssueScreenshot)}
                className="hidden"
              />
            </label>
            {issueScreenshot && (
              <button
                type="button"
                onClick={() => setIssueScreenshot(undefined)}
                className="text-xs font-semibold text-rose-700 hover:underline"
              >
                Remove Screenshot
              </button>
            )}
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-xl bg-[#4E2A16] px-6 py-3 text-sm font-bold text-white hover:bg-[#3E2723] disabled:opacity-60 min-h-[48px]"
          >
            <Send className="h-4 w-4" />
            <span>{submitting ? 'Submitting...' : 'Submit Report'}</span>
          </button>
        </form>
      )}

      {/* 3. CUSTOMER CARE */}
      {panel === 'care' && (
        <div className="rounded-2xl border border-stone-200/90 bg-white p-6 space-y-5">
          <div className="flex items-center gap-2.5">
            <Headphones className="h-5 w-5 text-[#4E2A16]" />
            <h3 className="text-base font-bold text-[#1C1917]">Customer Care</h3>
          </div>

          <div className="rounded-xl border border-stone-200 bg-[#FAF9F7] p-4 space-y-2 text-sm">
            <div>
              <span className="text-stone-500">Support Contact: </span>
              <span className="font-bold text-[#1C1917]">{SUPPORT_CONTACT_NAME}</span>
            </div>
            <div>
              <span className="text-stone-500">Support Email: </span>
              <a
                href={mailtoUrl}
                className="font-bold text-[#4E2A16] underline underline-offset-4"
              >
                {SUPPORT_EMAIL}
              </a>
            </div>
          </div>

          <a
            href={mailtoUrl}
            className="inline-flex w-full sm:w-auto items-center justify-center gap-2.5 rounded-xl bg-[#4E2A16] px-6 py-3.5 text-sm font-bold text-white hover:bg-[#3E2723] min-h-[48px]"
          >
            <Mail className="h-4 w-4" />
            <span>Contact Customer Care</span>
          </a>
        </div>
      )}

      {/* 4. FEEDBACK & SUGGESTIONS */}
      {panel === 'feedback' && (
        <form
          onSubmit={(e) => void handleSubmitFeedback(e)}
          className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-4"
        >
          <div className="flex items-center gap-2">
            <MessageSquarePlus className="h-5 w-5 text-[#4E2A16]" />
            <h3 className="text-base font-bold text-[#1C1917]">Feedback &amp; Suggestions</h3>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Feedback or Suggestion *
            </label>
            <textarea
              required
              rows={4}
              dir="auto"
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              placeholder="Tell us what features or improvements would help your café..."
              className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Optional Contact Info (Phone or Email)
            </label>
            <input
              type="text"
              value={feedbackContact}
              onChange={(e) => setFeedbackContact(e.target.value)}
              placeholder="Optional phone or email for follow-up"
              className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[44px]"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-xl bg-[#4E2A16] px-6 py-3 text-sm font-bold text-white hover:bg-[#3E2723] disabled:opacity-60 min-h-[48px]"
          >
            <Send className="h-4 w-4" />
            <span>{submitting ? 'Sending...' : 'Send Feedback'}</span>
          </button>
        </form>
      )}

      {/* 5. ABOUT CAFEPOS */}
      {panel === 'about' && (
        <div className="rounded-2xl border border-stone-200/90 bg-white p-6 space-y-4">
          <div className="flex items-center gap-3">
            <img
              src="/cafebill-logo.png"
              alt="CafePOS"
              className="h-12 w-12 rounded-xl object-cover shadow-xs"
            />
            <div>
              <h3 className="text-base font-bold text-[#1C1917]">About CafePOS</h3>
              <p className="text-xs text-stone-500">Version {APP_VERSION}</p>
            </div>
          </div>

          <div className="divide-y divide-stone-100 rounded-xl border border-stone-200 bg-[#FAF9F7] px-4 text-sm">
            <div className="flex items-center justify-between py-3">
              <span className="text-stone-500">Application Name</span>
              <span className="font-bold text-[#1C1917]">CafePOS</span>
            </div>
            <div className="flex items-center justify-between py-3">
              <span className="text-stone-500">Version</span>
              <span className="font-mono font-bold text-[#1C1917]">v{APP_VERSION}</span>
            </div>
            <div className="flex items-center justify-between py-3">
              <span className="text-stone-500">Developer / Support</span>
              <span className="font-bold text-[#1C1917]">{SUPPORT_CONTACT_NAME}</span>
            </div>
            <div className="flex items-center justify-between py-3">
              <span className="text-stone-500">Support Email</span>
              <a
                href={mailtoUrl}
                className="font-bold text-[#4E2A16] underline underline-offset-4"
              >
                {SUPPORT_EMAIL}
              </a>
            </div>
          </div>

          <p className="text-xs leading-relaxed text-stone-600">
            CafePOS is a mobile-first POS receipt and invoice generator built for cafés, coffee shops, bakeries, and small food businesses in the Maldives—featuring English &amp; Dhivehi (RTL) receipts, MVR &amp; USD currencies, open table orders, offline-first IndexedDB storage, and high-resolution PNG sharing.
          </p>
        </div>
      )}

      {/* Persistent Clickable Support Banner & Submitted Reports History */}
      <div className="rounded-2xl border border-stone-200/90 bg-white p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="text-xs font-bold text-stone-700">
            Your Submitted Support Reports ({submittedReports.length})
          </div>
          <a
            href={mailtoUrl}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-[#4E2A16] hover:underline"
          >
            <Mail className="h-3.5 w-3.5" />
            <span>{SUPPORT_EMAIL}</span>
          </a>
        </div>

        {submittedReports.length === 0 ? (
          <p className="text-xs text-stone-500">
            No support reports or feedback submitted yet.
          </p>
        ) : (
          <div className="divide-y divide-stone-100">
            {submittedReports.map((rep) => (
              <div key={rep.id} className="py-2.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-[#1C1917]">
                    {rep.title}
                  </span>
                  <span className="text-[11px] font-semibold text-stone-500">
                    {rep.type.toUpperCase()}
                    {rep.category ? ` · ${rep.category}` : ''}
                  </span>
                </div>
                <p className="mt-0.5 text-xs text-stone-600 line-clamp-2">{rep.description}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
