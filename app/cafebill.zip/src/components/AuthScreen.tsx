import React, { useState } from 'react';
import {
  ArrowLeft,
  Eye,
  EyeOff,
  KeyRound,
  Lock,
  Mail,
  Phone,
  PlayCircle,
  UserPlus,
} from 'lucide-react';
import {
  loginUser,
  registerUser,
  requestForgotPasswordOtp,
  resetPasswordWithOtp,
} from '../services/api';
import { COUNTRY_CODES, SUPPORT_EMAIL, type AuthUser } from '../types/auth';

interface AuthScreenProps {
  onAuthenticated: (user: AuthUser) => void;
  onContinueAsGuest: () => void;
}

type AuthMode = 'login' | 'register' | 'forgot';

export const AuthScreen: React.FC<AuthScreenProps> = ({
  onAuthenticated,
  onContinueAsGuest,
}) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [fullName, setFullName] = useState('');
  const [countryCode, setCountryCode] = useState('+960');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);

  // Forgot/Reset Password state
  const [forgotStep, setForgotStep] = useState<'request' | 'reset'>('request');
  const [otpCode, setOtpCode] = useState('');
  const [previewOtpHint, setPreviewOtpHint] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [infoMsg, setInfoMsg] = useState<string | null>(null);

  const resetMessages = () => {
    setErrorMsg(null);
    setInfoMsg(null);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    setLoading(true);
    try {
      const { user } = await loginUser({
        countryCode,
        phoneNumber,
        password,
        rememberMe,
      });
      onAuthenticated(user);
    } catch (err) {
      setErrorMsg((err as Error).message || 'Could not sign in.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    if (password !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      const { user } = await registerUser({
        fullName,
        countryCode,
        phoneNumber,
        password,
        rememberMe: true,
      });
      onAuthenticated(user);
    } catch (err) {
      setErrorMsg((err as Error).message || 'Could not create account.');
    } finally {
      setLoading(false);
    }
  };

  const handleRequestForgotOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    setLoading(true);
    try {
      const res = await requestForgotPasswordOtp({ countryCode, phoneNumber });
      setPreviewOtpHint(res.previewOtp || null);
      setInfoMsg(res.message);
      setForgotStep('reset');
    } catch (err) {
      setErrorMsg((err as Error).message || 'Could not start password reset.');
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    if (newPassword !== confirmNewPassword) {
      setErrorMsg('New passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      const res = await resetPasswordWithOtp({
        countryCode,
        phoneNumber,
        otp: otpCode,
        newPassword,
      });
      setInfoMsg(res.message);
      setMode('login');
      setForgotStep('request');
      setPassword('');
      setOtpCode('');
      setNewPassword('');
      setConfirmNewPassword('');
      setPreviewOtpHint(null);
    } catch (err) {
      setErrorMsg((err as Error).message || 'Failed to reset password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF9F7] flex flex-col justify-center px-4 py-8">
      <div className="mx-auto w-full max-w-md space-y-5">
        {/* Brand Header */}
        <div className="text-center space-y-2.5">
          <img
            src="/cafebill-logo.png"
            alt="CafePOS"
            className="mx-auto h-24 w-24 rounded-2xl object-cover shadow-md border border-[#4E2A16]/15"
          />
          <h1 className="text-2xl font-bold tracking-tight text-[#1C1917]">CafePOS</h1>
          <p className="text-sm text-stone-600">
            Café invoicing, POS Mobile App
          </p>
        </div>

        {/* Auth Card */}
        <div className="rounded-2xl border border-stone-200/90 bg-white p-5 sm:p-6 shadow-xs space-y-5">
          {mode !== 'forgot' && (
            <div className="grid grid-cols-2 gap-1 rounded-xl bg-[#FAF9F7] p-1 border border-stone-200/70">
              <button
                type="button"
                onClick={() => {
                  resetMessages();
                  setMode('login');
                }}
                className={`rounded-lg py-2.5 text-sm font-bold transition-colors min-h-[42px] ${
                  mode === 'login'
                    ? 'bg-[#4E2A16] text-white'
                    : 'text-stone-600 hover:text-[#1C1917]'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  resetMessages();
                  setMode('register');
                }}
                className={`rounded-lg py-2.5 text-sm font-bold transition-colors min-h-[42px] ${
                  mode === 'register'
                    ? 'bg-[#4E2A16] text-white'
                    : 'text-stone-600 hover:text-[#1C1917]'
                }`}
              >
                Create Account
              </button>
            </div>
          )}

          {errorMsg && (
            <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-semibold text-rose-900">
              {errorMsg}
            </div>
          )}

          {infoMsg && (
            <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-semibold text-emerald-900">
              {infoMsg}
            </div>
          )}

          {/* LOGIN FORM */}
          {mode === 'login' && (
            <form onSubmit={(e) => void handleLogin(e)} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  Mobile Phone Number
                </label>
                <div className="flex gap-2">
                  <select
                    value={countryCode}
                    onChange={(e) => setCountryCode(e.target.value)}
                    aria-label="Country code"
                    className="w-32 shrink-0 rounded-xl border border-stone-300 bg-white px-2.5 py-2.5 text-xs font-semibold text-[#1C1917] min-h-[46px]"
                  >
                    {COUNTRY_CODES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.code}
                      </option>
                    ))}
                  </select>
                  <div className="relative flex-1">
                    <Phone className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-stone-400" />
                    <input
                      type="tel"
                      required
                      dir="ltr"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="7771234"
                      className="w-full rounded-xl border border-stone-300 py-2.5 pr-3 pl-9 font-mono text-sm min-h-[46px]"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-stone-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full rounded-xl border border-stone-300 py-2.5 pr-11 pl-9 text-sm min-h-[46px]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute top-1/2 right-2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-lg text-stone-500 hover:bg-stone-100"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between gap-2">
                <label className="flex items-center gap-2 text-xs font-medium text-stone-700 cursor-pointer min-h-[36px]">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="h-4 w-4 accent-[#4E2A16]"
                  />
                  <span>Remember Me</span>
                </label>

                <button
                  type="button"
                  onClick={() => {
                    resetMessages();
                    setForgotStep('request');
                    setMode('forgot');
                  }}
                  className="text-xs font-bold text-[#4E2A16] hover:underline min-h-[36px]"
                >
                  Forgot Password?
                </button>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-xl bg-[#4E2A16] py-3.5 text-sm font-bold text-white shadow-xs transition-colors hover:bg-[#3E2723] disabled:opacity-60 min-h-[48px]"
              >
                {loading ? 'Signing In...' : 'Sign In'}
              </button>
            </form>
          )}

          {/* REGISTRATION FORM */}
          {mode === 'register' && (
            <form onSubmit={(e) => void handleRegister(e)} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  dir="auto"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Mohamed Ali"
                  className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[46px]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  Mobile Phone Number *
                </label>
                <div className="flex gap-2">
                  <select
                    value={countryCode}
                    onChange={(e) => setCountryCode(e.target.value)}
                    aria-label="Country code"
                    className="w-36 shrink-0 rounded-xl border border-stone-300 bg-white px-2.5 py-2.5 text-xs font-semibold text-[#1C1917] min-h-[46px]"
                  >
                    {COUNTRY_CODES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                  <input
                    type="tel"
                    required
                    dir="ltr"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="7771234"
                    className="flex-1 rounded-xl border border-stone-300 px-3 py-2.5 font-mono text-sm min-h-[46px]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  Password (min 6 characters) *
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Create a password"
                  className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[46px]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  Confirm Password *
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repeat your password"
                  className="w-full rounded-xl border border-stone-300 px-3.5 py-2.5 text-sm min-h-[46px]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#4E2A16] py-3.5 text-sm font-bold text-white shadow-xs transition-colors hover:bg-[#3E2723] disabled:opacity-60 min-h-[48px]"
              >
                <UserPlus className="h-4 w-4" />
                <span>{loading ? 'Creating Account...' : 'Create Account'}</span>
              </button>
            </form>
          )}

          {/* FORGOT / RESET PASSWORD */}
          {mode === 'forgot' && (
            <div className="space-y-4">
              <button
                type="button"
                onClick={() => {
                  resetMessages();
                  setMode('login');
                }}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#4E2A16] hover:underline"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
                <span>Back to Sign In</span>
              </button>

              <div className="flex items-center gap-2">
                <KeyRound className="h-5 w-5 text-[#4E2A16]" />
                <h2 className="text-base font-bold text-[#1C1917]">Reset Password</h2>
              </div>

              {forgotStep === 'request' ? (
                <form onSubmit={(e) => void handleRequestForgotOtp(e)} className="space-y-4">
                  <p className="text-xs text-stone-600">
                    Enter your registered mobile number to receive a 6-digit password reset code.
                  </p>
                  <div className="flex gap-2">
                    <select
                      value={countryCode}
                      onChange={(e) => setCountryCode(e.target.value)}
                      className="w-28 shrink-0 rounded-xl border border-stone-300 bg-white px-2.5 py-2.5 text-xs font-semibold min-h-[46px]"
                    >
                      {COUNTRY_CODES.map((c) => (
                        <option key={c.code} value={c.code}>
                          {c.code}
                        </option>
                      ))}
                    </select>
                    <input
                      type="tel"
                      required
                      dir="ltr"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="7771234"
                      className="flex-1 rounded-xl border border-stone-300 px-3 py-2.5 font-mono text-sm min-h-[46px]"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full rounded-xl bg-[#4E2A16] py-3 text-sm font-bold text-white hover:bg-[#3E2723] disabled:opacity-60 min-h-[46px]"
                  >
                    {loading ? 'Sending Code...' : 'Send Verification Code'}
                  </button>
                </form>
              ) : (
                <form onSubmit={(e) => void handleResetPassword(e)} className="space-y-3.5">
                  {previewOtpHint && (
                    <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-950">
                      Verification Code:{' '}
                      <span className="font-mono text-sm font-bold">{previewOtpHint}</span>
                    </div>
                  )}
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      6-Digit Verification Code
                    </label>
                    <input
                      type="text"
                      required
                      dir="ltr"
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value)}
                      placeholder="123456"
                      className="w-full rounded-xl border border-stone-300 px-3 py-2.5 font-mono text-sm min-h-[44px]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      New Password
                    </label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="At least 6 characters"
                      className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Confirm New Password
                    </label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={confirmNewPassword}
                      onChange={(e) => setConfirmNewPassword(e.target.value)}
                      placeholder="Repeat new password"
                      className="w-full rounded-xl border border-stone-300 px-3 py-2.5 text-sm min-h-[44px]"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full rounded-xl bg-[#4E2A16] py-3 text-sm font-bold text-white hover:bg-[#3E2723] disabled:opacity-60 min-h-[46px]"
                  >
                    {loading ? 'Updating...' : 'Reset Password'}
                  </button>
                </form>
              )}
            </div>
          )}
        </div>

        {/* Guest / Demo Mode Button */}
        <div className="rounded-2xl border border-stone-200/90 bg-white p-4 shadow-xs text-center space-y-2.5">
          <button
            type="button"
            onClick={onContinueAsGuest}
            className="flex w-full items-center justify-center gap-2 rounded-xl border-2 border-[#4E2A16] bg-[#FAF6F0] py-3 text-sm font-bold text-[#4E2A16] transition-colors hover:bg-[#F3EBE0] min-h-[48px]"
          >
            <PlayCircle className="h-4 w-4" />
            <span>Test App Without Logging In</span>
          </button>
          <p className="text-[11px] text-stone-500">
            Try POS orders, receipts &amp; PNG export locally on this device—no account needed.
          </p>
        </div>

        {/* Clickable Support Email Footer */}
        <p className="text-center text-xs text-stone-500">
          Need help? Contact{' '}
          <a
            href={`mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent('CafePOS Customer Support')}`}
            className="inline-flex items-center gap-1 font-semibold text-[#4E2A16] hover:underline"
          >
            <Mail className="h-3.5 w-3.5" />
            <span>{SUPPORT_EMAIL}</span>
          </a>
        </p>
      </div>
    </div>
  );
};
