import React, { useRef, useState } from 'react';
import {
  CheckCircle2,
  Copy,
  Download,
  Edit3,
  Share2,
  X,
} from 'lucide-react';
import type {
  BankAccount,
  BusinessProfile,
  Invoice,
  InvoiceLayoutStyle,
  PosWidth,
  TranslationMap,
} from '../types/invoice';
import {
  copyPngToClipboard,
  downloadPngBlob,
  generateInvoicePngBlob,
  isClipboardImageSupported,
  shareInvoicePng,
} from '../utils/pngExport';
import { InvoiceDocument } from './InvoiceDocument';

interface InvoicePreviewModalProps {
  invoice: Invoice | null;
  businessProfile: BusinessProfile;
  bankAccounts: BankAccount[];
  translations: TranslationMap;
  exchangeRateUsdToMvr: number;
  customFontDataUrl?: string;
  onClose: () => void;
  onMarkPaid?: (invoice: Invoice) => void;
  onEdit?: (invoice: Invoice) => void;
  onNotify: (message: string, type?: 'success' | 'info' | 'error') => void;
}

export const InvoicePreviewModal: React.FC<InvoicePreviewModalProps> = ({
  invoice,
  businessProfile,
  bankAccounts,
  translations,
  exchangeRateUsdToMvr,
  customFontDataUrl,
  onClose,
  onMarkPaid,
  onEdit,
  onNotify,
}) => {
  const exportRef = useRef<HTMLDivElement>(null);
  const [busyAction, setBusyAction] = useState<'download' | 'share' | 'copy' | null>(null);
  const [previewStyle, setPreviewStyle] = useState<InvoiceLayoutStyle | null>(null);
  const [previewWidth, setPreviewWidth] = useState<PosWidth | null>(null);

  if (!invoice) return null;

  const activeInvoice: Invoice = {
    ...invoice,
    layoutStyle: previewStyle ?? invoice.layoutStyle,
    posWidth: previewWidth ?? invoice.posWidth,
  };

  const handleDownload = async () => {
    if (!exportRef.current) return;
    setBusyAction('download');
    try {
      const blob = await generateInvoicePngBlob(exportRef.current, customFontDataUrl);
      downloadPngBlob(blob, `${activeInvoice.invoiceNumber}.png`);
      onNotify(`Downloaded ${activeInvoice.invoiceNumber}.png`, 'success');
    } catch {
      onNotify('Failed to generate PNG image.', 'error');
    } finally {
      setBusyAction(null);
    }
  };

  const handleShare = async () => {
    if (!exportRef.current) return;
    setBusyAction('share');
    try {
      const blob = await generateInvoicePngBlob(exportRef.current, customFontDataUrl);
      const result = await shareInvoicePng(
        blob,
        `${activeInvoice.invoiceNumber}.png`,
        `${businessProfile.name} — ${activeInvoice.invoiceNumber}`,
        `Invoice ${activeInvoice.invoiceNumber}`
      );
      if (result.method === 'web-share') {
        onNotify('Invoice shared.', 'success');
      } else {
        onNotify(
          'PNG downloaded — attach it directly in WhatsApp or your messaging app.',
          'info'
        );
      }
    } catch (err) {
      if ((err as Error)?.name !== 'AbortError') {
        onNotify('Unable to share image right now.', 'error');
      }
    } finally {
      setBusyAction(null);
    }
  };

  const handleCopy = async () => {
    if (!exportRef.current) return;
    setBusyAction('copy');
    try {
      const blob = await generateInvoicePngBlob(exportRef.current, customFontDataUrl);
      const copied = await copyPngToClipboard(blob);
      if (copied) {
        onNotify('Invoice image copied to clipboard.', 'success');
      } else {
        onNotify('Clipboard image copy is not supported on this browser.', 'info');
      }
    } catch {
      onNotify('Could not copy image to clipboard.', 'error');
    } finally {
      setBusyAction(null);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-stone-900/70 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
    >
      {/* Top Toolbar */}
      <div className="flex items-center justify-between gap-3 border-b border-stone-200 bg-white px-4 py-3">
        <div className="min-w-0">
          <h2 className="truncate text-sm font-bold text-[#1C1917]">
            {activeInvoice.invoiceNumber}
          </h2>
          <p className="truncate text-xs text-stone-500">
            {activeInvoice.customerName || 'Walk-in Customer'}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {/* Quick Style Toggle */}
          <div className="hidden sm:flex items-center rounded-xl bg-stone-100 p-1">
            <button
              type="button"
              onClick={() => {
                setPreviewStyle('pos');
                setPreviewWidth('58mm');
              }}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors ${
                activeInvoice.layoutStyle === 'pos' && activeInvoice.posWidth === '58mm'
                  ? 'bg-white text-[#1C1917] shadow-xs'
                  : 'text-stone-600 hover:text-[#1C1917]'
              }`}
            >
              58mm
            </button>
            <button
              type="button"
              onClick={() => {
                setPreviewStyle('pos');
                setPreviewWidth('80mm');
              }}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors ${
                activeInvoice.layoutStyle === 'pos' && activeInvoice.posWidth === '80mm'
                  ? 'bg-white text-[#1C1917] shadow-xs'
                  : 'text-stone-600 hover:text-[#1C1917]'
              }`}
            >
              80mm
            </button>
            <button
              type="button"
              onClick={() => setPreviewStyle('a4')}
              className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors ${
                activeInvoice.layoutStyle === 'a4'
                  ? 'bg-white text-[#1C1917] shadow-xs'
                  : 'text-stone-600 hover:text-[#1C1917]'
              }`}
            >
              A4
            </button>
          </div>

          {onEdit && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onEdit(invoice);
              }}
              className="inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 min-h-[40px]"
            >
              <Edit3 className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Edit</span>
            </button>
          )}

          <button
            type="button"
            onClick={onClose}
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-stone-200 bg-white text-stone-600 hover:bg-stone-100"
            aria-label="Close preview"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Mobile Style Switcher */}
      <div className="flex sm:hidden items-center justify-center gap-1 border-b border-stone-200 bg-stone-50 px-4 py-2">
        <button
          type="button"
          onClick={() => {
            setPreviewStyle('pos');
            setPreviewWidth('58mm');
          }}
          className={`flex-1 rounded-lg py-1.5 text-xs font-semibold ${
            activeInvoice.layoutStyle === 'pos' && activeInvoice.posWidth === '58mm'
              ? 'bg-white text-[#1C1917] shadow-xs'
              : 'text-stone-600'
          }`}
        >
          POS 58mm
        </button>
        <button
          type="button"
          onClick={() => {
            setPreviewStyle('pos');
            setPreviewWidth('80mm');
          }}
          className={`flex-1 rounded-lg py-1.5 text-xs font-semibold ${
            activeInvoice.layoutStyle === 'pos' && activeInvoice.posWidth === '80mm'
              ? 'bg-white text-[#1C1917] shadow-xs'
              : 'text-stone-600'
          }`}
        >
          POS 80mm
        </button>
        <button
          type="button"
          onClick={() => setPreviewStyle('a4')}
          className={`flex-1 rounded-lg py-1.5 text-xs font-semibold ${
            activeInvoice.layoutStyle === 'a4'
              ? 'bg-white text-[#1C1917] shadow-xs'
              : 'text-stone-600'
          }`}
        >
          A4 Invoice
        </button>
      </div>

      {/* Scrollable Invoice Canvas */}
      <div className="flex-1 overflow-auto p-4 sm:p-8">
        <div className="mx-auto w-fit rounded-xl shadow-2xl overflow-hidden bg-white">
          <InvoiceDocument
            invoice={activeInvoice}
            businessProfile={businessProfile}
            bankAccounts={bankAccounts}
            translations={translations}
            exchangeRateUsdToMvr={exchangeRateUsdToMvr}
            exportRef={exportRef}
          />
        </div>
      </div>

      {/* Bottom Action Bar */}
      <div className="border-t border-stone-200 bg-white px-4 py-3 pb-safe">
        <div className="mx-auto flex max-w-3xl flex-wrap items-center justify-center gap-2.5">
          {invoice.paymentStatus !== 'PAID' && onMarkPaid && (
            <button
              type="button"
              onClick={() => onMarkPaid(invoice)}
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-emerald-700 bg-emerald-50 px-4 py-2.5 text-sm font-semibold text-emerald-800 hover:bg-emerald-100 min-h-[44px]"
            >
              <CheckCircle2 className="h-4 w-4" />
              <span>Mark as Paid</span>
            </button>
          )}

          <button
            type="button"
            disabled={busyAction !== null}
            onClick={() => void handleDownload()}
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-sm font-semibold text-[#1C1917] hover:bg-stone-50 disabled:opacity-50 min-h-[44px]"
          >
            <Download className="h-4 w-4" />
            <span>{busyAction === 'download' ? 'Exporting...' : 'Download PNG'}</span>
          </button>

          {isClipboardImageSupported() && (
            <button
              type="button"
              disabled={busyAction !== null}
              onClick={() => void handleCopy()}
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-sm font-semibold text-[#1C1917] hover:bg-stone-50 disabled:opacity-50 min-h-[44px]"
            >
              <Copy className="h-4 w-4" />
              <span>{busyAction === 'copy' ? 'Copying...' : 'Copy Image'}</span>
            </button>
          )}

          <button
            type="button"
            disabled={busyAction !== null}
            onClick={() => void handleShare()}
            className="inline-flex flex-1 sm:flex-initial items-center justify-center gap-2 rounded-xl bg-[#2C1B18] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#3E2723] disabled:opacity-50 min-h-[44px]"
          >
            <Share2 className="h-4 w-4" />
            <span>{busyAction === 'share' ? 'Preparing...' : 'Share Invoice'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
