import type { InvoiceLabels, InvoiceLanguage, PaymentMethod, PaymentStatus, TranslationMap } from '../types/invoice';

export const DEFAULT_TRANSLATIONS: TranslationMap = {
  en: {
    invoiceTitle: 'INVOICE',
    receiptTitle: 'RECEIPT',
    invoiceNumber: 'Invoice Number',
    date: 'Date',
    table: 'Table / Order',
    customer: 'Customer',
    phone: 'Phone',
    email: 'Email',
    description: 'Description',
    quantity: 'Qty',
    unitPrice: 'Unit Price',
    amount: 'Amount',
    subtotal: 'Subtotal',
    discount: 'Discount',
    additionalCharges: 'Additional Charges',
    total: 'Total',
    paymentMethod: 'Payment Method',
    paymentStatus: 'Payment Status',
    paid: 'PAID',
    unpaid: 'UNPAID',
    partiallyPaid: 'PARTIALLY PAID',
    amountPaid: 'Amount Paid',
    balanceDue: 'Balance Due',
    paymentDate: 'Payment Date',
    bankTransferDetails: 'Bank Transfer Details',
    bankName: 'Bank',
    accountName: 'Account Name',
    accountNumber: 'Account No.',
    branch: 'Branch',
    notes: 'Notes',
    paymentInstructions: 'Payment Instructions',
    thankYou: 'Thank You!',
    cash: 'Cash',
    bankTransfer: 'Bank Transfer',
    card: 'Card',
    mobilePay: 'Mobile Pay',
    other: 'Other',
    regNo: 'Reg No.',
    convertedRef: 'Approx. Equivalent',
  },
  dv: {
    invoiceTitle: 'އިންވޮއިސް',
    receiptTitle: 'ރަސީދު',
    invoiceNumber: 'ނަންބަރު',
    date: 'ތާރީޚު',
    table: 'މޭޒު / އޯޑަރު',
    customer: 'ކަސްޓަމަރު',
    phone: 'ފޯނު',
    email: 'އީމެއިލް',
    description: 'ތަފްޞީލު',
    quantity: 'އަދަދު',
    unitPrice: 'އަގު',
    amount: 'ޖުމްލަ',
    subtotal: 'ޖުމްލަ',
    discount: 'ޑިސްކައުންޓް',
    additionalCharges: 'އިތުރު ޗާޖު',
    total: 'ޖުމްލަ އަގު',
    paymentMethod: 'ފައިސާ ދެއްކި ގޮތް',
    paymentStatus: 'ފައިސާގެ ޙާލަތު',
    paid: 'ފައިސާ ދައްކާފައި',
    unpaid: 'ފައިސާ ނުދައްކާ',
    partiallyPaid: 'ބައެއް ދައްކާފައި',
    amountPaid: 'ދެއްކި އަދަދު',
    balanceDue: 'ބާކީ އަދަދު',
    paymentDate: 'ފައިސާ ދެއްކި ތާރީޚު',
    bankTransferDetails: 'ބޭންކް ޓްރާންސްފަރ މަޢުލޫމާތު',
    bankName: 'ބޭންކް',
    accountName: 'އެކައުންޓްގެ ނަން',
    accountNumber: 'އެކައުންޓް ނަންބަރު',
    branch: 'ބްރާންޗް',
    notes: 'ނޯޓް',
    paymentInstructions: 'ފައިސާ ދެއްކުމުގެ އިރުޝާދު',
    thankYou: 'ޝުކުރިއްޔާ!',
    cash: 'ނަގުދު ފައިސާ',
    bankTransfer: 'ބޭންކް ޓްރާންސްފަރ',
    card: 'ކާޑު',
    mobilePay: 'މޯބައިލް ޕޭ',
    other: 'އެހެނިހެން',
    regNo: 'ރަޖިސްޓްރީ ނަންބަރު',
    convertedRef: 'ގާތްގަނޑަކަށް',
  },
};

export const TRANSLATION_FIELD_META: { key: keyof InvoiceLabels; label: string }[] = [
  { key: 'invoiceTitle', label: 'Invoice Title' },
  { key: 'receiptTitle', label: 'Receipt Title (POS)' },
  { key: 'invoiceNumber', label: 'Invoice Number' },
  { key: 'date', label: 'Date' },
  { key: 'table', label: 'Table / Order' },
  { key: 'customer', label: 'Customer' },
  { key: 'phone', label: 'Phone' },
  { key: 'email', label: 'Email' },
  { key: 'description', label: 'Item Description' },
  { key: 'quantity', label: 'Quantity' },
  { key: 'unitPrice', label: 'Unit Price' },
  { key: 'amount', label: 'Line Amount' },
  { key: 'subtotal', label: 'Subtotal' },
  { key: 'discount', label: 'Discount' },
  { key: 'additionalCharges', label: 'Additional Charges' },
  { key: 'total', label: 'Grand Total' },
  { key: 'paymentMethod', label: 'Payment Method' },
  { key: 'paymentStatus', label: 'Payment Status' },
  { key: 'paid', label: 'Status: PAID' },
  { key: 'unpaid', label: 'Status: UNPAID' },
  { key: 'partiallyPaid', label: 'Status: PARTIALLY PAID' },
  { key: 'amountPaid', label: 'Amount Paid' },
  { key: 'balanceDue', label: 'Balance Due' },
  { key: 'paymentDate', label: 'Payment Date' },
  { key: 'bankTransferDetails', label: 'Bank Transfer Heading' },
  { key: 'bankName', label: 'Bank Name' },
  { key: 'accountName', label: 'Account Holder Name' },
  { key: 'accountNumber', label: 'Account Number' },
  { key: 'branch', label: 'Bank Branch' },
  { key: 'notes', label: 'Notes Heading' },
  { key: 'paymentInstructions', label: 'Payment Instructions Heading' },
  { key: 'thankYou', label: 'Thank You Message' },
  { key: 'cash', label: 'Method: Cash' },
  { key: 'bankTransfer', label: 'Method: Bank Transfer' },
  { key: 'card', label: 'Method: Card' },
  { key: 'mobilePay', label: 'Method: Mobile Pay' },
  { key: 'other', label: 'Method: Other' },
  { key: 'regNo', label: 'Business Reg No.' },
  { key: 'convertedRef', label: 'Conversion Reference Label' },
];

export function getLabels(translations: TranslationMap, language: InvoiceLanguage): InvoiceLabels {
  return {
    ...DEFAULT_TRANSLATIONS[language],
    ...(translations[language] || {}),
  };
}

export function getPaymentMethodLabel(
  labels: InvoiceLabels,
  method: PaymentMethod
): string {
  switch (method) {
    case 'cash':
      return labels.cash;
    case 'bank_transfer':
      return labels.bankTransfer;
    case 'card':
      return labels.card;
    case 'mobile_pay':
      return labels.mobilePay;
    case 'other':
    default:
      return labels.other;
  }
}

export function getPaymentStatusLabel(
  labels: InvoiceLabels,
  status: PaymentStatus
): string {
  switch (status) {
    case 'PAID':
      return labels.paid;
    case 'PARTIALLY_PAID':
      return labels.partiallyPaid;
    case 'UNPAID':
    default:
      return labels.unpaid;
  }
}
