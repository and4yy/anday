import express, { type NextFunction, type Request, type Response } from 'express';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'cafebill-server.json');
const SECRET_FILE = path.join(DATA_DIR, '.session-secret');

interface ServerUser {
  id: string;
  fullName: string;
  countryCode: string;
  phoneNumber: string;
  normalizedPhone: string;
  passwordHash: string;
  onboardingCompleted: boolean;
  createdAt: string;
  updatedAt: string;
}

interface OtpChallenge {
  purpose: 'reset_password' | 'change_phone';
  userId: string;
  targetPhone: string;
  codeHash: string;
  expiresAt: number;
}

interface SupportReportRecord {
  id: string;
  userId: string;
  type: 'bug' | 'issue' | 'feedback';
  category?: string;
  title: string;
  description: string;
  contactInfo?: string;
  screenshotDataUrl?: string;
  appVersion?: string;
  deviceInfo?: string;
  createdAt: string;
}

interface WorkspacePayload {
  businessProfile?: unknown;
  bankAccounts?: unknown[];
  translations?: unknown;
  preferences?: unknown;
  quickMenuItems?: unknown[];
  customers?: unknown[];
  invoices?: unknown[];
  openOrders?: unknown[];
  updatedAt: string;
}

interface ServerStore {
  users: ServerUser[];
  otps: OtpChallenge[];
  workspaces: Record<string, WorkspacePayload>;
  supportReports: SupportReportRecord[];
}

function ensureDataDir(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
  }
}

function getSessionSecret(): string {
  if (process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 16) {
    return process.env.SESSION_SECRET;
  }
  ensureDataDir();
  if (fs.existsSync(SECRET_FILE)) {
    return fs.readFileSync(SECRET_FILE, 'utf8').trim();
  }
  const generated = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(SECRET_FILE, generated, { mode: 0o600 });
  return generated;
}

const SESSION_SECRET = getSessionSecret();

function readStore(): ServerStore {
  ensureDataDir();
  if (!fs.existsSync(DB_FILE)) {
    const initial: ServerStore = {
      users: [],
      otps: [],
      workspaces: {},
      supportReports: [],
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2), { mode: 0o600 });
    return initial;
  }
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    const parsed = JSON.parse(raw) as Partial<ServerStore>;
    return {
      users: Array.isArray(parsed.users) ? parsed.users : [],
      otps: Array.isArray(parsed.otps) ? parsed.otps : [],
      workspaces: parsed.workspaces && typeof parsed.workspaces === 'object' ? parsed.workspaces : {},
      supportReports: Array.isArray(parsed.supportReports) ? parsed.supportReports : [],
    };
  } catch {
    return { users: [], otps: [], workspaces: {}, supportReports: [] };
  }
}

function writeStore(store: ServerStore): void {
  ensureDataDir();
  const tmpFile = `${DB_FILE}.tmp`;
  fs.writeFileSync(tmpFile, JSON.stringify(store, null, 2), { mode: 0o600 });
  fs.renameSync(tmpFile, DB_FILE);
}

function normalizePhone(countryCode: string, phoneNumber: string): string {
  const cc = countryCode.replace(/[^\d+]/g, '');
  const digits = phoneNumber.replace(/\D/g, '');
  const prefix = cc.startsWith('+') ? cc : `+${cc}`;
  return `${prefix}${digits}`;
}

function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const keyBuf = Buffer.from(keyHex, 'hex');
  const derivedBuf = crypto.scryptSync(password, salt, 64);
  if (keyBuf.length !== derivedBuf.length) return false;
  return crypto.timingSafeEqual(keyBuf, derivedBuf);
}

function hashOtp(code: string): string {
  return crypto.createHmac('sha256', SESSION_SECRET).update(code).digest('hex');
}

function signSessionToken(userId: string, rememberMe: boolean): string {
  const ttlMs = rememberMe ? 30 * 24 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000;
  const payload = Buffer.from(
    JSON.stringify({
      uid: userId,
      exp: Date.now() + ttlMs,
      iat: Date.now(),
    })
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

function verifySessionToken(token: string): { uid: string; exp: number } | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [payload, sig] = parts;
  const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as {
      uid?: string;
      exp?: number;
    };
    if (!decoded.uid || !decoded.exp || decoded.exp < Date.now()) {
      return null;
    }
    return { uid: decoded.uid, exp: decoded.exp };
  } catch {
    return null;
  }
}

function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!cookieHeader) return out;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx > 0) {
      const k = part.slice(0, idx).trim();
      const v = part.slice(idx + 1).trim();
      out[k] = decodeURIComponent(v);
    }
  }
  return out;
}

function sanitizeUser(u: ServerUser) {
  return {
    id: u.id,
    fullName: u.fullName,
    countryCode: u.countryCode,
    phoneNumber: u.phoneNumber,
    normalizedPhone: u.normalizedPhone,
    onboardingCompleted: u.onboardingCompleted,
    createdAt: u.createdAt,
  };
}

interface AuthedRequest extends Request {
  userId?: string;
}

function requireAuth(req: AuthedRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  let token = '';
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7).trim();
  } else {
    const cookies = parseCookies(req.headers.cookie);
    token = cookies['cafebill_session'] || '';
  }

  if (!token) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }

  const verified = verifySessionToken(token);
  if (!verified) {
    res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
    return;
  }

  const store = readStore();
  const userExists = store.users.some((u) => u.id === verified.uid);
  if (!userExists) {
    res.status(401).json({ error: 'Account not found.' });
    return;
  }

  req.userId = verified.uid;
  next();
}

function setSessionCookie(res: Response, token: string, rememberMe: boolean): void {
  const maxAge = rememberMe ? 30 * 24 * 60 * 60 : 24 * 60 * 60;
  res.setHeader(
    'Set-Cookie',
    `cafebill_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`
  );
}

function clearSessionCookie(res: Response): void {
  res.setHeader(
    'Set-Cookie',
    'cafebill_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0'
  );
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '6mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  // 1. Register
  app.post('/api/auth/register', (req, res) => {
    const body = req.body as {
      fullName?: string;
      countryCode?: string;
      phoneNumber?: string;
      password?: string;
      rememberMe?: boolean;
    };

    const fullName = String(body.fullName || '').trim();
    const countryCode = String(body.countryCode || '+960').trim();
    const phoneNumber = String(body.phoneNumber || '').replace(/\D/g, '');
    const password = String(body.password || '');
    const rememberMe = Boolean(body.rememberMe ?? true);

    if (fullName.length < 2 || fullName.length > 120) {
      res.status(400).json({ error: 'Please enter your full name (2–120 characters).' });
      return;
    }
    if (phoneNumber.length < 6 || phoneNumber.length > 15) {
      res.status(400).json({ error: 'Please enter a valid mobile phone number.' });
      return;
    }
    if (password.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters long.' });
      return;
    }

    const normalizedPhone = normalizePhone(countryCode, phoneNumber);
    const store = readStore();

    if (store.users.some((u) => u.normalizedPhone === normalizedPhone)) {
      res.status(409).json({
        error: 'An account with this mobile number already exists. Please sign in instead.',
      });
      return;
    }

    const now = new Date().toISOString();
    const newUser: ServerUser = {
      id: `usr_${crypto.randomUUID().replace(/-/g, '').slice(0, 16)}`,
      fullName,
      countryCode,
      phoneNumber,
      normalizedPhone,
      passwordHash: hashPassword(password),
      onboardingCompleted: false,
      createdAt: now,
      updatedAt: now,
    };

    store.users.push(newUser);
    store.workspaces[newUser.id] = {
      updatedAt: now,
    };
    writeStore(store);

    const token = signSessionToken(newUser.id, rememberMe);
    setSessionCookie(res, token, rememberMe);

    res.status(201).json({
      user: sanitizeUser(newUser),
      token,
    });
  });

  // 2. Login
  app.post('/api/auth/login', (req, res) => {
    const body = req.body as {
      countryCode?: string;
      phoneNumber?: string;
      password?: string;
      rememberMe?: boolean;
    };

    const countryCode = String(body.countryCode || '+960').trim();
    const phoneNumber = String(body.phoneNumber || '').replace(/\D/g, '');
    const password = String(body.password || '');
    const rememberMe = Boolean(body.rememberMe);

    if (!phoneNumber || !password) {
      res.status(400).json({ error: 'Mobile number and password are required.' });
      return;
    }

    const normalizedPhone = normalizePhone(countryCode, phoneNumber);
    const store = readStore();
    const user = store.users.find((u) => u.normalizedPhone === normalizedPhone);

    if (!user || !verifyPassword(password, user.passwordHash)) {
      res.status(401).json({ error: 'Invalid mobile number or password.' });
      return;
    }

    const token = signSessionToken(user.id, rememberMe);
    setSessionCookie(res, token, rememberMe);

    res.json({
      user: sanitizeUser(user),
      token,
    });
  });

  // 3. Logout
  app.post('/api/auth/logout', (_req, res) => {
    clearSessionCookie(res);
    res.json({ ok: true });
  });

  // 4. Current User
  app.get('/api/auth/me', requireAuth, (req: AuthedRequest, res) => {
    const store = readStore();
    const user = store.users.find((u) => u.id === req.userId);
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    res.json({ user: sanitizeUser(user) });
  });

  // 5. Forgot Password (Free Built-in OTP Request)
  app.post('/api/auth/forgot-password', (req, res) => {
    const body = req.body as { countryCode?: string; phoneNumber?: string };
    const countryCode = String(body.countryCode || '+960').trim();
    const phoneNumber = String(body.phoneNumber || '').replace(/\D/g, '');

    if (phoneNumber.length < 6) {
      res.status(400).json({ error: 'Please enter a valid mobile number.' });
      return;
    }

    const normalizedPhone = normalizePhone(countryCode, phoneNumber);
    const store = readStore();
    const user = store.users.find((u) => u.normalizedPhone === normalizedPhone);

    if (!user) {
      res.status(404).json({ error: 'No account found with that mobile number.' });
      return;
    }

    const code = String(crypto.randomInt(100000, 999999));
    store.otps = store.otps.filter(
      (o) =>
        !(o.userId === user.id && o.purpose === 'reset_password') &&
        o.expiresAt > Date.now()
    );
    store.otps.push({
      purpose: 'reset_password',
      userId: user.id,
      targetPhone: normalizedPhone,
      codeHash: hashOtp(code),
      expiresAt: Date.now() + 10 * 60 * 1000,
    });
    writeStore(store);

    res.json({
      ok: true,
      smsSent: false,
      previewOtp: code,
      message: 'Verification code generated. Use the 6-digit code shown below to reset your password.',
    });
  });

  // 6. Reset Password
  app.post('/api/auth/reset-password', (req, res) => {
    const body = req.body as {
      countryCode?: string;
      phoneNumber?: string;
      otp?: string;
      newPassword?: string;
    };

    const countryCode = String(body.countryCode || '+960').trim();
    const phoneNumber = String(body.phoneNumber || '').replace(/\D/g, '');
    const otp = String(body.otp || '').trim();
    const newPassword = String(body.newPassword || '');

    if (newPassword.length < 6) {
      res.status(400).json({ error: 'New password must be at least 6 characters.' });
      return;
    }

    const normalizedPhone = normalizePhone(countryCode, phoneNumber);
    const store = readStore();
    const user = store.users.find((u) => u.normalizedPhone === normalizedPhone);
    if (!user) {
      res.status(404).json({ error: 'Account not found.' });
      return;
    }

    const otpIdx = store.otps.findIndex(
      (o) =>
        o.userId === user.id &&
        o.purpose === 'reset_password' &&
        o.targetPhone === normalizedPhone &&
        o.expiresAt > Date.now() &&
        o.codeHash === hashOtp(otp)
    );

    if (otpIdx === -1) {
      res.status(400).json({ error: 'Invalid or expired verification code.' });
      return;
    }

    user.passwordHash = hashPassword(newPassword);
    user.updatedAt = new Date().toISOString();
    store.otps.splice(otpIdx, 1);
    writeStore(store);

    res.json({ ok: true, message: 'Password has been reset. You can now sign in.' });
  });

  // 7. Update Profile Name
  app.put('/api/account/profile', requireAuth, (req: AuthedRequest, res) => {
    const fullName = String((req.body as { fullName?: string }).fullName || '').trim();
    if (fullName.length < 2 || fullName.length > 120) {
      res.status(400).json({ error: 'Full name must be 2–120 characters.' });
      return;
    }

    const store = readStore();
    const user = store.users.find((u) => u.id === req.userId);
    if (!user) {
      res.status(404).json({ error: 'Account not found.' });
      return;
    }

    user.fullName = fullName;
    user.updatedAt = new Date().toISOString();
    writeStore(store);

    res.json({ user: sanitizeUser(user) });
  });

  // 8. Request OTP for Changing Mobile Number (Free Built-in Verification)
  app.post('/api/account/request-phone-otp', requireAuth, (req: AuthedRequest, res) => {
    const body = req.body as { countryCode?: string; phoneNumber?: string };
    const countryCode = String(body.countryCode || '+960').trim();
    const phoneNumber = String(body.phoneNumber || '').replace(/\D/g, '');

    if (phoneNumber.length < 6 || phoneNumber.length > 15) {
      res.status(400).json({ error: 'Please enter a valid new mobile number.' });
      return;
    }

    const normalizedPhone = normalizePhone(countryCode, phoneNumber);
    const store = readStore();
    if (store.users.some((u) => u.normalizedPhone === normalizedPhone && u.id !== req.userId)) {
      res.status(409).json({ error: 'That mobile number is already linked to another account.' });
      return;
    }

    const code = String(crypto.randomInt(100000, 999999));
    store.otps = store.otps.filter(
      (o) =>
        !(o.userId === req.userId && o.purpose === 'change_phone') &&
        o.expiresAt > Date.now()
    );
    store.otps.push({
      purpose: 'change_phone',
      userId: req.userId!,
      targetPhone: normalizedPhone,
      codeHash: hashOtp(code),
      expiresAt: Date.now() + 10 * 60 * 1000,
    });
    writeStore(store);

    res.json({
      ok: true,
      smsSent: false,
      previewOtp: code,
    });
  });

  // 9. Verify OTP & Update Mobile Number
  app.post('/api/account/verify-phone-change', requireAuth, (req: AuthedRequest, res) => {
    const body = req.body as {
      countryCode?: string;
      phoneNumber?: string;
      otp?: string;
      currentPassword?: string;
    };

    const countryCode = String(body.countryCode || '+960').trim();
    const phoneNumber = String(body.phoneNumber || '').replace(/\D/g, '');
    const otp = String(body.otp || '').trim();
    const currentPassword = String(body.currentPassword || '');
    const normalizedPhone = normalizePhone(countryCode, phoneNumber);

    const store = readStore();
    const user = store.users.find((u) => u.id === req.userId);
    if (!user) {
      res.status(404).json({ error: 'Account not found.' });
      return;
    }

    if (!verifyPassword(currentPassword, user.passwordHash)) {
      res.status(401).json({ error: 'Current password is incorrect.' });
      return;
    }

    const otpIdx = store.otps.findIndex(
      (o) =>
        o.userId === user.id &&
        o.purpose === 'change_phone' &&
        o.targetPhone === normalizedPhone &&
        o.expiresAt > Date.now() &&
        o.codeHash === hashOtp(otp)
    );

    if (otpIdx === -1) {
      res.status(400).json({ error: 'Invalid or expired OTP verification code.' });
      return;
    }

    user.countryCode = countryCode;
    user.phoneNumber = phoneNumber;
    user.normalizedPhone = normalizedPhone;
    user.updatedAt = new Date().toISOString();
    store.otps.splice(otpIdx, 1);
    writeStore(store);

    res.json({ user: sanitizeUser(user) });
  });

  // 10. Change Password
  app.post('/api/account/change-password', requireAuth, (req: AuthedRequest, res) => {
    const body = req.body as { currentPassword?: string; newPassword?: string };
    const currentPassword = String(body.currentPassword || '');
    const newPassword = String(body.newPassword || '');

    if (newPassword.length < 6) {
      res.status(400).json({ error: 'New password must be at least 6 characters.' });
      return;
    }

    const store = readStore();
    const user = store.users.find((u) => u.id === req.userId);
    if (!user || !verifyPassword(currentPassword, user.passwordHash)) {
      res.status(401).json({ error: 'Current password is incorrect.' });
      return;
    }

    user.passwordHash = hashPassword(newPassword);
    user.updatedAt = new Date().toISOString();
    writeStore(store);

    res.json({ ok: true });
  });

  // 11. Delete Account
  app.delete('/api/account', requireAuth, (req: AuthedRequest, res) => {
    const currentPassword = String((req.body as { password?: string }).password || '');
    const store = readStore();
    const userIdx = store.users.findIndex((u) => u.id === req.userId);

    if (userIdx === -1) {
      res.status(404).json({ error: 'Account not found.' });
      return;
    }

    const user = store.users[userIdx];
    if (!verifyPassword(currentPassword, user.passwordHash)) {
      res.status(401).json({ error: 'Incorrect password. Account deletion cancelled.' });
      return;
    }

    store.users.splice(userIdx, 1);
    delete store.workspaces[user.id];
    store.otps = store.otps.filter((o) => o.userId !== user.id);
    store.supportReports = store.supportReports.filter((r) => r.userId !== user.id);
    writeStore(store);
    clearSessionCookie(res);

    res.json({ ok: true });
  });

  // 12. User-Isolated Private Workspace GET & PUT
  app.get('/api/workspace', requireAuth, (req: AuthedRequest, res) => {
    const store = readStore();
    const user = store.users.find((u) => u.id === req.userId);
    const workspace = store.workspaces[req.userId!] || { updatedAt: new Date().toISOString() };
    res.json({
      onboardingCompleted: Boolean(user?.onboardingCompleted),
      workspace,
    });
  });

  app.put('/api/workspace', requireAuth, (req: AuthedRequest, res) => {
    const body = req.body as WorkspacePayload & { onboardingCompleted?: boolean };
    const store = readStore();
    const user = store.users.find((u) => u.id === req.userId);
    if (!user) {
      res.status(404).json({ error: 'Account not found.' });
      return;
    }

    if (typeof body.onboardingCompleted === 'boolean') {
      user.onboardingCompleted = body.onboardingCompleted;
      user.updatedAt = new Date().toISOString();
    }

    const current = store.workspaces[user.id] || { updatedAt: new Date().toISOString() };
    store.workspaces[user.id] = {
      businessProfile: body.businessProfile ?? current.businessProfile,
      bankAccounts: Array.isArray(body.bankAccounts) ? body.bankAccounts : current.bankAccounts,
      translations: body.translations ?? current.translations,
      preferences: body.preferences ?? current.preferences,
      quickMenuItems: Array.isArray(body.quickMenuItems)
        ? body.quickMenuItems
        : current.quickMenuItems,
      customers: Array.isArray(body.customers) ? body.customers : current.customers,
      invoices: Array.isArray(body.invoices) ? body.invoices : current.invoices,
      openOrders: Array.isArray(body.openOrders) ? body.openOrders : current.openOrders,
      updatedAt: new Date().toISOString(),
    };
    writeStore(store);

    res.json({
      ok: true,
      onboardingCompleted: user.onboardingCompleted,
      updatedAt: store.workspaces[user.id].updatedAt,
    });
  });

  // 13. Help & Customer Support Reports (Authenticated & User-Isolated)
  app.post('/api/support/reports', requireAuth, (req: AuthedRequest, res) => {
    const body = req.body as Partial<SupportReportRecord>;
    const type = body.type;
    const title = String(body.title || '').trim();
    const description = String(body.description || '').trim();

    if (type !== 'bug' && type !== 'issue' && type !== 'feedback') {
      res.status(400).json({ error: 'Invalid report type.' });
      return;
    }
    if (!title || !description) {
      res.status(400).json({ error: 'Please fill in all required fields.' });
      return;
    }

    const record: SupportReportRecord = {
      id: `rep_${crypto.randomUUID().replace(/-/g, '').slice(0, 12)}`,
      userId: req.userId!,
      type,
      category: body.category ? String(body.category).slice(0, 80) : undefined,
      title: title.slice(0, 200),
      description: description.slice(0, 5000),
      contactInfo: body.contactInfo ? String(body.contactInfo).slice(0, 200) : undefined,
      screenshotDataUrl:
        body.screenshotDataUrl && body.screenshotDataUrl.length <= 1500000
          ? body.screenshotDataUrl
          : undefined,
      appVersion: body.appVersion ? String(body.appVersion).slice(0, 32) : undefined,
      deviceInfo: body.deviceInfo ? String(body.deviceInfo).slice(0, 500) : undefined,
      createdAt: new Date().toISOString(),
    };

    const store = readStore();
    store.supportReports.unshift(record);
    writeStore(store);

    res.status(201).json({
      ok: true,
      report: {
        id: record.id,
        type: record.type,
        category: record.category,
        title: record.title,
        description: record.description,
        createdAt: record.createdAt,
      },
    });
  });

  app.get('/api/support/reports', requireAuth, (req: AuthedRequest, res) => {
    const store = readStore();
    const userReports = store.supportReports
      .filter((r) => r.userId === req.userId)
      .map((r) => ({
        id: r.id,
        type: r.type,
        category: r.category,
        title: r.title,
        description: r.description,
        createdAt: r.createdAt,
      }));
    res.json({ reports: userReports });
  });

  // Vite dev middleware or production static build
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CafePOS server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start CafePOS server:', err);
  process.exit(1);
});
